-- All In One WP Security & Firewall 4.4.1
-- MySQL dump
-- 2019-09-27 15:57:54

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `enojr_aiowps_events`;

CREATE TABLE `enojr_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_aiowps_failed_logins`;

CREATE TABLE `enojr_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_aiowps_global_meta`;

CREATE TABLE `enojr_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_aiowps_login_activity`;

CREATE TABLE `enojr_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `logout_date` datetime NOT NULL DEFAULT '1000-10-00 10:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_aiowps_login_lockdown`;

CREATE TABLE `enojr_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_aiowps_permanent_block`;

CREATE TABLE `enojr_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_commentmeta`;

CREATE TABLE `enojr_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_comments`;

CREATE TABLE `enojr_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_comments` VALUES("1","1","WordPress コメントの投稿者","wapuu@wordpress.example","https://wordpress.org/","","2019-09-28 00:34:12","2019-09-27 15:34:12","こんにちは、これはコメントです。
コメントの承認、編集、削除を始めるにはダッシュボードの「コメント画面」にアクセスしてください。
コメントのアバターは「<a href=\"https://gravatar.com\">Gravatar</a>」から取得されます。","0","1","","","0","0");


DROP TABLE IF EXISTS `enojr_links`;

CREATE TABLE `enojr_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_options`;

CREATE TABLE `enojr_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=222 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_options` VALUES("1","siteurl","https://hkx.monster","yes");
INSERT INTO `enojr_options` VALUES("2","home","https://hkx.monster","yes");
INSERT INTO `enojr_options` VALUES("3","blogname","LIFE","yes");
INSERT INTO `enojr_options` VALUES("4","blogdescription","Just another WordPress site","yes");
INSERT INTO `enojr_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `enojr_options` VALUES("6","admin_email","haokexin1214@gmail.com","yes");
INSERT INTO `enojr_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `enojr_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `enojr_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `enojr_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `enojr_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `enojr_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `enojr_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `enojr_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `enojr_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `enojr_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `enojr_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `enojr_options` VALUES("18","default_category","1","yes");
INSERT INTO `enojr_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `enojr_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `enojr_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `enojr_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `enojr_options` VALUES("23","date_format","Y年n月j日","yes");
INSERT INTO `enojr_options` VALUES("24","time_format","g:i A","yes");
INSERT INTO `enojr_options` VALUES("25","links_updated_date_format","Y年n月j日 g:i A","yes");
INSERT INTO `enojr_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `enojr_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `enojr_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `enojr_options` VALUES("29","rewrite_rules","a:75:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `enojr_options` VALUES("30","hack_file","0","yes");
INSERT INTO `enojr_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `enojr_options` VALUES("32","moderation_keys","","no");
INSERT INTO `enojr_options` VALUES("33","active_plugins","a:2:{i:0;s:19:\"akismet/akismet.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";}","yes");
INSERT INTO `enojr_options` VALUES("34","category_base","","yes");
INSERT INTO `enojr_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `enojr_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `enojr_options` VALUES("37","gmt_offset","","yes");
INSERT INTO `enojr_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `enojr_options` VALUES("39","recently_edited","","no");
INSERT INTO `enojr_options` VALUES("40","template","twentynineteen","yes");
INSERT INTO `enojr_options` VALUES("41","stylesheet","twentynineteen","yes");
INSERT INTO `enojr_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `enojr_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `enojr_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `enojr_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `enojr_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `enojr_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `enojr_options` VALUES("48","db_version","44719","yes");
INSERT INTO `enojr_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `enojr_options` VALUES("50","upload_path","","yes");
INSERT INTO `enojr_options` VALUES("51","blog_public","1","yes");
INSERT INTO `enojr_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `enojr_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `enojr_options` VALUES("54","tag_base","","yes");
INSERT INTO `enojr_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `enojr_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `enojr_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `enojr_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `enojr_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `enojr_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `enojr_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `enojr_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `enojr_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `enojr_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `enojr_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `enojr_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `enojr_options` VALUES("67","image_default_size","","yes");
INSERT INTO `enojr_options` VALUES("68","image_default_align","","yes");
INSERT INTO `enojr_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `enojr_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `enojr_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `enojr_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `enojr_options` VALUES("73","page_comments","0","yes");
INSERT INTO `enojr_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `enojr_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `enojr_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `enojr_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `enojr_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("79","widget_text","a:0:{}","yes");
INSERT INTO `enojr_options` VALUES("80","widget_rss","a:0:{}","yes");
INSERT INTO `enojr_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `enojr_options` VALUES("82","timezone_string","Asia/Tokyo","yes");
INSERT INTO `enojr_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `enojr_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `enojr_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `enojr_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `enojr_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `enojr_options` VALUES("88","site_icon","0","yes");
INSERT INTO `enojr_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `enojr_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `enojr_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `enojr_options` VALUES("92","show_comments_cookies_opt_in","1","yes");
INSERT INTO `enojr_options` VALUES("93","initial_db_version","44719","yes");
INSERT INTO `enojr_options` VALUES("94","enojr_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","yes");
INSERT INTO `enojr_options` VALUES("95","fresh_site","1","yes");
INSERT INTO `enojr_options` VALUES("96","WPLANG","zh_CN","yes");
INSERT INTO `enojr_options` VALUES("97","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("98","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("99","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("100","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("101","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("102","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `enojr_options` VALUES("103","cron","a:8:{i:1569602053;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1569603312;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1569641653;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1569684852;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1569684861;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1569684862;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1569686112;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `enojr_options` VALUES("104","_site_transient_timeout_theme_roots","1569600252","no");
INSERT INTO `enojr_options` VALUES("105","_site_transient_theme_roots","a:3:{s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}","no");
INSERT INTO `enojr_options` VALUES("106","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("107","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("108","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("109","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("110","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("111","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("112","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("113","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("114","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("116","site_manager_cache_installed","4","yes");
INSERT INTO `enojr_options` VALUES("117","theme_mods_twentynineteen","a:1:{s:18:\"custom_css_post_id\";i:-1;}","yes");
INSERT INTO `enojr_options` VALUES("118","recovery_keys","a:0:{}","yes");
INSERT INTO `enojr_options` VALUES("120","theme_switcher_disable","1","yes");
INSERT INTO `enojr_options` VALUES("121","kusanagi-translate-accelerator-settings","a:6:{s:8:\"activate\";s:1:\"1\";s:10:\"cache_type\";s:3:\"apc\";s:8:\"frontend\";s:6:\"cutoff\";s:8:\"wp-login\";s:5:\"cache\";s:5:\"admin\";s:5:\"cache\";s:14:\"file_cache_dir\";s:0:\"\";}","yes");
INSERT INTO `enojr_options` VALUES("122","sitemanager_device_rules","a:2:{s:5:\"smart\";a:2:{s:5:\"theme\";s:0:\"\";s:5:\"regex\";a:6:{i:0;s:8:\"\\(iPhone\";i:1;s:6:\"\\(iPod\";i:2;s:17:\"Android .+ Mobile\";i:3;s:8:\"IEMobile\";i:4;s:13:\"Windows Phone\";i:5;s:26:\"Android; Mobile; .+Firefox\";}}s:6:\"tablet\";a:2:{s:5:\"theme\";s:0:\"\";s:5:\"regex\";a:3:{i:0;s:6:\"\\(iPad\";i:1;s:9:\" Android \";i:2;s:26:\"Android; Tablet; .+Firefox\";}}}","yes");
INSERT INTO `enojr_options` VALUES("129","_site_transient_timeout_browser_9c5c4872bfa3f637183841417bd0b02e","1570203262","no");
INSERT INTO `enojr_options` VALUES("130","_site_transient_browser_9c5c4872bfa3f637183841417bd0b02e","a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"77.0.3865.90\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `enojr_options` VALUES("131","_site_transient_timeout_php_check_a5b4d2808570efd012607394df5c6fa9","1570203262","no");
INSERT INTO `enojr_options` VALUES("132","_site_transient_php_check_a5b4d2808570efd012607394df5c6fa9","a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `enojr_options` VALUES("134","can_compress_scripts","0","no");
INSERT INTO `enojr_options` VALUES("135","_site_transient_timeout_community-events-810542d029b3bd0e6c0c1e4e185e931c","1569641664","no");
INSERT INTO `enojr_options` VALUES("136","_site_transient_community-events-810542d029b3bd0e6c0c1e4e185e931c","a:3:{s:9:\"sandboxed\";b:0;s:8:\"location\";a:1:{s:2:\"ip\";s:10:\"60.76.76.0\";}s:6:\"events\";a:5:{i:0;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:117:\"道玄坂 WordPress Meetup #6 メディア企業の混沌なCMS運用、そのリアルと処方箋 @loftwork COOOP10\";s:3:\"url\";s:63:\"https://www.meetup.com/Tokyo-WordPress-Meetup/events/264745325/\";s:6:\"meetup\";s:22:\"Tokyo WordPress Meetup\";s:10:\"meetup_url\";s:46:\"https://www.meetup.com/Tokyo-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-10-11 19:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:17:\"Tōkyō-to, Japan\";s:7:\"country\";s:2:\"jp\";s:8:\"latitude\";d:35.656063079833999;s:9:\"longitude\";d:139.69549560547;}}i:1;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:81:\"八王子WordPressミートアップ（旧・八王子WordPressもくもく会）\";s:3:\"url\";s:66:\"https://www.meetup.com/Tokyo-WordPress-Meetup/events/dqrlcryznbqb/\";s:6:\"meetup\";s:22:\"Tokyo WordPress Meetup\";s:10:\"meetup_url\";s:46:\"https://www.meetup.com/Tokyo-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-10-12 14:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:15:\"Hachioji, Japan\";s:7:\"country\";s:2:\"jp\";s:8:\"latitude\";d:35.657875061035;s:9:\"longitude\";d:139.34031677246;}}i:2;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:81:\"八王子WordPressミートアップ（旧・八王子WordPressもくもく会）\";s:3:\"url\";s:66:\"https://www.meetup.com/Tokyo-WordPress-Meetup/events/qssjhryznbqb/\";s:6:\"meetup\";s:22:\"Tokyo WordPress Meetup\";s:10:\"meetup_url\";s:46:\"https://www.meetup.com/Tokyo-WordPress-Meetup/\";s:4:\"date\";s:19:\"2019-10-12 14:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:15:\"Hachioji, Japan\";s:7:\"country\";s:2:\"jp\";s:8:\"latitude\";d:35.657875061035;s:9:\"longitude\";d:139.34031677246;}}i:3;a:7:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:16:\"WordCamp Niigata\";s:3:\"url\";s:33:\"https://2019.niigata.wordcamp.org\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2019-10-22 00:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:13:\"Niigata JAPAN\";s:7:\"country\";s:2:\"JP\";s:8:\"latitude\";d:37.446518699999999;s:9:\"longitude\";d:138.8513499;}}i:4;a:7:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:14:\"WordCamp Tokyo\";s:3:\"url\";s:31:\"https://2019.tokyo.wordcamp.org\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2019-11-01 00:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:5:\"Tokyo\";s:7:\"country\";s:2:\"JP\";s:8:\"latitude\";d:35.695734100000003;s:9:\"longitude\";d:139.69030319999999;}}}}","no");
INSERT INTO `enojr_options` VALUES("137","_transient_timeout_feed_992efac292246ae35bf235a03417a202","1569641664","no");
INSERT INTO `enojr_options` VALUES("138","_transient_feed_992efac292246ae35bf235a03417a202","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"ブログ | 日本語\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ja.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"WordPress 日本語ローカルサイトブログ\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Sep 2019 09:01:46 +0900\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"ja\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.3-beta1-46334\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WordPress 5.2.3セキュリティとメンテナンスのリリース\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"https://ja.wordpress.org/2019/09/05/wordpress-5-2-3-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Sep 2019 09:01:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5689\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、Jake Spurlock が書いた WordPress.org 公式ブログの記事、「WordPres [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9054:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a> が書いた WordPress.org 公式ブログの記事、「<a href=\"https://wordpress.org/news/2019/09/wordpress-5-2-3-security-and-maintenance-release/\">WordPress 5.2.3 Security and Maintenance Release</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。<br></p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2.3が利用可能になりました! </p>



<p>このセキュリティとメンテナンスのリリースでは29件の修正と強化を施しました。さらに、多数のセキュリティ修正が加わっていますので、下の一覧をご覧ください。</p>



<p>これらのバグは WordPress 5.2.2以下に影響を与えます。バージョン5.2.3ではこれらを修正していますので、アップグレードをしてください。</p>



<p>まだ5.2にアップデートしていない場合は、5.0とそれ以前のバージョンにもアップデートされたバージョンがあります。</p>



<h3>セキュリティ関連のアップデート</h3>



<ul><li>2件の問題を発見、開示してくれた <a href=\"https://blog.ripstech.com/authors/simon-scannell/\">Simon Scannell of RIPS Technologies</a> に感謝します。1つ目は、投稿者権限での投稿プレビューで見つかったクロスサイトスクリプティング (XSS) 脆弱性です。2つ目は保存されたコメントでのクロスサイトスクリプティング脆弱性です。</li><li>オープンリダイレクトに繋がりうる URL のバリデーションとサニタイズの問題を開示してくれたに&nbsp;<a href=\"https://security-consulting.icu/blog/\">Tim Coen</a>&nbsp;感謝します。</li><li>メディアアップロード中の反射型クロスサイトスクリプティングについて開示してくれたに Anshul Jain 感謝します。</li><li>ショートコードに関するクロスサイトスクリプティング (XSS) の脆弱性を開示してくれた &nbsp;<a href=\"https://fortiguard.com/\">Zhouyuan Yang of Fortinet’s FortiGuard Labs</a> に感謝します</li><li>ダッシュボードで起こりうる反射型クロスサイトスクリプティングのケースを見つけて開示してくれたコアセキュリティチームのIan Dunn に感謝します。</li><li>クロスサイトスクリプティング (XSS) 攻撃を招きかねない URL のサニタイズに関する問題を開示してくれた NCC グループからの Soroush Dalili (<a href=\"https://twitter.com/irsdl?lang=en\">@irsdl</a>) に感謝します。</li><li>上記の変更に加え、WordPress の古いバージョンの jQuery をアップデートしています。この変更は<a href=\"https://core.trac.wordpress.org/ticket/47020\">5.2.1で加えられたもので</a>、今回、古いバージョンへも反映されました。</li></ul>



<p><a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.2.3&amp;order=priority\">すべての変更箇所は Trac で</a>閲覧可能です。 </p>



<p>詳細な情報は Trac 上で変更箇所一覧を閲覧するか、バージョン<a href=\"https://wordpress.org/support/wordpress-version/version-5-2-3/\">5.2.3ドキュメントページ</a>を参照してください。</p>



<p>WordPress 5.2.3はショートサイクルメンテナンスリリースです。次のメジャーリリースは<a href=\"https://make.wordpress.org/core/5-3/\">バージョン5.3</a>です。</p>



<p>WordPress 5.2.3はこのページの上の方にあるボタンからダウンロード可能です。もしくは<strong>ダッシュボード</strong>→ <strong>更新</strong>と進み、<strong>今すぐ更新する</strong>をクリックしてください。</p>



<p>自動バックグラウンド更新をサポートしているサイトは、すでに自動更新がはじまっています。</p>



<h2>感謝と称賛!</h2>



<p>このリリースは62名ものコントリビューターとともにリリースされました。このリリースに協力していただいた皆さんに感謝します!</p>



<p><a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>,&nbsp;<a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>,&nbsp;<a href=\"https://profiles.wordpress.org/alpipego/\">Alex Goller</a>,&nbsp;<a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>,&nbsp;<a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>,&nbsp;<a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>,&nbsp;<a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/762e5e74/\">Ashish Shukla</a>,&nbsp;<a href=\"https://profiles.wordpress.org/wpboss/\">Aslam Shekh</a>,&nbsp;<a href=\"https://profiles.wordpress.org/backermann1978/\">backermann1978</a>,&nbsp;<a href=\"https://profiles.wordpress.org/cdog/\">Catalin Dogaru</a>,&nbsp;<a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>,&nbsp;<a href=\"https://profiles.wordpress.org/aprea/\">Chris Aprea</a>,&nbsp;<a href=\"https://profiles.wordpress.org/christophherr/\">Christoph Herr</a>,&nbsp;<a href=\"https://profiles.wordpress.org/danmicamediacom/\">dan@micamedia.com</a>,&nbsp;<a href=\"https://profiles.wordpress.org/diddledan/\">Daniel Llewellyn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/donmhico/\">donmhico</a>,&nbsp;<a href=\"https://profiles.wordpress.org/iseulde/\">Ella van Durpe</a>,&nbsp;<a href=\"https://profiles.wordpress.org/epiqueras/\">epiqueras</a>,&nbsp;<a href=\"https://profiles.wordpress.org/fencer04/\">Fencer04</a>,&nbsp;<a href=\"https://profiles.wordpress.org/flaviozavan/\">flaviozavan</a>,&nbsp;<a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>,&nbsp;<a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>,&nbsp;<a href=\"https://profiles.wordpress.org/gqevu6bsiz/\">gqevu6bsiz</a>,&nbsp;<a href=\"https://profiles.wordpress.org/thakkarhardik/\">Hardik Thakkar</a>,&nbsp;<a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>,&nbsp;<a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>,&nbsp;<a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>,&nbsp;<a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeffrey Paul</a>,&nbsp;<a href=\"https://profiles.wordpress.org/jikamens/\">jikamens</a>,&nbsp;<a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa,</a> <a href=\"https://profiles.wordpress.org/karlgroves/\">karlgroves</a>,&nbsp;<a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a>,&nbsp;<a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>,&nbsp;<a href=\"https://profiles.wordpress.org/majemedia/\">Maje Media LLC</a>,&nbsp;<a href=\"https://profiles.wordpress.org/mspatovaliyski/\">Martin Spatovaliyski</a>,&nbsp;<a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>,&nbsp;<a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>,&nbsp;<a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nayana123/\">nayana123</a>,&nbsp;<a href=\"https://profiles.wordpress.org/greatislander/\">Ned Zimmerman</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nickdaugherty/\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/rabmalin/\">Nilambar Sharma</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nmenescardi/\">nmenescardi</a>,&nbsp;<a href=\"https://profiles.wordpress.org/bassgang/\">Paul Vincent Beigang</a>,&nbsp;<a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendonça</a>,&nbsp;<a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vjik/\">Sergey Predvoditelev</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sharaz/\">Sharaz Shahid</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sstoqnov/\">Stanimir Stoyanov</a>,&nbsp;<a href=\"https://profiles.wordpress.org/ryokuhi/\">Stefano Minoia</a>,&nbsp;<a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>,&nbsp;<a href=\"https://profiles.wordpress.org/isabel_brison/\">tellthemachines</a>,&nbsp;<a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vaishalipanchal/\">Vaishali Panchal</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vortfu/\">vortfu</a>,&nbsp;<a href=\"https://profiles.wordpress.org/tsewlliw/\">Will West</a>, そして <a href=\"https://profiles.wordpress.org/yarnboy/\">yarnboy</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"WordPress 5.2.2メンテナンスリリース\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://ja.wordpress.org/2019/06/19/wordpress-5-2-2-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 19 Jun 2019 01:42:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5660\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、marybaum が書いた WordPress.org 公式ブログの記事、「WordPress 5.2 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4748:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/marybaum/\">marybaum</a> が書いた WordPress.org 公式ブログの記事、「<a href=\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\">WordPress 5.2.2 Maintenance Release</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。<br></p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2.2が利用可能になりました! このメンテナンスリリースでは13個のバグを修正し、<a href=\"https://ja.wordpress.org/2019/05/08/jaco/\">5.2で導入された</a>サイトヘルス機能にすこし磨きをかけました。</p>



<p>詳細な情報は <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.2.2&amp;order=priority\">Trac の変更リスト</a>か、<a href=\"https://wordpress.org/support/wordpress-version/version-5-2-2/\">バージョン5.2.2のドキュメンテーションページ</a>を参照してください。</p>



<p>WordPress 5.2.2はショートサイクルメンテナンスリリースです。次のメジャーリリースは5.3です。進行状況の詳細は  <a href=\"https://make.wordpress.org/core/\">make.wordpress.org/core</a> をチェックしてみたください。</p>



<p><a href=\"https://ja.wordpress.org/download/\">WordPress 5.2.</a>2 をダウンロードするか、<code>ダッシュボード → 更新</code>と 進み、<code>今すぐ更新する</code>をクリックしてください。自動バックグラウンド更新をサポートしているサイトは、すでに自動更新がはじまっています。</p>



<p><a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>、<a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a> と <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>   が共同でリードし、エグゼクティブディレクターの Josepha Haden Chomphosy の素晴らしいガイドを受け、他に30名の貢献者の皆さんとともにリリースしました。このリリースに協力していただいた皆さんに感謝します!</p>



<p><a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/jankimoradiya/\">Janki Moradiya</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jitendrabanjara1991/\">jitendrabanjara1991</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>, <a href=\"https://profiles.wordpress.org/immeet94/\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">palmiak</a>, <a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendonça</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly/\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shashank3105/\">Shashank Panchal</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">vaishalipanchal</a>, <a href=\"https://profiles.wordpress.org/vrimill/\">vrimill</a>、と <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"WordPress 5.2.1 メンテナンスリリース\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://ja.wordpress.org/2019/05/22/wordpress-5-2-1-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 May 2019 07:22:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5650\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、Josephaが書いた WordPress.org 公式ブログの記事、「WordPress 5.2.1 [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5703:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a>が書いた WordPress.org 公式ブログの記事、「<a href=\"https://wordpress.org/news/2019/05/wordpress-5-2-1-maintenance-release/\">WordPress 5.2.1 Maintenance Release</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。<br></p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2.1が利用可能になりました! このメンテナンスリリースでは、ブロックエディター、アクセシビリティ、国際化、そして<a href=\"https://ja.wordpress.org/2019/05/08/jaco/\">5.2で導入された</a>サイトヘルス機能の改善と33件のバグを修正しています。</p>



<p><a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.2.1&amp;order=priority\">変更点のすべてのリストは Trac で</a>参照できます。</p>



<p>WordPress 5.2.1はショートサイクルのメンテナンスリリースです。<a href=\"https://core.trac.wordpress.org/query?milestone=5.2.2\">バージョン5.2.2</a>はだいたい2週間後のリリースが予定されています。</p>



<p><a href=\"https://ja.wordpress.org/download/\">WordPress 5.2.1</a> をダウンロードするか、<code>ダッシュボード → 更新</code>と 進み、<code>今すぐ更新する</code>をクリックしてください。自動バックグラウンド更新をサポートしているサイトは、すでに自動更新がはじまっています。</p>



<p>Jonathan Desrosiers と William Earnhardt が共同でリードし、他に52名の貢献者の皆さんとともにリリースしました。このリリースに協力していただいた皆さんに感謝します!</p>



<p><a href=\"https://profiles.wordpress.org/xavortm/\">Alex Dimitrov</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey “Rarst” Savchenko</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/anischarolia/\">anischarolia</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/chesio/\">chesio</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/daxelrod/\">daxelrod</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/odminstudios/\">Dima</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/iseulde/\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/edocev/\">Emil Dotsev</a>, <a href=\"https://profiles.wordpress.org/sachyya-sachet/\">ghoul</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">Grzegorz (Greg) Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/gwwar/\">gwwar</a>, <a href=\"https://profiles.wordpress.org/hareesh-pillai/\">Hareesh</a>, <a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/imath/\">imath</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a>, <a href=\"https://profiles.wordpress.org/jrf/\">jrf</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">kjellr</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mikengarrett/\">MikeNGarrett</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/onlanka/\">onlanka</a>, <a href=\"https://profiles.wordpress.org/paragoninitiativeenterprises/\">paragoninitiativeenterprises</a>, <a href=\"https://profiles.wordpress.org/parkcityj/\">parkcityj</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/presskopp/\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/sebastienserre/\">Sébastien SERRE</a>, <a href=\"https://profiles.wordpress.org/tfrommen/\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/timph/\">timph</a>, <a href=\"https://profiles.wordpress.org/tobiasbg/\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tonybogdanov/\">tonybogdanov</a>, <a href=\"https://profiles.wordpress.org/tobifjellner/\">Tor-Bjorn Fjellner</a>, <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a>, そして <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>。</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"WordPress 5.2 “ジャコ”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"https://ja.wordpress.org/2019/05/08/jaco/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 May 2019 02:04:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5639\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"以下は、Matt Mullenweg が書いた WordPress.org 公式ブログの記事、「WordPre [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:29968:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a> が書いた WordPress.org 公式ブログの記事、「<a href=\"https://wordpress.org/news/2019/05/jaco/\">WordPress 5.2 “Jaco”</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。<br></p>



<hr class=\"wp-block-separator\" />



<h2>サイトを安全に保つ</h2>



<figure class=\"wp-block-image\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/05/about_maintain-wordpress-cropped.png?fit=632%2C500&amp;ssl=1\" alt=\"\" class=\"wp-image-6926\" /></figure>



<p>名高く革新的なジャズベーシスト、ジャコ・パストリアスに敬意を評して命名された WordPress 5.2がダウンロードもしくは WordPress のダッシュボードからのアップデートが可能になりました。このアップデートの新しい機能により、サイトでもし何かがうまくいかなかったときの修正がこれまでより、より容易になりました。</p>



<p>設定の問題や致命的なエラーを特定、修正するためのより強力なツールが備わりました。クライアントを手助けする開発者であれ、ご自分のサイトのみを管理する方であれ、これらのツールは必要なときに正しい情報を手に入れる助けになるでしょう。</p>



<hr class=\"wp-block-separator\" />



<h3>サイトヘルスチェック</h3>



<div class=\"wp-block-image\"><figure class=\"alignleft\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2019/05/about_site-health.png?resize=205%2C143&amp;ssl=1\" alt=\"\" class=\"wp-image-6927\" /></figure></div>



<p>5.1で導入された<a href=\"https://ja.wordpress.org/2019/02/22/betty/\">サイトヘルス</a>機能に加え、このリリースではよくある設定問題のデバッグに役立つ2つの新しいページが追加されました。また、開発者がサイト管理者のためにデバッグ情報を含められるスペースも追加しています。</p>



<h3>PHP エラープロテクション</h3>



<div class=\"wp-block-image\"><figure class=\"alignleft\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/05/about_error-protection.png?resize=202%2C228&amp;ssl=1\" alt=\"\" class=\"wp-image-6930\" /></figure></div>



<p>この管理者向けのアップデートにより、開発者の時間を損なわずに致命的なエラーを安全に修正もしくは管理できるようになります。いわゆる「死のホワイトスクリーン」のより優れた処理と、エラーを引き起こしているプラグインもしくはテーマを停止させるリカバリーモードへの移行が特徴です。</p>



<hr class=\"wp-block-separator\" />



<h2>皆さんのための改善</h2>



<h3>アクセシビリティの向上</h3>



<p>スクリーンリーダーやその他の支援技術を利用する方々のため、状況認識とキーボードナビゲーションのフローを改善するための多くの変更が連携して施されました。</p>



<h3>新しいダッシュボードアイコン</h3>



<p>Instagram、BuddyPress 用のアイコンセット、そしてグローバルな多様性を受け入れるための回転する地球を含む13個の新しいアイコンが備わりました。ダッシュボードで見つけてお楽しみください !</p>



<h3>プラグイン互換性チェック</h3>



<p>インストールされているプラグインがサイトの PHP のバージョンと互換性があるかを WordPress が自動的に検知するようになりました。もしそのプラグインが現在使用中の PHP のバージョンよりも上のバージョンを必要とする場合、潜在的な互換性エラーを回避するため、WordPress はそのプラグインを有効化しません。</p>



<hr class=\"wp-block-separator\" />



<h2>開発者をハッピーに</h2>



<p><a href=\"https://make.wordpress.org/core/2019/03/26/coding-standards-updates-for-php-5-6/\"><strong>PHP バージョンの引き上げ</strong></a></p>



<p>サポートされる PHP の最低バージョンが5.6.20になりました。WordPress 5.2から、テーマとプラグインは名前空間、無名関数、そしてもっとたくさんのことを安全に活用できるようになりました !</p>



<p><a href=\"https://make.wordpress.org/core/2019/04/24/developer-focused-privacy-updates-in-5-2/\"><strong>プライバシーのアップデート</strong></a></p>



<p>新しいテーマページテンプレート、条件分岐関数、そしてプライバシーポリシーページのデザインとカスタマイズをより容易にする2つの CSS クラス。</p>



<p><strong><a href=\"https://make.wordpress.org/core/2019/04/24/miscellaneous-developer-updates-in-5-2/\">新しいボディタグのフック</a> </strong></p>



<p>5.2 では <code>wp_body_open</code> フックが導入されました。テーマが、<code>&lt;body&gt;</code> 要素の最初にコードを挿入できるようにします。</p>



<p><a href=\"https://make.wordpress.org/core/2019/03/25/building-javascript/\"><strong>JavaScript のビルド</strong></a></p>



<p>wordpress/scripts パッケージ内での webpack と Babel 設定の追加により、モダンな JavaScript を書くための複雑なビルドツールのセットアップに開発者は悩む必要がなくなりました。</p>



<p><em>*PHP の古いバージョン(5.6.20未満)でサイトが動いている場合は、5.2をインストールする前に <a href=\"https://ja.wordpress.org/support/update-php/\">PHP をアップデート</a>してください。</em></p>



<hr class=\"wp-block-separator\" />



<h2>チーム</h2>



<p>このリリースは <a href=\"http://ma.tt/\">Matt Mullenweg</a>、<a href=\"https://josepha.blog/\">Josepha Haden Chomphosy</a>、そして <a href=\"https://pento.net/\">Gary Pendergast</a> によってリードされました。 彼らは以下の327名の寛大なボランティア貢献者の皆さんに素晴らしい力添えを受けました。ご利用中の音楽サービスでジャコ・パストリアスの曲を流しながら、この方たちのプロフィールページを眺めてみてください:<a href=\"https://profiles.wordpress.org/aandrewdixon\">aandrewdixon</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/adamsoucie\">Adam Soucie</a>, <a href=\"https://profiles.wordpress.org/oztaser\">Adil Öztaşer</a>, <a href=\"https://profiles.wordpress.org/ajitbohra\">Ajit Bohra</a>, <a href=\"https://profiles.wordpress.org/schlessera\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/aldavigdis\">aldavigdis</a>, <a href=\"https://profiles.wordpress.org/alexdenning\">Alex Denning</a>, <a href=\"https://profiles.wordpress.org/akirk\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/viper007bond\">Alex Mills</a>, <a href=\"https://profiles.wordpress.org/tellyworth\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/lexiqueen\">Alexis</a>, <a href=\"https://profiles.wordpress.org/alexislloyd\">Alexis Lloyd</a>, <a href=\"https://profiles.wordpress.org/allancole\">allancole</a>, <a href=\"https://profiles.wordpress.org/allendav\">Allen Snook</a>, <a href=\"https://profiles.wordpress.org/arena\">André</a>, <a href=\"https://profiles.wordpress.org/nosolosw\">Andrés</a>, <a href=\"https://profiles.wordpress.org/andraganescu\">andraganescu</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/euthelup\">Andrei Lupu</a>, <a href=\"https://profiles.wordpress.org/aduth\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/rarst\">Andrey &#8220;Rarst&#8221; Savchenko</a>, <a href=\"https://profiles.wordpress.org/afragen\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/andizer\">Andy Meerwaldt</a>, <a href=\"https://profiles.wordpress.org/aniketpatel\">Aniket Patel</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/vanyukov\">Anton Vanyukov</a>, <a href=\"https://profiles.wordpress.org/avillegasn\">Antonio Villegas</a>, <a href=\"https://profiles.wordpress.org/antonypuckey\">antonypuckey</a>, <a href=\"https://profiles.wordpress.org/aristath\">Aristeides Stathopoulos</a>, <a href=\"https://profiles.wordpress.org/wpboss\">Aslam Shekh</a>, <a href=\"https://profiles.wordpress.org/axaak\">axaak</a>, <a href=\"https://profiles.wordpress.org/pixolin\">Bego Mario Garde</a>, <a href=\"https://profiles.wordpress.org/empireoflight\">Ben Dunkle</a>, <a href=\"https://profiles.wordpress.org/britner\">Ben Ritner &#8211; Kadence Themes</a>, <a href=\"https://profiles.wordpress.org/bfintal\">Benjamin Intal</a>, <a href=\"https://profiles.wordpress.org/billerickson\">Bill Erickson</a>, <a href=\"https://profiles.wordpress.org/birgire\">Birgir Erlendsson</a>, <a href=\"https://profiles.wordpress.org/bodohugobarwich\">Bodo (Hugo) Barwich</a>, <a href=\"https://profiles.wordpress.org/gitlost\">bonger</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/bradleyt\">Bradley Taylor</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/brentswisher\">Brent Swisher</a>, <a href=\"https://profiles.wordpress.org/bulletdigital\">bulletdigital</a>, <a href=\"https://profiles.wordpress.org/burhandodhy\">Burhan Nasir</a>, <a href=\"https://profiles.wordpress.org/cathibosco1\">Cathi Bosco</a>, <a href=\"https://profiles.wordpress.org/chetan200891\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/chiaralovelaces\">Chiara Magnani</a>, <a href=\"https://profiles.wordpress.org/chouby\">Chouby</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/dswebsme\">D.S. Webster</a>, <a href=\"https://profiles.wordpress.org/colorful-tones\">Damon Cook</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/danieltj\">Daniel James</a>, <a href=\"https://profiles.wordpress.org/diddledan\">Daniel Llewellyn</a>, <a href=\"https://profiles.wordpress.org/talldanwp\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/mte90\">Daniele Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/nerrad\">Darren Ethier (nerrad)</a>, <a href=\"https://profiles.wordpress.org/drw158\">Dave Whitley</a>, <a href=\"https://profiles.wordpress.org/davefx\">DaveFX</a>, <a href=\"https://profiles.wordpress.org/davetgreen\">davetgreen</a>, <a href=\"https://profiles.wordpress.org/david.binda\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/davidbinda\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/dlh\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dgroddick\">David Roddick</a>, <a href=\"https://profiles.wordpress.org/get_dave\">David Smith</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald\">davidb</a>, <a href=\"https://profiles.wordpress.org/folletto\">Davide &#8216;Folletto&#8217; Casali</a>, <a href=\"https://profiles.wordpress.org/dekervit\">dekervit</a>, <a href=\"https://profiles.wordpress.org/denis-de-bernardy\">Denis de Bernardy</a>, <a href=\"https://profiles.wordpress.org/dmsnell\">Dennis Snell</a>, <a href=\"https://profiles.wordpress.org/valendesigns\">Derek Herman</a>, <a href=\"https://profiles.wordpress.org/pcfreak30\">Derrick Hammer</a>, <a href=\"https://profiles.wordpress.org/designsimply\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dhanukanuwan\">Dhanukanuwan</a>, <a href=\"https://profiles.wordpress.org/dharm1025\">Dharmesh Patel</a>, <a href=\"https://profiles.wordpress.org/dianeco\">Diane</a>, <a href=\"https://profiles.wordpress.org/diegoreymendez\">diegoreymendez</a>, <a href=\"https://profiles.wordpress.org/dilipbheda\">Dilip Bheda</a>, <a href=\"https://profiles.wordpress.org/odminstudios\">Dima</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dency\">Dixita Dusara</a>, <a href=\"https://profiles.wordpress.org/iamdmitrymayorov\">Dmitry Mayorov</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/drewapicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/dsifford\">dsifford</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/etoledom\">etoledom</a>, <a href=\"https://profiles.wordpress.org/fabiankaegy\">fabiankaegy</a>, <a href=\"https://profiles.wordpress.org/faisal03\">Faisal Alvi</a>, <a href=\"https://profiles.wordpress.org/parsmizban\">Farhad Sakhaei</a>, <a href=\"https://profiles.wordpress.org/flixos90\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/peaceablewhale\">Franklin Tse</a>, <a href=\"https://profiles.wordpress.org/fuegas\">Fuegas</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/soulseekah\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/gziolo\">Grzegorz (Greg) Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/wido\">Guido Scialfa</a>, <a href=\"https://profiles.wordpress.org/gutendev\">GutenDev</a>, <a href=\"https://profiles.wordpress.org/hannahmalcolm\">Hannah Malcolm</a>, <a href=\"https://profiles.wordpress.org/hardik-amipara\">Hardik Amipara</a>, <a href=\"https://profiles.wordpress.org/thakkarhardik\">Hardik Thakkar</a>, <a href=\"https://profiles.wordpress.org/luehrsen\">Hendrik Luehrsen</a>, <a href=\"https://profiles.wordpress.org/henrywright-1\">Henry</a>, <a href=\"https://profiles.wordpress.org/henrywright\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/ryanshoover\">Hoover</a>, <a href=\"https://profiles.wordpress.org/ianbelanger\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ice9js\">ice9js</a>, <a href=\"https://profiles.wordpress.org/zinigor\">Igor Zinovyev</a>, <a href=\"https://profiles.wordpress.org/imath\">imath</a>, <a href=\"https://profiles.wordpress.org/ixium\">Ixium</a>, <a href=\"https://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jakeparis\">jakeparis</a>, <a href=\"https://profiles.wordpress.org/cc0a\">James</a>, <a href=\"https://profiles.wordpress.org/janak007\">janak Kaneriya</a>, <a href=\"https://profiles.wordpress.org/jarred-kennedy\">Jarred Kennedy</a>, <a href=\"https://profiles.wordpress.org/vengisss\">Javier Villanueva</a>, <a href=\"https://profiles.wordpress.org/jayupadhyay01\">Jay Upadhyay</a>, <a href=\"https://profiles.wordpress.org/jaydeep-rami\">Jaydip Rami</a>, <a href=\"https://profiles.wordpress.org/jaymanpandya\">Jayman Pandya</a>, <a href=\"https://profiles.wordpress.org/jdeeburke\">jdeeburke</a>, <a href=\"https://profiles.wordpress.org/audrasjb\">Jean-Baptiste Audras</a>, <a href=\"https://profiles.wordpress.org/jeffpaul\">Jeff Paul</a>, <a href=\"https://profiles.wordpress.org/cheffheid\">Jeffrey de Wit</a>, <a href=\"https://profiles.wordpress.org/miss_jwo\">Jenny</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/endocreative\">Jeremy Green</a>, <a href=\"https://profiles.wordpress.org/jeherve\">Jeremy Herve</a>, <a href=\"https://profiles.wordpress.org/jitendrabanjara1991\">jitendrabanjara1991</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">JJJ</a>, <a href=\"https://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/j-falk\">Johan Falk</a>, <a href=\"https://profiles.wordpress.org/johannadevos\">Johanna de Vos</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jonathandejong\">Jonathandejong</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jonnybojangles\">jonnybojangles</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/jordesign\">jordesign</a>, <a href=\"https://profiles.wordpress.org/koke\">Jorge Bernal</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/keraweb\">Jory Hogeveen</a>, <a href=\"https://profiles.wordpress.org/jcastaneda\">Jose Castaneda</a>, <a href=\"https://profiles.wordpress.org/josephwa\">josephwa</a>, <a href=\"https://profiles.wordpress.org/builtbynorthby\">Josh Feck</a>, <a href=\"https://profiles.wordpress.org/joshuawold\">JoshuaWold</a>, <a href=\"https://profiles.wordpress.org/joyously\">Joy</a>, <a href=\"https://profiles.wordpress.org/jplojohn\">jplo</a>, <a href=\"https://profiles.wordpress.org/jrtashjian\">JR Tashjian</a>, <a href=\"https://profiles.wordpress.org/jrf\">jrf</a>, <a href=\"https://profiles.wordpress.org/juiiee8487\">Juhi Patel</a>, <a href=\"https://profiles.wordpress.org/juliarrr\">juliarrr</a>, <a href=\"https://profiles.wordpress.org/kadamwhite\">K. Adam White</a>, <a href=\"https://profiles.wordpress.org/kamataryo\">KamataRyo</a>, <a href=\"https://profiles.wordpress.org/karinedo\">Karine Do</a>, <a href=\"https://profiles.wordpress.org/katyatina\">Katyatina</a>, <a href=\"https://profiles.wordpress.org/kelin1003\">Kelin Chauhan</a>, <a href=\"https://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/itzmekhokan\">Khokan Sardar</a>, <a href=\"https://profiles.wordpress.org/killua99\">killua99</a>, <a href=\"https://profiles.wordpress.org/ixkaito\">Kite</a>, <a href=\"https://profiles.wordpress.org/kjellr\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/knutsp\">Knut Sparhell</a>, <a href=\"https://profiles.wordpress.org/olein\">Koji Kuno</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/xkon\">Konstantinos Xenos</a>, <a href=\"https://profiles.wordpress.org/codemascot\">Kʜᴀɴ (ಠ_ಠ)</a>, <a href=\"https://profiles.wordpress.org/laurelfulford\">laurelfulford</a>, <a href=\"https://profiles.wordpress.org/lkraav\">lkraav</a>, <a href=\"https://profiles.wordpress.org/lukecarbis\">Luke Carbis</a>, <a href=\"https://profiles.wordpress.org/lgedeon\">Luke Gedeon</a>, <a href=\"https://profiles.wordpress.org/lukepettway\">Luke Pettway</a>, <a href=\"https://profiles.wordpress.org/maedahbatool\">Maedah Batool</a>, <a href=\"https://profiles.wordpress.org/travel_girl\">Maja Benke</a>, <a href=\"https://profiles.wordpress.org/malae\">Malae</a>, <a href=\"https://profiles.wordpress.org/manzoorwanijk\">Manzoor Wani</a>, <a href=\"https://profiles.wordpress.org/robobot3000\">Marcin</a>, <a href=\"https://profiles.wordpress.org/iworks\">Marcin Pietrzak</a>, <a href=\"https://profiles.wordpress.org/marco-peralta\">Marco Peralta</a>, <a href=\"https://profiles.wordpress.org/marcofernandes\">marcofernandes</a>, <a href=\"https://profiles.wordpress.org/mkaz\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/marekhrabe\">marekhrabe</a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius Jensen</a>, <a href=\"https://profiles.wordpress.org/mbelchev\">Mariyan Belchev</a>, <a href=\"https://profiles.wordpress.org/mapk\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/markcallen\">markcallen</a>, <a href=\"https://profiles.wordpress.org/mechter\">Markus Echterhoff</a>, <a href=\"https://profiles.wordpress.org/m-e-h\">Marty Helmick</a>, <a href=\"https://profiles.wordpress.org/marybaum\">marybaum</a>, <a href=\"https://profiles.wordpress.org/mattnyeus\">mattnyeus</a>, <a href=\"https://profiles.wordpress.org/mdwolinski\">mdwolinski</a>, <a href=\"https://profiles.wordpress.org/immeet94\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mheikkila\">mheikkila</a>, <a href=\"https://profiles.wordpress.org/wpscholar\">Micah Wood</a>, <a href=\"https://profiles.wordpress.org/michelleweber\">michelleweber</a>, <a href=\"https://profiles.wordpress.org/mcsf\">Miguel Fonseca</a>, <a href=\"https://profiles.wordpress.org/mmtr86\">Miguel Torres</a>, <a href=\"https://profiles.wordpress.org/simison\">Mikael Korpela</a>, <a href=\"https://profiles.wordpress.org/mauteri\">Mike Auteri</a>, <a href=\"https://profiles.wordpress.org/mikeschinkel\">Mike Schinkel [WPLib Box project lead]</a>, <a href=\"https://profiles.wordpress.org/mikeschroder\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mikeselander\">Mike Selander</a>, <a href=\"https://profiles.wordpress.org/mikengarrett\">MikeNGarrett</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/0mirka00\">mirka</a>, <a href=\"https://profiles.wordpress.org/lord_viper\">Mobin Ghasempoor</a>, <a href=\"https://profiles.wordpress.org/mohadeseghasemi\">Mohadese Ghasemi</a>, <a href=\"https://profiles.wordpress.org/saimonh\">Mohammed Saimon</a>, <a href=\"https://profiles.wordpress.org/mor10\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/man4toman\">Morteza Geransayeh</a>, <a href=\"https://profiles.wordpress.org/mmuhsin\">Muhammad Muhsin</a>, <a href=\"https://profiles.wordpress.org/mukesh27\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/m_uysl\">Mustafa Uysal</a>, <a href=\"https://profiles.wordpress.org/mzorz\">mzorz</a>, <a href=\"https://profiles.wordpress.org/nfmohit\">Nahid F. Mohit</a>, <a href=\"https://profiles.wordpress.org/naoki0h\">Naoki Ohashi</a>, <a href=\"https://profiles.wordpress.org/nateallen\">Nate Allen</a>, <a href=\"https://profiles.wordpress.org/greatislander\">Ned Zimmerman</a>, <a href=\"https://profiles.wordpress.org/neobabis\">Neokazis Charalampos</a>, <a href=\"https://profiles.wordpress.org/modernnerd\">Nick Cernis</a>, <a href=\"https://profiles.wordpress.org/ndiego\">Nick Diego</a>, <a href=\"https://profiles.wordpress.org/celloexpressions\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/jainnidhi\">Nidhi Jain</a>, <a href=\"https://profiles.wordpress.org/nielslange\">Niels Lange</a>, <a href=\"https://profiles.wordpress.org/nielsdeblaauw\">nielsdeblaauw</a>, <a href=\"https://profiles.wordpress.org/nnikolov\">Nikolay Nikolov</a>, <a href=\"https://profiles.wordpress.org/rabmalin\">Nilambar Sharma</a>, <a href=\"https://profiles.wordpress.org/ninio\">ninio</a>, <a href=\"https://profiles.wordpress.org/notnownikki\">notnownikki</a>, <a href=\"https://profiles.wordpress.org/pandelisz\">pandelisz</a>, <a href=\"https://profiles.wordpress.org/paragoninitiativeenterprises\">paragoninitiativeenterprises</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/pbearne\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/pbiron\">Paul Biron</a>, <a href=\"https://profiles.wordpress.org/pedromendonca\">Pedro Mendonça</a>, <a href=\"https://profiles.wordpress.org/peterbooker\">Peter Booker</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/pfiled\">pfiled</a>, <a href=\"https://profiles.wordpress.org/pilou69\">pilou69</a>, <a href=\"https://profiles.wordpress.org/pranalipatel\">Pranali Patel</a>, <a href=\"https://profiles.wordpress.org/pratikkry\">Pratik K. Yadav</a>, <a href=\"https://profiles.wordpress.org/presskopp\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/psealock\">psealock</a>, <a href=\"https://profiles.wordpress.org/bamadesigner\">Rachel Cherry</a>, <a href=\"https://profiles.wordpress.org/rahmon\">Rahmon</a>, <a href=\"https://profiles.wordpress.org/superpoincare\">Ramanan</a>, <a href=\"https://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/ramizmanked\">Ramiz Manked</a>, <a href=\"https://profiles.wordpress.org/ramonopoly\">ramonopoly</a>, <a href=\"https://profiles.wordpress.org/youknowriad\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/rinatkhaziev\">Rinat Khaziev</a>, <a href=\"https://profiles.wordpress.org/noisysocks\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/rsusanto\">Rudy Susanto</a>, <a href=\"https://profiles.wordpress.org/ryan\">Ryan Boren</a>, <a href=\"https://profiles.wordpress.org/welcher\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/saeedfard\">Saeed Fard</a>, <a href=\"https://profiles.wordpress.org/salcode\">Sal Ferrarello</a>, <a href=\"https://profiles.wordpress.org/samanehmirrajabi\">Samaneh Mirrajabi</a>, <a href=\"https://profiles.wordpress.org/samikeijonen\">Sami Keijonen</a>, <a href=\"https://profiles.wordpress.org/elhardoum\">Samuel Elh</a>, <a href=\"https://profiles.wordpress.org/sgarza\">Santiago Garza</a>, <a href=\"https://profiles.wordpress.org/saracope\">Sara Cope</a>, <a href=\"https://profiles.wordpress.org/saracup\">saracup</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/sebastianpisula\">Sebastian Pisula</a>, <a href=\"https://profiles.wordpress.org/ebrahimzadeh\">Sekineh Ebrahimzadeh</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sergioestevao\">SergioEstevao</a>, <a href=\"https://profiles.wordpress.org/sgastard\">sgastard</a>, <a href=\"https://profiles.wordpress.org/sharifkiberu\">sharifkiberu</a>, <a href=\"https://profiles.wordpress.org/shazdeh\">shazdeh</a>, <a href=\"https://profiles.wordpress.org/shital-patel\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/sky_76\">sky_76</a>, <a href=\"https://profiles.wordpress.org/soean\">Soren Wrede</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stevenkword\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/sudar\">Sudar Muthu</a>, <a href=\"https://profiles.wordpress.org/sudhiryadav\">Sudhir Yadav</a>, <a href=\"https://profiles.wordpress.org/szepeviktor\">szepe.viktor</a>, <a href=\"https://profiles.wordpress.org/miyauchi\">Takayuki Miyauchi</a>, <a href=\"https://profiles.wordpress.org/karmatosed\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/themonic\">Themonic</a>, <a href=\"https://profiles.wordpress.org/thomstark\">thomstark</a>, <a href=\"https://profiles.wordpress.org/tfrommen\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/thrijith\">Thrijith Thankachan</a>, <a href=\"https://profiles.wordpress.org/hedgefield\">Tim Hedgefield</a>, <a href=\"https://profiles.wordpress.org/timwright12\">Tim Wright</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/timph\">timph</a>, <a href=\"https://profiles.wordpress.org/tmatsuur\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/ohiosierra\">tmdesigned</a>, <a href=\"https://profiles.wordpress.org/tmdesigned\">tmdesigned</a>, <a href=\"https://profiles.wordpress.org/tz-media\">Tobias Zimpel</a>, <a href=\"https://profiles.wordpress.org/tomharrigan\">TomHarrigan</a>, <a href=\"https://profiles.wordpress.org/tobifjellner\">Tor-Bjorn Fjellner</a>, <a href=\"https://profiles.wordpress.org/toro_unit\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/torres126\">torres126</a>, <a href=\"https://profiles.wordpress.org/zodiac1978\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/itowhid06\">Towhidul Islam</a>, <a href=\"https://profiles.wordpress.org/liljimmi\">Tracy Levesque</a>, <a href=\"https://profiles.wordpress.org/umang7\">Umang Bhanvadia</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal\">Vaishali Panchal</a>, <a href=\"https://profiles.wordpress.org/webfactory\">WebFactory</a>, <a href=\"https://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/bahia0019\">William &#8216;Bahia&#8217; Bay</a>, <a href=\"https://profiles.wordpress.org/earnjam\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/williampatton\">williampatton</a>, <a href=\"https://profiles.wordpress.org/willscrlt\">Willscrlt</a>, <a href=\"https://profiles.wordpress.org/wolly\">Wolly aka Paolo Valenti</a>, <a href=\"https://profiles.wordpress.org/wrwrwr0\">wrwrwr0</a>, <a href=\"https://profiles.wordpress.org/yoavf\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/fierevere\">Yui</a>, そして <a href=\"https://profiles.wordpress.org/zebulan\">zebulan</a>。</p>



<p>また、<a href=\"https://wordpress.org/support/\">サポートフォーラム</a> (<a href=\"https://ja.wordpress.org/support/\">日本語</a>)で貢献してくださっているコミュニティボランティアの皆さんにも感謝いたします。WordPress を初めて使う方からであれ、最初のリリースからの利用者であれ、彼らは世界中からの質問に答えています。こうしたリリースは皆さんのおかげでより成功したものと</p>



<p>最新情報を追ったり、貢献したい方は <a href=\"https://make.wordpress.org/\">Make WordPress</a> や<a href=\"https://make.wordpress.org/core/\">コア開発ブログ</a>をチェックしてみてください。</p>



<p>WordPress を選んでいただき、ありがとうございます !</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"WordPress 5.2 RC2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://ja.wordpress.org/2019/05/06/wordpress-5-2-rc2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 May 2019 06:45:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5636\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、Josephaが書いた WordPress.org 公式ブログの記事、「WordPress 5.2 R [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3447:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a>が書いた WordPress.org 公式ブログの記事、<a href=\"https://wordpress.org/news/2019/05/wordpress-5-2-rc2/\">「WordPress 5.2 RC 2」</a>を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2 の2つ目のリリース候補が利用可能になりました !</p>



<p>WordPress  5.2は<strong><a href=\"https://make.wordpress.org/core/5-2/\">5月7日 (火)</a></strong><a href=\"https://make.wordpress.org/core/5-2/\"> </a>にリリース予定ですが、そのためには皆さんの手助けが必要です。まだバージョン5.2を試していないなら、今がその時です。</p>



<p>WordPress 5.2リリース候補版をテストする方法は2つあります。<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> プラグインを使うか、<a href=\"https://wordpress.org/wordpress-5.2-RC2.zip\">ここから RC 版 (zip) をダウンロード</a>してください。</p>



<p>WordPress 5.2についての詳細は<a href=\"https://wordpress.org/news/2019/04/wordpress-5-2-release-candidate/\">最初のリリース候補の投稿を御覧ください。</a>(<a href=\"https://ja.wordpress.org/2019/04/29/wordpress-5-2-release-candidate/\">日本語</a>)</p>



<p>このリリースには最終的なアバウトページのデザインが含まれます。また、次の修正が含まれています:</p>



<ul><li>リカバリーモード通知メールの正しい翻訳 (#47093)。</li><li>マルチサイトでのサイトヘルス機能の改善 (#47084)。</li></ul>



<h2>プラグイン・テーマ開発者の方へ</h2>



<p>WordPress 5.2でプラグインとテーマをテストし、readme ファイルの「検証済み最新バージョン」を 5.2に更新してください。互換性の問題を発見した場合は、最終リリース前に解決できるように<a href=\"https://wordpress.org/support/forum/alphabeta/\">サポートフォーラム (英語版)</a> に投稿してください。</p>



<p>大きな変更の詳細に触れた、開発者向けの<a href=\"https://make.wordpress.org/core/2019/04/16/wordpress-5-2-field-guide/\">5.2フィールドガイド</a>も公開しています。</p>



<h2>協力するには</h2>



<p>英語以外の言語を話す方は、<a href=\"https://translate.wordpress.org/projects/wp/dev\">WordPress を100言語以上に翻訳するのにご協力</a>ください !</p>



<p><strong>バグを見つけたと思った場合</strong>は、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta\">アルファ・ベータエリア</a><a href=\"https://ja.wordpress.org/support/forum/alphabeta/\"> (日本語)</a> に投稿できます。情報をお待ちしています。もし再現可能なバグ報告を書ける場合は <a href=\"https://make.wordpress.org/core/reports/\">WordPress Trac に報告</a>してください。<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧はこちら</a>で見ることができます。</p>



<hr class=\"wp-block-separator\" />



<p><em>It’s the start of May<br>and the release is coming.<br>We all give a cheer!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 5.2 リリース候補\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://ja.wordpress.org/2019/04/29/wordpress-5-2-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 29 Apr 2019 05:29:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5630\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、Josephaが書いた WordPress.org 公式ブログの記事、「WordPress 5.2 R [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4355:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a>が書いた WordPress.org 公式ブログの記事、<a href=\"https://wordpress.org/news/2019/04/wordpress-5-2-release-candidate/\">「WordPress 5.2 Release Candidate」</a>を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2の最初のリリース候補版がご利用いただけるようになりました。</p>



<p>これは、WordPress 5.2のリリースが近づいている今、重要なマイルストーンです。「リリース候補版」とは、新しいバージョンをリリースする準備はできたものの、多くのユーザーと数千個のプラグイン・テーマが存在するため、何か足りないものがある可能性もあるということを意味しています。WordPress  5.2は<strong>5月7日 (火)</strong> にリリース予定ですが、そのためには皆さんの手助けが必要です。まだバージョン5.2を試していないなら、今がその時です。</p>



<p>WordPress 5.2リリース候補版をテストする方法は2つあります。<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> プラグインを使うか、<a href=\"https://wordpress.org/wordpress-5.2-RC1.zip\">ここから RC 版 (zip) をダウンロード</a>してください。</p>



<h2>WordPress 5.2に含まれるのは?</h2>



<p>前回のリリースに引き続き、WordPress 5.2ではさらに設定問題や致命的なエラーを特定、修正するためのより強固なツールを提供しています。クライアントを手助けする開発者であれ、ご自分のサイトのみを管理する方であれ、これらのツールは必要なときに正しい情報を手に入れる助けになるでしょう。</p>



<p>サイトヘルスチェックツールと PHP エラープロテクションツールはまったく新しい機能で、もしサイトのプラグインやテーマに関する問題を発見しても安心させてくれます。また、ダッシュボードで使用できるアイコンの更新や、支援技術を使用するすべてのユーザーに対する新しいアクセシビリティへの対応などもあります。</p>



<h2>プラグイン・テーマ開発者の方へ</h2>



<p>WordPress 5.2でプラグインとテーマをテストし、readme ファイルの「検証済み最新バージョン」を 5.2に更新してください。互換性の問題を発見した場合は、最終リリース前に解決できるように<a href=\"https://wordpress.org/support/forum/alphabeta/\">サポートフォーラム (英語版)</a> に投稿してください。</p>



<p>大きな変更の詳細に触れた、開発者向けの<a href=\"https://make.wordpress.org/core/2019/04/16/wordpress-5-2-field-guide/\">5.2フィールドガイド</a>も公開しています。</p>



<h2>協力するには</h2>



<p>英語以外の言語を話す方は、<a href=\"https://translate.wordpress.org/projects/wp/dev\">WordPress を100言語以上に翻訳するのにご協力</a>ください。このリリースが、5.2リリーススケジュールにおける<a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#hard-freeze\">ハードストリングフリーズ</a> (文字列が確定したポイント) のタイミングとなります。</p>



<p><strong>バグを見つけたと思った場合</strong>は、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta\">アルファ・ベータエリア</a><a href=\"https://ja.wordpress.org/support/forum/alphabeta/\"> (日本語)</a> に投稿できます。情報をお待ちしています。もし再現可能なバグ報告を書ける場合は <a href=\"https://make.wordpress.org/core/reports/\">WordPress Trac に報告</a>してください。<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧はこちら</a>で見ることができます。</p>



<hr class=\"wp-block-separator\" />



<p><em>Howdy, RC 1!<br>With tools this interesting,<br>I can hardly wait.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"WordPress 5.2 ベータ 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ja.wordpress.org/2019/04/13/wordpress-5-2-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 13 Apr 2019 03:06:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5610\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、Jonathan Desrosiers が書いた WordPress.org 公式ブログの記事、「Wo [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6421:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a> が書いた WordPress.org 公式ブログの記事、<a href=\"https://wordpress.org/news/2019/04/wordpress-5-2-beta-3/\">「WordPress 5.2 Beta 3」</a>を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2 ベータ 3がリリースされました。</p>



<p>この<strong>ソフトウェアはまだ開発中です</strong>ので、本番サイトで使うことはおすすめしません。新しいバージョンを試すためにテストサイトを立ち上げることを検討してみてください。</p>



<p>WordPress 5.2ベータをテストする方法は2つあります。<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> プラグインを使うか (「最新版ナイトリービルド」を選択)、<a href=\"https://wordpress.org/wordpress-5.2-beta3.zip\">ここから ベータ 版 (zip) をダウンロード</a>してください。</p>



<p>WordPress 5.2は<a href=\"https://make.wordpress.org/core/5-2/\">4月30日</a>にリリースされる予定です。そこにたどり着くために私たちにはみなさんの助けが必要です。<a href=\"https://ja.wordpress.org/2019/04/13/wordpress-5-2-beta-2/\">ベータ2</a>を試した皆さんからのテストやフィードバックに感謝します。あれから<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=04%2F09%2F2019..04%2F13%2F2019&amp;milestone=5.2&amp;group=component&amp;col=id&amp;col=summary&amp;col=status&amp;col=milestone&amp;col=owner&amp;col=type&amp;col=priority&amp;order=priority\">40のチケットがクローズされました。</a>主な変更とバグの修正をご紹介します。</p>



<ul><li>新しいサイトヘルス機能は改善され続けています。</li><li>サポートしていないバージョンの PHP 上で動いているサイトではプラグインがアップデートされなくなりました。(<a href=\"https://core.trac.wordpress.org/ticket/46613\">#46613</a>)</li><li>サイトがリカバリーモードで動いている場合、それがより明確になりました。(<a href=\"https://core.trac.wordpress.org/ticket/46608\">#46608</a>)</li><li>集中ボタンがクラッシクエディターでのキーボードナビゲーションを妨げないようになりました。(<a href=\"https://core.trac.wordpress.org/ticket/46640\">#46640</a>).</li><li>支援技術により管理バーサブメニューでのアナウンスがより良くなりました。 (<a href=\"https://core.trac.wordpress.org/ticket/37513\">#37513</a>).</li><li>WordPress メールの件名がより一貫性を持つようになりました。 (<a href=\"https://core.trac.wordpress.org/ticket/37940\">#37940</a>).</li><li>個人データのエクスポートはユーザーデータのダウンロードが完了したときだけ表示されます。( <a href=\"https://core.trac.wordpress.org/ticket/44644\">#44644</a>).</li><li>アクセシビリティをさらに改善しました (<a href=\"https://core.trac.wordpress.org/ticket/35497\">#35497</a> と <a href=\"https://core.trac.wordpress.org/ticket/42853\">#42853</a>).</li></ul>



<h2>PHP の最低バージョンのアップデート</h2>



<p><strong>重要なお知らせ:</strong> WordPress 5.2ベータ2から、WordPress が必要とする PHP の最低バージョンが5.6.20になります。もし PHP  の古いバージョンで運営している場合は 、WordPress 5.2 が正式にリリースされる前にアップデートすることを強くおすすめします。</p>



<figure class=\"wp-block-embed-wordpress wp-block-embed is-type-wp-embed is-provider-日本語\"><div class=\"wp-block-embed__wrapper\">
<blockquote class=\"wp-embedded-content\" data-secret=\"VZ8A9yLpYF\"><a href=\"https://ja.wordpress.org/2019/04/03/minimum-php-version-update/\">PHP 最低必須バージョンの変更</a></blockquote><iframe title=\"&#8220;PHP 最低必須バージョンの変更&#8221; &#8212; 日本語\" class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" style=\"position: absolute; clip: rect(1px, 1px, 1px, 1px);\" src=\"https://ja.wordpress.org/2019/04/03/minimum-php-version-update/embed/#?secret=VZ8A9yLpYF\" data-secret=\"VZ8A9yLpYF\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>
</div></figure>



<h2>開発者の方へ</h2>



<p>WordPress 5.2 は、WordPress を開発する体験をより洗練されたものにするための変更を数多く含んでいます。遅れないようにするため、<a href=\"https://make.wordpress.org/core/\">Make WordPress Core ブログ</a> を購読し、皆さんのプロダクトに影響を与えうるアップデートや変更に関する<a href=\"https://make.wordpress.org/core/tag/5-1+dev-notes/\">開発者向け文章</a>に特別な注意を払っておいてください。</p>



<h2>協力するには</h2>



<p>英語以外の言語を話す方は、<a href=\"https://translate.wordpress.org/projects/wp/dev\">WordPress を100言語以上に翻訳するのにご協力</a>ください。 ベータ 3 リリースが、5.2 リリースサイクルにおける<a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#soft-freeze\">ソフトストリングフリーズ</a> (文字列がおおむね確定したポイント) のタイミングとなります。</p>



<p><strong>バグを見つけたと思った場合</strong>は、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta\">アルファ・ベータエリア</a><a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">&nbsp;(日本語)</a>&nbsp;に投稿できます。情報をお待ちしています。もし再現可能なバグ報告を書ける場合は&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">WordPress Trac に報告</a>してください。<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧はこちら</a>で見ることができます。</p>



<hr class=\"wp-block-separator\" />



<p><em>Would you look at that<br>each day brings release closer<br>test to be ready</em>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"WordPress 5.2 ベータ2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ja.wordpress.org/2019/04/13/wordpress-5-2-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 13 Apr 2019 02:31:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5605\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、Gary Pendergastが書いた WordPress.org 公式ブログの記事、「WordPre [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5684:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>が書いた WordPress.org 公式ブログの記事、<a href=\"https://wordpress.org/news/2019/04/wordpress-5-2-beta-2/\">「WordPress 5.2 Beta 2」</a>を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2 ベータ 2がリリースされました。</p>



<p>この<strong>ソフトウェアはまだ開発中です</strong>ので、本番サイトで使うことはおすすめしません。新しいバージョンを試すためにテストサイトを立ち上げることを検討してみてください。</p>



<p>WordPress 5.2ベータをテストする方法は2つあります。<a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> プラグインを使うか (「最新版ナイトリービルド」を選択)、<a href=\"https://wordpress.org/wordpress-5.2-beta2.zip\">ここから ベータ 版 (zip) をダウンロード</a>してください。</p>



<p>WordPress 5.2は<a href=\"https://make.wordpress.org/core/5-2/\">4月30日</a>にリリースされる予定です。そこにたどり着くために私たちにはみなさんの助けが必要です。ベータ1を試した皆さんからのテストやフィードバックに感謝します。あれから<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;changetime=2019-03-28..&amp;milestone=5.2&amp;group=component&amp;col=id&amp;col=summary&amp;col=owner&amp;col=type&amp;col=priority&amp;col=component&amp;col=version&amp;order=priority\">100のチケットがクローズされました。</a>主な変更とバグの修正をご紹介します。</p>



<ul><li>Emoji 12のサポートを追加しました! </li><li>新しい <code>wp_body_open()</code> テンプレートタグ (と、それに付随する<code>wp_body_open</code> アクション) により、テーマ (そしてプラグインも) から <code>&lt;body&gt;</code> 開始タグ直後にコンテンツを追加できるようになりました。 (<a href=\"https://core.trac.wordpress.org/ticket/12563\">#12563</a>)</li><li>ダイナミックブロックコンテンツで余計なパラグラフタグが間違って表示されないようになりました。 (<a href=\"https://core.trac.wordpress.org/ticket/45495\">#45495</a>)</li><li>サイトヘルスチェックの画面でバグの修正、微調整、パフォーマンスの向上が行われました。</li><li>クラッシュプロテクションがプラグインの編集を妨げないようになりました。(<a href=\"https://core.trac.wordpress.org/ticket/46045\">#46045</a>).</li><li>カスタムエラーハンドラーが正しく読み込まれるようになりました。 (<a href=\"https://core.trac.wordpress.org/ticket/46069\">#46069</a>).</li></ul>



<h2>PHP の最低バージョンのアップデート</h2>



<p>WordPress 5.2ベータ2から、WordPress が必要とする PHP の最低バージョンが5.6.20になります。もし PHP の古いバージョンで運営している場合は 、WordPress 5.2 が正式にリリースされる前にアップデートすることを強くおすすめします。</p>



<figure class=\"wp-block-embed-wordpress wp-block-embed is-type-wp-embed is-provider-日本語\"><div class=\"wp-block-embed__wrapper\">
<blockquote class=\"wp-embedded-content\" data-secret=\"jnrY1zz3C2\"><a href=\"https://ja.wordpress.org/2019/04/03/minimum-php-version-update/\">PHP 最低必須バージョンの変更</a></blockquote><iframe title=\"&#8220;PHP 最低必須バージョンの変更&#8221; &#8212; 日本語\" class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" style=\"position: absolute; clip: rect(1px, 1px, 1px, 1px);\" src=\"https://ja.wordpress.org/2019/04/03/minimum-php-version-update/embed/#?secret=jnrY1zz3C2\" data-secret=\"jnrY1zz3C2\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>
</div></figure>



<h2>開発者の方へ</h2>



<p>WordPress 5.2 は、WordPress を開発する体験をより洗練されたものにするための変更を数多く含んでいます。遅れないようにするため、<a href=\"https://make.wordpress.org/core/\">Make WordPress Core ブログ</a> を購読し、皆さんのプロダクトに影響を与えうるアップデートや変更に関する<a href=\"https://make.wordpress.org/core/tag/5-1+dev-notes/\">開発者向け文章</a>に特別な注意を払っておいてください。</p>



<h2>協力するには</h2>



<p>英語以外の言語を話す方は、<a href=\"https://translate.wordpress.org/projects/wp/dev\">WordPress を100言語以上に翻訳するのにご協力</a>ください。</p>



<p>バグ<strong>を見つけたと思った場合</strong>は、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta\">アルファ・ベータエリア</a><a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">(日本語)</a>&nbsp;に投稿できます。情報をお待ちしています。もし再現可能なバグ報告を書ける場合は&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">WordPress Trac に報告</a>してください。<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧はこちら</a>で見ることができます。</p>



<hr class=\"wp-block-separator\" />



<p><em>The wonderful thing<br> about betas, is betas<br> are wonderful things.</em> </p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"WordPress 5.2 ベータ1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ja.wordpress.org/2019/04/04/wordpress-5-2-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Apr 2019 08:41:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5572\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"以下は、Josephaが書いた WordPress.org 公式ブログの記事、「WordPress 5.2 B [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"JOTAKI Taisuke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9990:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha</a>が書いた WordPress.org 公式ブログの記事、<a href=\"https://wordpress.org/news/2019/03/wordpress-5-2-beta-1/\">「WordPress 5.2 Beta 1」</a>を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>WordPress 5.2 ベータ 1がリリースされました。</p>



<p>この<strong>ソフトウェアはまだ開発中です</strong>ので、本番サイトで使うことはおすすめしません。新しいバージョンを試すためにテストサイトを立ち上げることを検討してみてください。</p>



<p>WordPress 5.2 ベータ版をテストする方法は2つあります:</p>



<ul><li><a href=\"https://ja.wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a>&nbsp;プラグイン (「最新版ナイトリービルド」を選択 ) を利用する</li><li><a href=\"https://wordpress.org/wordpress-5.2-beta1.zip\">ベータ版の ZIP ファイルをこちらからダウンロードする</a></li></ul>



<p>WordPress 5.2は<a href=\"https://make.wordpress.org/core/5-2/\">4月30日</a>にリリースされる予定です。そこにたどり着くために私たちにはみなさんの助けが必要です。今後数週間でできるだけ多くのバグを見つけることができるよう、以下にテストすべき重要項目の一部を挙げました。</p>



<h2>ブロックエディター</h2>



<p>WordPress 5.1以降、ブロックエディターのパフォーマンスが大幅に向上し、大量の投稿の読み込み時間が35％短縮され、キーを押す時間（入力時の反応の速さ）が半分になりました。</p>



<p>アクセシビリティも向上し続けています。ブロックエディターは、ブラウザの縮小モーション設定をサポートします。投稿URLのスラッグはより良いラベルとヘルプテキストを持っています。ランドマークをナビゲートするキーボードのフォーカススタイルは、より明確で一貫性があります。さまざまな新しい会話メッセージがあり、スクリーンリーダーの動作をより便利にするために既存のメッセージが調整されています。</p>



<p>いくつかの新しいブロックを追加しました。</p>



<ul><li>RSSブロック</li><li>Amazon Kindle埋め込みブロック</li><li>検索ブロック</li><li>カレンダーブロック</li><li>タグクラウドブロック</li></ul>



<p>これらのブロックを追跡し、必要なものだけを表示するために、ブロックのオンとオフを切り替える新しいブロック管理ツールがあります。</p>



<figure class=\"wp-block-image\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2019/03/01-block-manager-1024x768.png?fit=632%2C474&amp;ssl=1\" alt=\"\" class=\"wp-image-6806\" /><figcaption>ブロック管理モーダル</figcaption></figure>



<p>私たちは常に既存のブロックにも取り組んでいます。ブロックエディターには何百ものバグフィックスと改良がほどこされました。グーテンベルグプラグインリリースでそれらについてもっと読むことができます：4.9、5.0、5.1、5.2、および5.3。</p>



<h3>WordPress モバイルアプリ</h3>



<p>ブロックエディターはウェブサイトだけのものでもありません。WordPress モバイルアプリには現在、実験的なバージョンの組み込みのブロックエディターが含まれています。これはまだ開発中ですが、今すぐ試すことができます。</p>



<figure class=\"wp-block-embed-wordpress wp-block-embed is-type-wp-embed is-provider-make-wordpress-mobile\"><div class=\"wp-block-embed__wrapper\">
<blockquote class=\"wp-embedded-content\" data-secret=\"AikCDGVOo4\"><a href=\"https://make.wordpress.org/mobile/2019/02/26/the-block-editor-is-coming-to-the-mobile-apps/\">The block editor is coming to the mobile apps</a></blockquote><iframe title=\"&#8220;The block editor is coming to the mobile apps&#8221; &#8212; Make WordPress Mobile\" class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" style=\"position: absolute; clip: rect(1px, 1px, 1px, 1px);\" src=\"https://make.wordpress.org/mobile/2019/02/26/the-block-editor-is-coming-to-the-mobile-apps/embed/#?secret=AikCDGVOo4\" data-secret=\"AikCDGVOo4\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>
</div></figure>



<h2>サイトヘルスチェック</h2>



<p>サイトヘルスチェックは、WordPress エコシステム全体の安定性とパフォーマンスの向上を目的とした進行中のプロジェクトです。</p>



<p>このプロジェクトの最初のフェーズ（当初は WordPress 5.1を目標としていました）が WordPress 5.2には含まれています。初めに WordPress が問題のあるコードをキャッチして一時停止するので、ダッシュボードにログインして問題が何であるかを確認できます（<a href=\"https://core.trac.wordpress.org/ticket/44458\">#44458</a>）。以前は、ファイルにFTPでアクセスするか、ホストに連絡する必要がありました。</p>



<p>また、ダッシュボードに新しいヘルスチェックツールを追加しています。 <em>ツール</em>メニューにアクセスして<em>ヘルスチェック</em>をクリックすると、サイトの速度とセキュリティを向上させるのに役立つ情報が得られます。</p>



<figure class=\"wp-block-embed-wordpress wp-block-embed is-type-wp-embed is-provider-make-wordpress-core\"><div class=\"wp-block-embed__wrapper\">
<blockquote class=\"wp-embedded-content\" data-secret=\"pWu7mOaVYB\"><a href=\"https://make.wordpress.org/core/2019/03/20/the-improved-fatal-error-protection/\">The Improved Fatal Error Protection</a></blockquote><iframe title=\"&#8220;The Improved Fatal Error Protection&#8221; &#8212; Make WordPress Core\" class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" style=\"position: absolute; clip: rect(1px, 1px, 1px, 1px);\" src=\"https://make.wordpress.org/core/2019/03/20/the-improved-fatal-error-protection/embed/#?secret=pWu7mOaVYB\" data-secret=\"pWu7mOaVYB\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>
</div></figure>



<h2>PHP バージョンバンプ</h2>



<p>このリリースでは、<a href=\"https://make.wordpress.org/core/2018/12/08/updating-the-minimum-php-version/\">WordPress がサポートされる PHP の最低バージョンを5.6に引き上げます</a>。この変更に準備ができているかどうかを確認するため、WordPress 5.2では必要に応じて警告が表示され、PHP のバージョンをアップグレードする手助けをします。</p>



<h2>開発者の皆さんへ</h2>



<ul><li>プラグインがサポートする PHP の最低バージョンを指定できるようになったため、ユーザーのサイトを壊す危険を冒さずに安全に開発方法を現代化することができます。(<a href=\"https://core.trac.wordpress.org/ticket/40934\">#40934</a>)</li><li><code>sodium_compat</code> ライブラリを追加しました。これは、<a href=\"https://blog.zend.com/2018/11/06/modern-cryptography-in-php-7-2-with-sodium/\">PHP 7.2で追加されたSodiumベースの暗号化ライブラリ</a>に対する下位互換性を提供します。 (<a href=\"https://core.trac.wordpress.org/ticket/45806\">#45806</a>)</li><li>ダッシュアイコンの新しいリリースがあります。WordPress ダッシュボードアイコンフォントです。利用できる新しい25のアイコンがあります！ (<a href=\"https://core.trac.wordpress.org/ticket/41074\">#41074</a>)</li><li>アクセシビリティを向上させるために  <code>get_search_form()</code> にラベルを渡せるようになりました 。(<a href=\"https://core.trac.wordpress.org/ticket/42057\">#42057</a>)</li></ul>



<p>WordPress 5.2ではこれまでに<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=5.2&amp;group=resolution&amp;order=priority\">130個のチケットがクローズ</a>され、WordPress の操作性を円滑にするための多数の小さなバグ修正と改良が行われています。</p>



<p>5.2 について開発者が知っておくべきその他の変更の詳細については、今後の数週間 <a href=\"https://make.wordpress.org/core/\">Make WordPress Core ブログ</a> (<code>dev-notes</code>&nbsp;タグが<a href=\"https://make.wordpress.org/core/tag/5-1+dev-notes/\">ついています</a>) をチェックしてみてください。</p>



<h2>協力するには</h2>



<p>英語以外の言語を話す方は、<a href=\"https://translate.wordpress.org/projects/wp/dev\">WordPress を100言語以上に翻訳するのにご協力</a>ください。</p>



<p>バグ<strong>を見つけたと思った場合</strong>は、サポートフォーラムの<a href=\"https://wordpress.org/support/forum/alphabeta\">アルファ・ベータエリア</a><a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">(日本語)</a>&nbsp;に投稿できます。情報をお待ちしています。もし再現可能なバグ報告を書ける場合は&nbsp;<a href=\"https://make.wordpress.org/core/reports/\">WordPress Trac に報告</a>してください。<a href=\"https://core.trac.wordpress.org/tickets/major\">既知のバグ一覧はこちら</a>で見ることができます。</p>



<hr class=\"wp-block-separator\" />



<p><em>With each new release,<br>bearing multiple betas; <br>We fix, then we fly.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"PHP 最低必須バージョンの変更\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://ja.wordpress.org/2019/04/03/minimum-php-version-update/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Apr 2019 01:48:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:7:\"Hosting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ja.wordpress.org/?p=5559\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:154:\"今月末リリース予定の WordPress 5.2 では PHP の最低必須バージョンを更新し、PHP 5.6.20 以降が必須となる見通しです。\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Naoko Takano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4816:\"
<p>以下は、<a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>&nbsp;が書いた WordPress.org 公式ブログの記事、「<a href=\"https://wordpress.org/news/2019/04/minimum-php-version-update/\">Minimum PHP Version update</a>」を訳したものです。</p>



<p>誤字脱字誤訳などありましたら<a href=\"https://ja.wordpress.org/support/forum/alphabeta/\">フォーラムまでお知らせください</a>。</p>



<hr class=\"wp-block-separator\" />



<p>今月末に WordPress 5.2 のリリースを予定していますが、それと同時に PHP の最低必須バージョンを更新します。WordPress には、PHP 5.6.20 以降が必須となります。</p>



<p>WordPress 5.1 から、PHP バージョン 5.6 以下を使っているユーザーの方にはダッシュボードに <a href=\"https://ja.wordpress.org/support/update-php/\">PHP の更新を助ける情報</a>を含む通知が表示されています。以来、<a href=\"https://ja.wordpress.org/about/stats/\">WordPress 統計情報</a>で、より新しいバージョンの PHP を利用するユーザーの増加が確認できるようになりました。</p>



<figure class=\"wp-block-image\"><img src=\"https://ja.wordpress.org/files/2019/04/update-php-notice-1024x388.png\" alt=\"\" class=\"wp-image-5562\" srcset=\"https://ja.wordpress.org/files/2019/04/update-php-notice-1024x388.png 1024w, https://ja.wordpress.org/files/2019/04/update-php-notice-300x114.png 300w, https://ja.wordpress.org/files/2019/04/update-php-notice-768x291.png 768w, https://ja.wordpress.org/files/2019/04/update-php-notice.png 1226w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /><figcaption>古すぎるバージョンの PHP を使っているユーザーに表示される通知</figcaption></figure>



<h2>PHP をアップグレードすべき理由</h2>



<p>お使いのサーバーでサポート対象外バージョンの PHP が稼働している場合、 WordPress 更新ツールは WordPress 5.2 をサイトに提供しません。WordPress を手動で更新しようとした場合、作業は失敗するでしょう。最新の WordPress 機能を使い続けたい場合は PHP をより新しいバージョンにアップグレードする必要があります。</p>



<p>PHP を新しいバージョンにアップグレードする際、WordPress としては推奨バージョンである PHP 7.3 への更新をおすすめしています。PHP internals チームは、最新バージョンがこれまで最速となるようすばらしい努力を重ねてきています。これはつまり、アップグレードを行うことでサイト運営者・訪問者の両方に対してサイトのスピードを改善できるということです。</p>



<p>このパフォーマンス強化はまた、サイトのホスティングに必要なサーバーの数を減らせるということも意味しています。PHP をアップグレードすることは、サイト運営者であるあなたに朗報なだけではなく、<a href=\"https://wordpress.org/news/2019/03/one-third-of-the-web/\">Web 上のサイトの1/3を占める WordPress</a> がこれまでよりも少ない電力を要するため、地球にも優しいということでもあります。</p>



<h2>PHP のアップグレード方法</h2>



<p>新バージョンの PHP にアップグレードするために手助けが必要な方は、詳<a href=\"https://ja.wordpress.org/support/update-php/\">しいドキュメンテーションを利用できます</a>。リンク先のページには、ホスティングサービス (レンタルサーバーなど) へサポートを依頼するために送るメッセージのサンプルも含まれます。多くのホスティングサービスも、各自に特化した&nbsp;<a href=\"https://github.com/WordPress/servehappy-resources/blob/master/tutorials/hosting-specific/tutorials-ja.md\">PHP をアップグレード</a>する方法についての情報を公開しています。</p>



<h2>現在は PHP 5.6、近々 PHP 7 以降へ</h2>



<p>今回、<a href=\"https://wordpress.org/news/2010/07/eol-for-php4-and-mysql4/\">2010年</a>以来初めて WordPress の PHP 必須バージョンを上げることになりますが、これが2019年最後の変更とはならないかもしれません。WordPress コアチームは、年末に PHP 7 以降を最低必須バージョンにすることも視野に入れつつ、最新バージョンの PHP がどれくらい採用されているかを観察していく予定です。</p>



<p><a href=\"https://ja.wordpress.org/support/update-php/\"><strong>PHP のバージョンアップ</a>をして、今後 WordPress のバージョンを更新できるように備えましょう !</strong></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ja.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 27 Sep 2019 15:34:24 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Wed, 18 Jul 2012 08:25:33 GMT\";s:4:\"link\";s:61:\"<https://ja.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `enojr_options` VALUES("139","_transient_timeout_feed_mod_992efac292246ae35bf235a03417a202","1569641664","no");
INSERT INTO `enojr_options` VALUES("140","_transient_feed_mod_992efac292246ae35bf235a03417a202","1569598464","no");
INSERT INTO `enojr_options` VALUES("141","_transient_timeout_feed_6f409681938158427d2ded6eb1b9ea27","1569641665","no");
INSERT INTO `enojr_options` VALUES("142","_transient_feed_6f409681938158427d2ded6eb1b9ea27","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:5:\"

	
	\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:141:\"
		
		
		
		
		
		
		

		
		
					
				

			
				

			
				

			
				

			
				

			
				

			
				

			
				

			
				

			
				

					
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WordPress | サポートフォーラム » 返信一覧\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"https://ja.wordpress.org/support/forums/feed\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 28 Sep 2019 00:34:16 +0900\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"https://bbpress.org/?v=2.6-alpha-6091\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"ja\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"https://ja.wordpress.org/support/topic/all-in-one-wp-migration%e3%81%a7%e4%bd%9c%e6%88%90%e3%81%97%e3%81%9f%e3%82%b5%e3%82%a4%e3%83%88%e3%81%ae%e7%94%bb%e5%83%8f%e3%81%8c%e8%a1%a8%e7%a4%ba%e3%81%95%e3%82%8c%e3%81%aa%e3%81%84/#post-11658728\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"all-in-one-wp-migrationで作成したサイトの画像が表示されない\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"https://ja.wordpress.org/support/topic/all-in-one-wp-migration%e3%81%a7%e4%bd%9c%e6%88%90%e3%81%97%e3%81%9f%e3%82%b5%e3%82%a4%e3%83%88%e3%81%ae%e7%94%bb%e5%83%8f%e3%81%8c%e8%a1%a8%e7%a4%ba%e3%81%95%e3%82%8c%e3%81%aa%e3%81%84/#post-11658728\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 13:40:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1918:\"
						
						<p>お世話になります。<br />
all-in-one-wp-migrationのプラグインを使用して、コピーサイトを作成たのですが、画像だけ表示されません。</p>
<p>コピーサイトは、元サイトのサブドメイン下に設置しています。<br />
画像に関することで、元サイトで指定いていることは、画像のパスを相対パスで指定するよう、function.phpに以下の追記をしました。</p>
<pre><code>function delete_host_from_attachment_url( $url ) {
    $regex = &#039;/^http(s)?:\\/\\/[^\\/\\s]+(.*)$/&#039;;
    if ( preg_match( $regex, $url, $m ) ) {
        $url = $m[2];
    }
    return $url;
}
add_filter( &#039;wp_get_attachment_url&#039;, &#039;delete_host_from_attachment_url&#039; );
add_filter( &#039;attachment_link&#039;, &#039;delete_host_from_attachment_url&#039; );</code></pre>
<p>なぜ画像が表示されないのか確認するために、画像を別タブで開きパスを確認すると、下記のようになっていました。</p>
<p><a href=\"https://motosaite.com/wp-content/uploads/logo.png　←元サイトドメイン\" rel=\"nofollow\">https://motosaite.com/wp-content/uploads/logo.png　←元サイトドメイン</a></p>
<p>↑これが、</p>
<p><a href=\"https://motosaite.com/copy/wp-content/uploads/logo.png　←コピーサイトドメイン\" rel=\"nofollow\">https://motosaite.com/copy/wp-content/uploads/logo.png　←コピーサイトドメイン</a></p>
<p>↑こうなれば、画像は表示されます。</p>
<p>サブドメインが完全に抜け落ちているのだと理解しました。<br />
ただ、このやり方がどうすれば良いのかわかりません。</p>
<p>元サイト・コピーサイトそれぞれ、どの部分をどうすれば実装可能でしょうか？<br />
お知恵をお貸し下さい。<br />
宜しくお願いします。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"mikujin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e3%82%b5%e3%82%a4%e3%83%88%e7%ae%a1%e7%90%86%e8%80%85%e4%bb%a5%e5%a4%96%e3%81%ae%e3%83%a6%e3%83%bc%e3%82%b6%e3%83%bc%e3%81%ae%e3%83%ad%e3%82%b0%e3%82%a2%e3%82%a6%e3%83%88%e6%99%82%e3%81%ae%e4%b8%8d/#post-11658727\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"返信先: サイト管理者以外のユーザーのログアウト時の不具合？\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e3%82%b5%e3%82%a4%e3%83%88%e7%ae%a1%e7%90%86%e8%80%85%e4%bb%a5%e5%a4%96%e3%81%ae%e3%83%a6%e3%83%bc%e3%82%b6%e3%83%bc%e3%81%ae%e3%83%ad%e3%82%b0%e3%82%a2%e3%82%a6%e3%83%88%e6%99%82%e3%81%ae%e4%b8%8d/#post-11658727\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 12:40:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:449:\"
						
						<p>WordPress バージョン 5.2.3 のバグのようです。Windows 環境の場合のみの現象のようです。バージョン 5.2.4 で修正される予定ですが、それまで待てない場合はパッチも作成されているようなので試してみてはと思います。<br />
<a href=\"https://core.trac.wordpress.org/ticket/47980\" rel=\"nofollow\">https://core.trac.wordpress.org/ticket/47980</a></p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"ishitaka\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:253:\"https://ja.wordpress.org/support/topic/%e3%80%8cmw-wp-form%e3%80%8d%e3%81%a7%e8%a4%87%e6%95%b0%e3%81%ae%e3%83%86%e3%82%ad%e3%82%b9%e3%83%88%e9%a0%85%e7%9b%ae%e3%81%a8%e3%83%81%e3%82%a7%e3%83%83%e3%82%af%e3%83%9c%e3%83%83%e3%82%af%e3%82%b9/#post-11658726\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:132:\"返信先: 「mw wp form」でテキスト項目とチェックボックスでどちらかが入力されたら必須判定したい\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:253:\"https://ja.wordpress.org/support/topic/%e3%80%8cmw-wp-form%e3%80%8d%e3%81%a7%e8%a4%87%e6%95%b0%e3%81%ae%e3%83%86%e3%82%ad%e3%82%b9%e3%83%88%e9%a0%85%e7%9b%ae%e3%81%a8%e3%83%81%e3%82%a7%e3%83%83%e3%82%af%e3%83%9c%e3%83%83%e3%82%af%e3%82%b9/#post-11658726\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 12:33:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:276:\"
						
						<p>マルチポスト<br />
<a href=\"https://teratail.com/questions/213639\" rel=\"nofollow\">https://teratail.com/questions/213639</a></p>
<p>どちらでも構いませんがどちらか一方をクローズ（解決済み）してください。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"ishitaka\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://ja.wordpress.org/support/topic/css-grid%e3%82%92%e4%bd%bf%e3%81%a3%e3%81%9f%e6%99%82%e3%81%ab%e3%80%80%e3%82%b5%e3%82%a4%e3%83%88%e8%a1%a8%e7%a4%ba%e3%81%8c%e3%81%aa%e3%81%8f%e3%81%aa%e3%82%8b/#post-11658725\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"返信先: css gridを使った時に　サイト表示がなくなる\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://ja.wordpress.org/support/topic/css-grid%e3%82%92%e4%bd%bf%e3%81%a3%e3%81%9f%e6%99%82%e3%81%ab%e3%80%80%e3%82%b5%e3%82%a4%e3%83%88%e8%a1%a8%e7%a4%ba%e3%81%8c%e3%81%aa%e3%81%8f%e3%81%aa%e3%82%8b/#post-11658725\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 07:25:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:714:\"
						
						<p>とりあえず、開発者ツールで色々と検証してみることをおすすめします。</p>
<p>１つ言えるのは、<code>.container</code>クラスは使用しているテーマ側で使用されていて、<br />
それと競合している可能性があります。<br />
<code>&lt;div id=&quot;container&quot; class=&quot;container wrap cf&quot;&gt;</code></p>
<pre><code>.container {
    padding-right: constant(safe-area-inset-right);
    padding-left: constant(safe-area-inset-left);
    padding-right: env(safe-area-inset-right);
    padding-left: env(safe-area-inset-left);
}</code></pre>
<p>クラスの名前を変更したほうが良さそうです。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"RICK\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658724\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"返信先: 管理画面にて特定のプラグイン管理ページが開かない\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658724\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 06:25:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:662:\"
						
						<p>こんにちは</p>
<p>「<a href=\"https://ja.wordpress.org/support/topic/%E5%95%8F%E9%A1%8C%E8%A7%A3%E6%B1%BA%E3%81%AE%E3%81%9F%E3%82%81%E3%81%AE%E3%83%81%E3%82%A7%E3%83%83%E3%82%AF%E3%83%AA%E3%82%B9%E3%83%88-%E3%83%89%E3%83%A9%E3%83%95%E3%83%88%E7%89%88/\" rel=\"nofollow\">問題解決のためのチェックリスト</a>」は試されたでしょうか？<br />
「問題解決のためのチェックリスト」にも書かれていますが、WordPress の<a href=\"http://wpdocs.osdn.jp/WordPressでのデバッグ#WP_DEBUG\" rel=\"nofollow\">デバッグモード</a>でエラーがないか確認してみてください。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"ishitaka\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658723\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"返信先: 管理画面にて特定のプラグイン管理ページが開かない\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658723\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 06:11:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:164:\"
						
						<p>ありがとうございます。<br />
PHP　バージョン7.1.32<br />
でした。<br />
Query Monitorで確認しました。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"hnoma21\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658722\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"返信先: 管理画面にて特定のプラグイン管理ページが開かない\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658722\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 06:03:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"
						
						<p>「現象２」とあるところから、確認する価値はあるでしょう。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"CG\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658721\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"管理画面にて特定のプラグイン管理ページが開かない\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:252:\"https://ja.wordpress.org/support/topic/%e7%ae%a1%e7%90%86%e7%94%bb%e9%9d%a2%e3%81%ab%e3%81%a6%e7%89%b9%e5%ae%9a%e3%81%ae%e3%83%97%e3%83%a9%e3%82%b0%e3%82%a4%e3%83%b3%e7%ae%a1%e7%90%86%e3%83%9a%e3%83%bc%e3%82%b8%e3%81%8c%e9%96%8b%e3%81%8b/#post-11658721\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 05:40:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1634:\"
						
						<p>突然特定のプラグイン管理ページが開かなくなりました。<br />
エラー：Web サイトはページを表示できません HTTP 500内部エラー</p>
<p>いまわかっているの不具合プラグイン管理では<br />
・SiteGuard<br />
<a href=\"https://アドレス名/wp-admin/admin.php?page=siteguard\" rel=\"nofollow\">https://アドレス名/wp-admin/admin.php?page=siteguard</a></p>
<p>・BackWPup<br />
<a href=\"https://アドレス名/wp-admin/admin.php?page=backwpup\" rel=\"nofollow\">https://アドレス名/wp-admin/admin.php?page=backwpup</a></p>
<p>・Contact Form 7<br />
<a href=\"https://アドレス名/wp-admin/admin.php?page=wpcf7\" rel=\"nofollow\">https://アドレス名/wp-admin/admin.php?page=wpcf7</a></p>
<p>なおどれも一度削除し入れなおしても同様でした。</p>
<p>「現象１」<br />
表示されませんが、動作はしているようです。<br />
例：SiteGuardをインストールすると「ログインページ変更」の通知メールなど届く。<br />
またなぞるとメニューの表示まではされますがその先がエラー表示になります。<br />
「現象２」<br />
なおこれが発生する前に「php5.3なのでphp5.6で動作します」というメッセージ表示があったこともありました。（現在は表示されませんというエラーのみ）</p>
<p>「環境」<br />
・サーバはコアサーバー<br />
・WordPress 5.2.3<br />
・php7.1（バージョンダウン、アップも試し済み</p>
<p>回避方法などよろしくお願いします。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"hnoma21\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:260:\"https://ja.wordpress.org/support/topic/wallstreet%e3%81%ae%e3%83%86%e3%83%bc%e3%83%9e%e3%81%a7%ef%bc%92%e7%82%b9%e8%a7%a3%e6%b1%ba%e3%81%a7%e3%81%8d%e3%81%aa%e3%81%84%e5%95%8f%e9%a1%8c%e3%81%8c%e3%80%81%e3%80%81%e3%80%81%e3%80%82%e5%8a%a9/page/2/#post-11658720\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"返信先: Wallstreetのテーマで２点解決できない問題が、、、。助けてください。\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:260:\"https://ja.wordpress.org/support/topic/wallstreet%e3%81%ae%e3%83%86%e3%83%bc%e3%83%9e%e3%81%a7%ef%bc%92%e7%82%b9%e8%a7%a3%e6%b1%ba%e3%81%a7%e3%81%8d%e3%81%aa%e3%81%84%e5%95%8f%e9%a1%8c%e3%81%8c%e3%80%81%e3%80%81%e3%80%81%e3%80%82%e5%8a%a9/page/2/#post-11658720\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 03:40:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"
						
						<p><a href=\"https://ja.wordpress.org/support/users/ishitaka/\" class=\"mention\" rel=\"nofollow\">@ishitaka</a><br />
了解致しました！<br />
ありがとうございました。</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"adenter\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:55:\"
					
					
					
					
					

					

					
					
				\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://ja.wordpress.org/support/topic/css-grid%e3%82%92%e4%bd%bf%e3%81%a3%e3%81%9f%e6%99%82%e3%81%ab%e3%80%80%e3%82%b5%e3%82%a4%e3%83%88%e8%a1%a8%e7%a4%ba%e3%81%8c%e3%81%aa%e3%81%8f%e3%81%aa%e3%82%8b/#post-11658719\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"css gridを使った時に　サイト表示がなくなる\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:215:\"https://ja.wordpress.org/support/topic/css-grid%e3%82%92%e4%bd%bf%e3%81%a3%e3%81%9f%e6%99%82%e3%81%ab%e3%80%80%e3%82%b5%e3%82%a4%e3%83%88%e8%a1%a8%e7%a4%ba%e3%81%8c%e3%81%aa%e3%81%8f%e3%81%aa%e3%82%8b/#post-11658719\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 Sep 2019 02:11:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9860:\"
						
						<p>wordpress に　elementor のビルドプラグインを入れて、<br />
elementor内にHTMLボックスを配置してリスト作成をしております。</p>
<p>その状態で、wordpressのカスタマイズからcss追加をしているのですが、<br />
カスタマイズ画面上ではCSSの追加でちゃんと表示できているのですが、<br />
いざプレビューを見るとコンテンツが全く表示されていない現状です。</p>
<p>コードとスクショをそれぞれ記載いたします。知識のある方ご教授お願いします。<br />
拙いコードですが、そもそもこっちの方がいいよってのもあれば教えてくださるとありがたいです。</p>
<p>また、gridよりもいい簡単な方法があればとも思っています。<br />
スクショのようなリストができればなんでもいいのですが。。現状色々ググった上でgridにたどり着きました。</p>
<p>CSS&#8212;&#8211;</p>
<p>  body {<br />
      	margin: 0;<br />
      	padding: 0;</p>
<p>      }<br />
      .back {<br />
      	position: fixed;<br />
      	bottom: 10px;<br />
      	right: 10px;</p>
<p>      }<br />
      ul {<br />
				background-color:#000;<br />
			 	margin: 5px;<br />
				padding:0px;<br />
}<br />
      li {<br />
				list-style: none;<br />
				width:23vw;<br />
				text-size-adjust: auto;</p>
<p>}</p>
<p>      .searchList {<br />
				margin-bottom: 20px;<br />
      }<br />
      .searchList li {<br />
      	display: inline-block;<br />
	    }<br />
      .list {<br />
      	overflow: hidden;<br />
      }</p>
<p>      #more {<br />
      	display: none;<br />
      }<br />
      .none {<br />
				display: none;<br />
}</p>
<p> .container{<br />
	display: grid;<br />
	width: 100vw;<br />
	height: 25vh;<br />
	text-align:center;<br />
	 	grid-template-columns: 25 25 25 25;<br />
	grid-template-rows:fr1 fr1 fr1 ;<br />
	grid-template-areas:<br />
		&#8220;title dataplan talkplan price&#8221;<br />
		&#8220;simtype carrir talkapp price&#8221;</p>
<p>}</p>
<p>.plans, .data_volume, .free_talk_type{<br />
	height:15vh;}<br />
.type, .connect_type, .talk_app{<br />
	height:8vh;<br />
	margin:0px;<br />
}</p>
<p>.plans{<br />
	grid-area:title;</p>
<p>	background-color:#f2a9aa;<br />
}<br />
.data_volume{<br />
	grid-area: dataplan;<br />
	background-color:#fff111;<br />
}<br />
.free_talk_type{<br />
	grid-area:talkplan;<br />
	background-color:#111fff;<br />
}<br />
.yenmonth{<br />
	grid-area: price;<br />
	background-color:#fff12a;<br />
}<br />
.connect_type {<br />
	grid-area: carrir;<br />
	background-color:#ffa111;<br />
}<br />
.type{<br />
	grid-area: simtype;<br />
		background-color:#cc77d7;}<br />
.talk_app{<br />
	grid-area:talkapp;<br />
	background-color: #fff1d1;<br />
}<br />
&#8212;&#8212;</p>
<p>html&#8212;<br />
&lt;!DOCTYPE html&gt;<br />
&lt;html lang=&#8221;ja&#8221; dir=&#8221;ltr&#8221;&gt;<br />
  &lt;head&gt;<br />
    &lt;meta charset=&#8221;utf-8&#8243;&gt;<br />
    &lt;title&gt;ピッタリSIM診断&lt;/title&gt;</p>
<p>&lt;script src=&#8221;/path/to/masonry.pkgd.min.js&#8221;&gt;&lt;/script&gt;<br />
&lt;script src=&#8221;http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js&#8221;&gt;&lt;/script&gt;<br />
    &lt;script&gt;<br />
      $(function() {<br />
      	var lists = $(&#8216;.list ul&#8217;);<br />
      	$(document).on(&#8216;change&#8217;, &#8216;.serchBox select&#8217;, function() {<br />
      		lists.show();<br />
      		for (var i = 0; i &lt; $(&#8216;.serchBox select&#8217;).length; i++) {<br />
      			// 絞り込みの項目を取得<br />
      			var item = $(&#8216;.serchBox select&#8217;).eq(i).attr(&#8216;name&#8217;);<br />
      			// 絞り込みの対象を取得<br />
      			var target = $(&#8216;.serchBox select&#8217;).eq(i).val();</p>
<p>      			if(target != &#8221;) {<br />
      				for (var j = 0; j &lt; lists.length; j++) {<br />
      					// 絞り込み対象でない場合は非表示<br />
      					if(!lists.eq(j).find(&#8216;.&#8217; + item).find(&#8216;span&#8217;).hasClass(target)) {<br />
      						lists.eq(j).hide();<br />
      					}<br />
      				};<br />
      			}<br />
      		};<br />
      	});<br />
      });<br />
    &lt;/script&gt;</p>
<p>  &lt;/head&gt;</p>
<p>  &lt;body&gt;<br />
    &lt;div class=&#8221;container&#8221;&gt;<br />
    &lt;header class=&#8221;header&#8221;&gt;&lt;/header&gt;<br />
    &lt;main class=&#8221;main&#8221;&gt;&lt;/main&gt;<br />
    &lt;footer class=&#8221;footer&#8221;&gt;&lt;/footer&gt;<br />
&lt;/div&gt;<br />
    &lt;div class=&#8221;serchBox&#8221;&gt;<br />
      &lt;label class=&#8221;search_label&#8221;&gt;SIMタイプ<br />
      &lt;select name=&#8221;type&#8221;&gt;<br />
        &lt;option value=&#8221;&#8221;&gt;未選択&lt;/option&gt;<br />
        &lt;option value=&#8221;data&#8221;&gt;データのみ&lt;/option&gt;<br />
        &lt;option value=&#8221;talk_data&#8221;&gt;通話+データ&lt;/option&gt;<br />
      &lt;/select&gt;<br />
      &lt;/label&gt;</p>
<p>      &lt;label class=&#8221;search_label&#8221;&gt;無料通話<br />
        &lt;select name=&#8221;free_talk_type&#8221;&gt;<br />
          &lt;option value=&#8221;&#8221;&gt;なし&lt;/option&gt;<br />
          &lt;option value=&#8221;free_talk&#8221;&gt;完全無料&lt;/option&gt;<br />
          &lt;option value=&#8221;10_free_talk&#8221;&gt;10分以内無料&lt;/option&gt;<br />
          &lt;option value=&#8221;20_free_talk&#8221;&gt;10分以上無料&lt;/option&gt;<br />
        &lt;/select&gt;<br />
      &lt;/label&gt;<br />
      &lt;label class=&#8221;search_label&#8221;&gt;データ上限<br />
        &lt;select name=&#8221;data_volume&#8221;&gt;<br />
          &lt;option value=&#8221;&#8221;&gt;未選択&lt;/option&gt;<br />
          &lt;option value=&#8221;2gb&#8221;&gt;〜2GB&lt;/option&gt;<br />
          &lt;option value=&#8221;5gb&#8221;&gt;3〜5GB&lt;/option&gt;<br />
          &lt;option value=&#8221;10gb&#8221;&gt;6〜10GB&lt;/option&gt;<br />
          &lt;option value=&#8221;20gb&#8221;&gt;11〜20GB&lt;/option&gt;<br />
          &lt;option value=&#8221;30gb&#8221;&gt;30GB〜&lt;/option&gt;<br />
        &lt;/select&gt;<br />
      &lt;label class=&#8221;search_label&#8221;&gt;使用回線<br />
        &lt;select name=&#8221;connect_type&#8221;&gt;<br />
          &lt;option value=&#8221;&#8221;&gt;未選択&lt;/option&gt;<br />
          &lt;option value=&#8221;au&#8221;&gt;au回線&lt;/option&gt;<br />
          &lt;option value=&#8221;docomo&#8221;&gt;DOCOMO回線&lt;/option&gt;<br />
          &lt;option value=&#8221;softbank&#8221;&gt;SoftBank回線&lt;/option&gt;<br />
          &lt;option value=&#8221;connect_other&#8221;&gt;その他&lt;/option&gt;<br />
        &lt;/select&gt;<br />
      &lt;/label&gt;</p>
<p>&lt;div class=&#8221;list&#8221;&gt;<br />
  &lt;ul class=&#8221;container&#8221;&gt;<br />
        &lt;li class=&#8221;plans&#8221;&gt;クジラエアー<br />
        &lt;li class=&#8221;data_volume&#8221;&gt;データ量&lt;br&gt;&lt;span class=&#8221;30gb datavolume&#8221;&gt;90GB&lt;/span&gt;<br />
        &lt;li class=&#8221;free_talk_type&#8221;&gt;無料通話&lt;br&gt;&lt;span class=&#8221;freetalk&#8221;&gt;なし&lt;/span&gt;<br />
        &lt;li class=&#8221;yenmonth&#8221;&gt;月額４８６０円<br />
        &lt;li class=&#8221;type&#8221;&gt;SIMタイプ&lt;br&gt;&lt;span class=&#8221;data simtype&#8221;&gt;データのみ&lt;/span&gt;<br />
        &lt;li class=&#8221;connect_type&#8221;&gt;&lt;span class=&#8221;docomo connecttype&#8221;&gt;DOCOMO回線&lt;/span&gt;<br />
        &lt;li class=&#8221;talk_app&#8221;&gt;通話アプリ&lt;span class=&#8221;&#8221;&#8221;apptalk”&gt;&ensp;−&lt;/span&gt;</p>
<p>  &lt;ul class=&#8221;container&#8221;&gt;<br />
        &lt;li class=&#8221;plans&#8221;&gt;クジラモバイルS<br />
        &lt;li class=&#8221;data_volume&#8221;&gt;データ量&lt;br&gt;&lt;span class=&#8221;20gb datavolume&#8221;&gt;20GB&lt;/span&gt;<br />
        &lt;li class=&#8221;free_talk_type&#8221;&gt;無料通話&lt;br&gt;&lt;span class=&#8221;free_talk freetalk&#8221;&gt;24時間無料&lt;/span&gt;<br />
        &lt;li class=&#8221;yenmonth&#8221;&gt;月額４８６０円<br />
        &lt;li class=&#8221;type&#8221;&gt;SIMタイプ&lt;br&gt;&lt;span class=&#8221;talk_data simtype&#8221;&gt;通話+データ&lt;/span&gt;<br />
        &lt;li class=&#8221;connect_type&#8221;&gt;&lt;span class=&#8221;softbank connecttype&#8221;&gt;SoftBank回線&lt;/span&gt;<br />
        &lt;li class=&#8221;talk_app&#8221;&gt;通話アプリ&lt;span class=&#8221;not apptalk&#8221;&gt;なし&lt;/span&gt;</p>
<p>    &lt;ul class=&#8221;container&#8221;&gt;<br />
        &lt;li class=&#8221;plans&#8221;&gt;クジラモバイルD&lt;br&gt;+&lt;br&gt;クジラトーク<br />
        &lt;li class=&#8221;data_volume&#8221;&gt;データ量&lt;br&gt;&lt;span class=&#8221;30gb datavolume&#8221;&gt;30GB&lt;/span&gt;<br />
        &lt;li class=&#8221;free_talk_type&#8221;&gt;無料通話&lt;br&gt;&lt;span class=&#8221;10_free_talk freetalk&#8221;&gt;10分以内無料&lt;/span&gt;<br />
        &lt;li class=&#8221;yenmonth&#8221;&gt;月額５７１０円<br />
        &lt;li class=&#8221;type&#8221;&gt;SIMタイプ&lt;br&gt;&lt;span class=&#8221;talk_data simtype&#8221;&gt;通話+データ&lt;/span&gt;<br />
        &lt;li class=&#8221;connect_type&#8221;&gt;&lt;span class=&#8221;docomo connecttype&#8221;&gt;DOCOMO回線&lt;/span&gt;<br />
        &lt;li class=&#8221;talk_app&#8221;&gt;通話アプリ&lt;span class=&#8221;must apptalk&#8221;&gt;必須&lt;/span&gt;</p>
<p>  &lt;/body&gt;<br />
&lt;/html&gt;<br />
&#8212;&#8212;</p>
<p>スクリーンショット 2019-09-27 11.09.45</p>
						
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"saklab\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:44:\"https://ja.wordpress.org/support/forums/feed\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:7:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 27 Sep 2019 15:34:25 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:12:\"x-robots-tag\";s:15:\"noindex, follow\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `enojr_options` VALUES("143","_transient_timeout_feed_mod_6f409681938158427d2ded6eb1b9ea27","1569641665","no");
INSERT INTO `enojr_options` VALUES("144","_transient_feed_mod_6f409681938158427d2ded6eb1b9ea27","1569598465","no");
INSERT INTO `enojr_options` VALUES("145","_transient_timeout_dash_v2_45827e8e892dd0b85803a110fad8690f","1569641665","no");
INSERT INTO `enojr_options` VALUES("146","_transient_dash_v2_45827e8e892dd0b85803a110fad8690f","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/2019/09/05/wordpress-5-2-3-security-and-maintenance-release/\'>WordPress 5.2.3セキュリティとメンテナンスのリリース</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/support/topic/all-in-one-wp-migration%E3%81%A7%E4%BD%9C%E6%88%90%E3%81%97%E3%81%9F%E3%82%B5%E3%82%A4%E3%83%88%E3%81%AE%E7%94%BB%E5%83%8F%E3%81%8C%E8%A1%A8%E7%A4%BA%E3%81%95%E3%82%8C%E3%81%AA%E3%81%84/#post-11658728\'>all-in-one-wp-migrationで作成したサイトの画像が表示されない</a></li><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/support/topic/%E3%82%B5%E3%82%A4%E3%83%88%E7%AE%A1%E7%90%86%E8%80%85%E4%BB%A5%E5%A4%96%E3%81%AE%E3%83%A6%E3%83%BC%E3%82%B6%E3%83%BC%E3%81%AE%E3%83%AD%E3%82%B0%E3%82%A2%E3%82%A6%E3%83%88%E6%99%82%E3%81%AE%E4%B8%8D/#post-11658727\'>返信先: サイト管理者以外のユーザーのログアウト時の不具合？</a></li><li><a class=\'rsswidget\' href=\'https://ja.wordpress.org/support/topic/%E3%80%8Cmw-wp-form%E3%80%8D%E3%81%A7%E8%A4%87%E6%95%B0%E3%81%AE%E3%83%86%E3%82%AD%E3%82%B9%E3%83%88%E9%A0%85%E7%9B%AE%E3%81%A8%E3%83%81%E3%82%A7%E3%83%83%E3%82%AF%E3%83%9C%E3%83%83%E3%82%AF%E3%82%B9/#post-11658726\'>返信先: 「mw wp form」でテキスト項目とチェックボックスでどちらかが入力されたら必須判定したい</a></li></ul></div>","no");
INSERT INTO `enojr_options` VALUES("147","ftp_credentials","a:3:{s:8:\"hostname\";s:9:\"localhost\";s:8:\"username\";s:8:\"kusanagi\";s:15:\"connection_type\";s:3:\"ftp\";}","yes");
INSERT INTO `enojr_options` VALUES("148","core_updater.lock","1569598942","no");
INSERT INTO `enojr_options` VALUES("150","_site_transient_timeout_available_translations","1569609793","no");
INSERT INTO `enojr_options` VALUES("151","_site_transient_available_translations","a:117:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"5.0.6\";s:7:\"updated\";s:19:\"2019-05-16 12:52:45\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.0.6/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-03 09:40:59\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.11\";s:7:\"updated\";s:19:\"2019-05-14 14:59:20\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.11/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-10 16:44:41\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-23 07:22:14\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:33:\"མུ་མཐུད་དུ།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-24 05:22:45\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-26 14:27:28\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-02 05:01:03\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-03 09:38:07\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-08 20:19:38\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-05 14:26:27\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-19 19:57:19\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.2.3/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-19 19:54:05\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-05 14:24:48\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.2.3/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-22 14:40:13\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-24 10:21:57\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-20 23:50:40\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-25 07:12:29\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-08 16:57:02\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.1.2\";s:7:\"updated\";s:19:\"2019-06-06 15:48:01\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.2/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-20 16:48:55\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-20 20:46:03\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-22 16:47:50\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-23 09:48:06\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.0.6\";s:7:\"updated\";s:19:\"2018-12-07 18:38:30\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.0.6/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:3:\"5.0\";s:7:\"updated\";s:19:\"2018-12-06 21:26:01\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.0/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:6:\"4.9.11\";s:7:\"updated\";s:19:\"2019-05-23 02:23:28\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.11/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-21 11:52:29\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-01 01:18:38\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:9:\"5.0-beta3\";s:7:\"updated\";s:19:\"2018-11-28 16:04:33\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0-beta3/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-13 21:31:06\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-23 10:52:04\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-10 12:52:19\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-20 19:29:21\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-29 15:57:31\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-08 10:46:15\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-20 13:48:04\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-19 14:36:40\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 13:16:13\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-26 16:16:58\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-05 07:28:44\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-02-21 08:17:32\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-21 14:15:57\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-09 07:34:10\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.0.3/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.11\";s:7:\"updated\";s:19:\"2019-05-08 04:00:57\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.11/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-24 13:58:05\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 14:32:44\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.9/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-27 09:34:34\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:6:\"4.7.14\";s:7:\"updated\";s:19:\"2019-05-10 10:24:08\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.14/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-08 12:57:25\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.8.10\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.10/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-30 20:27:25\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-19 07:40:04\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-30 14:24:29\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-15 14:36:38\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.2.3/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-16 11:16:09\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-20 11:47:07\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-07 06:24:50\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-02 07:58:03\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.2.3/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-24 16:57:40\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-02 08:07:52\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-22 05:41:06\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-26 17:19:21\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-15 18:30:22\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-10 14:50:59\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-26 11:40:37\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.3/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-05 08:35:20\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-04 16:57:08\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-24 12:39:42\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-31 10:05:29\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-29 15:44:37\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-17 20:55:48\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.1.2\";s:7:\"updated\";s:19:\"2019-03-31 10:39:40\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.2/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-23 12:32:40\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.0.3/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-06 09:52:01\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-19 04:36:22\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-07-29 00:33:56\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-08-05 12:58:25\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `enojr_options` VALUES("152","new_admin_email","haokexin1214@gmail.com","yes");
INSERT INTO `enojr_options` VALUES("158","_transient_timeout_feed_9bbd59226dc36b9b26cd43f15694c5c3","1569642225","no");
INSERT INTO `enojr_options` VALUES("159","_transient_feed_9bbd59226dc36b9b26cd43f15694c5c3","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"News –  – WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 24 Sep 2019 07:18:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.3-beta1-46334\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 5.3 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2019/09/wordpress-5-3-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Sep 2019 18:36:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7114\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:321:\"WordPress 5.3 Beta 1 is now available! This software is still in development, so we don’t recommend running it on a production site. Consider setting up a test site to play with the new version. You can test the WordPress 5.3 beta in two ways: Try the WordPress Beta Tester plugin (choose the “bleeding edge [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Francesca Marano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9121:\"
<p>WordPress 5.3 Beta 1 is now available!</p>



<p><strong>This software is still in development,</strong> so we don’t recommend running it on a production site. Consider setting up a test site to play with the new version.</p>



<p>You can test the WordPress 5.3 beta in two ways:</p>



<ul><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.3-beta1.zip\">download the beta here</a> (zip).</li></ul>



<p>WordPress 5.3 is slated for release on <a href=\"https://make.wordpress.org/core/5-3/\">November 12, 2019</a>, and we need your help to get there. Here are some of the big items to test, so we can find and resolve as many bugs as possible in the coming weeks.</p>



<h2>Block Editor: features and improvements</h2>



<p>Twelve releases of the Gutenberg plugin are going to be merged into 5.3 which means there’s a long list of exciting new features.&nbsp;</p>



<p>Here are just a few of them:</p>



<ul><li>Group block and grouping interactions</li><li>Columns block improvements (width support + patterns)</li><li>Table block improvements (text alignment support, header/footer support, colors)</li><li>Gallery block improvements (reordering inline, caption support)</li><li>Separator block improvements (color support)</li><li>Latest Posts block improvements (support excerpt, content)</li><li>List block improvements (indent/outdent shortcuts, start value and reverse order support)</li><li>Button block improvements (support target, border radius)</li><li>Animations and micro interactions (moving blocks, dropdowns, and a number of small animations to improve the UX)</li><li>Accessibility Navigation Mode which will allow you to navigate with the keyboard between blocks without going into their content.</li><li>Block Style Variations API</li></ul>



<p>Plus a number of other improvements, amongst them:</p>



<ul><li>Data Module API improvements (useSelect/useEffect)</li><li>Inserter Help Panel</li><li>Extensibility: DocumentSettingsPanel</li><li>Snackbar notices</li><li>Typewriter Experience</li><li>Fix a number of Accessibility report issues</li></ul>



<p>If you want to see all the features for each release, here are direct links to the release posts: <a href=\"https://make.wordpress.org/core/2019/09/19/whats-new-in-gutenberg-18-september/\">6.5</a>, <a href=\"https://make.wordpress.org/core/2019/08/28/whats-new-in-gutenberg-28-august/\">6.4</a>, <a href=\"https://make.wordpress.org/core/2019/08/14/whats-new-in-gutenberg-14-august/\">6.3</a>, <a href=\"https://make.wordpress.org/core/2019/07/31/whats-new-in-gutenberg-31-july/\">6.2</a>, <a href=\"https://make.wordpress.org/core/2019/07/10/whats-new-in-gutenberg-10-july/\">6.1</a>, <a href=\"https://make.wordpress.org/core/2019/06/26/whats-new-in-gutenberg-26th-june/\">6.0</a>, <a href=\"https://make.wordpress.org/core/2019/06/12/whats-new-in-gutenberg-12th-june/\">5.9</a>, <a href=\"https://make.wordpress.org/core/2019/05/29/whats-new-in-gutenberg-29th-may/\">5.8</a>, <a href=\"https://make.wordpress.org/core/2019/05/15/whats-new-in-gutenberg-15th-may/\">5.7</a>, <a href=\"https://make.wordpress.org/core/2019/05/01/whats-new-in-gutenberg-1st-may/\">5.6</a>, <a href=\"https://make.wordpress.org/core/2019/04/17/whats-new-in-gutenberg-17th-april/\">5.5</a>, and <a href=\"https://make.wordpress.org/core/2019/04/03/whats-new-in-gutenberg-3rd-april/\">5.4</a>.</p>



<h3>Continuous effort on performance</h3>



<p>The team working on the block editor managed to shave off 1.5 seconds of loading time for a particularly sizeable post (~ 36,000 words, ~ 1,000 blocks) since WordPress 5.2.</p>



<h2>A new default theme: welcome Twenty Twenty</h2>



<p>WordPress 5.3 introduces <a href=\"https://make.wordpress.org/core/2019/09/06/introducing-twenty-twenty/\">Twenty Twenty</a>, the latest default theme in our project history.&nbsp;</p>



<p>This elegant new theme is based on the WordPress theme <a href=\"https://www.andersnoren.se/teman/chaplin-wordpress-theme/\">Chaplin</a> which was released on the WordPress.org theme directory earlier this summer.&nbsp;</p>



<p>It includes full support for the block editor, empowering users to find the right design for their message.</p>



<h2>Wait! There is more</h2>



<p>5.3 is going to be a rich release with the inclusion of numerous enhancements to interactions and the interface.</p>



<h2>Admin interface enhancements</h2>



<p>Design and Accessibility teams worked together to port some parts of Gutenberg styles into the whole wp-admin interface. Both teams are going to iterate on these changes during the 5.3 beta cycle. These improved styles fix many accessibility issues, improve color contrasts on form fields and buttons, add consistency between editor and admin interfaces, modernize the WordPress color scheme, add better zoom management, and more.</p>



<h3>Big Images are coming to WordPress</h3>



<p>Uploading non-optimized, high-resolution pictures from your smartphone isn’t a problem anymore. WordPress now supports resuming uploads when they fail as well as larger default image sizes. That way pictures you add from the block editor look their best no matter how people get to your site.</p>



<h3>Automatic image rotation during upload</h3>



<p>Your images will be correctly rotated upon upload according to the EXIF orientation. This feature was first proposed nine years ago. Never give up on your dreams to see your fixes land in WordPress!</p>



<h3>Site Health Checks</h3>



<p>The improvements introduced in 5.3 make it easier to identify and understand areas that may need troubleshooting on your site from the Tools -&gt; Health Check screen.</p>



<h3>Admin Email Verification</h3>



<p>You’ll now be periodically asked to check that your admin email address is up to date when you log in as an administrator. This reduces the chance that you’ll get locked out of your site if you change your email address.</p>



<h2>For Developers</h2>



<h3>Time/Date component fixes</h3>



<p>Developers can now work with <a href=\"https://make.wordpress.org/core/2019/09/23/date-time-improvements-wp-5-3/\">dates and timezones</a> in a more reliable way. Date and time functionality has received a number of new API functions for unified timezone retrieval and PHP interoperability, as well as many bug fixes.</p>



<h3>PHP 7.4 Compatibility</h3>



<p>The WordPress core team is actively preparing to support PHP 7.4 when it is released later this year. WordPress 5.3 contains <a href=\"https://core.trac.wordpress.org/query?status=accepted&amp;status=assigned&amp;status=closed&amp;status=new&amp;status=reopened&amp;status=reviewing&amp;keywords=~php74&amp;milestone=5.3&amp;order=priority\">multiple changes</a> to remove deprecated functionality and ensure compatibility. Please test this beta release with PHP 7.4 to ensure all functionality continues to work as expected and does not raise any new warnings. </p>



<h3>Other Changes for Developers</h3>



<ul><li>Multisite<ul><li>Filter sites by status<ul><li><a href=\"https://core.trac.wordpress.org/ticket/37392\">https://core.trac.wordpress.org/ticket/37392</a>&nbsp;</li><li><a href=\"https://core.trac.wordpress.org/ticket/37684\">https://core.trac.wordpress.org/ticket/37684</a>&nbsp;</li></ul></li><li>Save database version in site meta<ul><li><a href=\"https://core.trac.wordpress.org/ticket/41685\">https://core.trac.wordpress.org/ticket/41685</a>&nbsp;</li></ul></li></ul></li><li>Code modernization and PHP 7.4 support<ul><li><a href=\"https://core.trac.wordpress.org/ticket/47678\">https://core.trac.wordpress.org/ticket/47678</a>&nbsp;</li><li><a href=\"https://core.trac.wordpress.org/ticket/47783\">https://core.trac.wordpress.org/ticket/47783</a></li></ul></li><li>Toggle password view<ul><li><a href=\"https://core.trac.wordpress.org/ticket/42888\">https://core.trac.wordpress.org/ticket/42888</a></li></ul></li></ul>



<p>Keep your eyes on the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for more <a href=\"https://make.wordpress.org/core/tag/5-3+dev-notes/\">5.3 related developer notes</a> in the coming weeks detailing other changes that you should be aware of.</p>



<h2>What’s next</h2>



<p>There have been over 400 tickets fixed in WordPress 5.3 so far with numerous bug fixes and improvements to help smooth your WordPress experience.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help us translate WordPress into more than 100 languages</a>!</p>



<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a> where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.<br></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7114\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"People of WordPress: Abdullah Ramzan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2019/09/people-of-wordpress-abdullah-ramzan/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Sep 2019 18:21:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"heropress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:10:\"Interviews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7086\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:391:\"You’ve probably heard that WordPress is open-source software, and may know that it’s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people’s lives for the better. This monthly series shares some of those lesser-known, amazing stories. Meet Abdullah Ramzan, from Lahore, Punjab, Pakistan. Abdullah Ramzan was born and brought [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Yvette Sonneveld\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6788:\"
<p><em>You’ve probably heard that WordPress is open-source software, and may know that it’s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people’s lives for the better. This monthly series shares some of those lesser-known, amazing stories.</em></p>



<h2><strong>Meet Abdullah Ramzan, from Lahore, Punjab, Pakistan.</strong></h2>



<p>Abdullah Ramzan was born and brought up in the under-developed city of <a href=\"https://en.wikipedia.org/wiki/Layyah\"><strong>​Layyah​</strong></a>, which is situated in Southern Punjab, Pakistan and surrounded by desert and the river ​Sindh​.</p>



<p>He graduated from college in his home town and started using a computer in ​2010​ when he joined <a href=\"https://gcuf.edu.pk/\"><strong>​Government College University Faisalabad​</strong></a>. Abdullah’s introduction to WordPress happened while he was finishing the last semester of his degree. His final project was based in WordPress.</p>



<p>Ramzan’s late mother was the real hero in his life, helping him with his Kindergarten homework and seeing him off to school every day.&nbsp;</p>



<p>Before her heart surgery, Ramzan visited her in the hospital ICU, where she hugged him and said: ​“<strong>Don’t worry, everything will be good</strong>.” Sadly, his mother died during her surgery. However, her influence on Ramzan’s life continues.</p>



<h3><strong>Start of Ramzan’s Career:</strong></h3>



<p>After graduation, Ramzan struggled to get his first job. He first joined PressTigers<strong>​</strong> as a Software Engineer and met Khawaja Fahad Shakeel<a href=\"https://twitter.com/FahadShakeel\"><strong>​</strong></a>, his first mentor. Shakeel provided Ramzan with endless support. Something had always felt missing in his life, but he felt like he was on the right track for the first time in his life when he joined the WordPress community.&nbsp;</p>



<h3><strong>Community – WordCamps and Meetups:</strong></h3>



<p>Although Ramzan had used WordPress since ​2015​, attending WordPress meetups and open source contributions turned out to be a game-changer for him. He learned a lot from the WordPress community and platform, and developed strong relationships with several individuals. One of them is <a href=\"https://twitter.com/jainnidhi03\"><strong>​</strong></a>Nidhi Jain​ from Udaipur India who he works with on WordPress development. The second is <a href=\"https://twitter.com/desrosj\"><strong>​</strong></a>Jonathan Desrosiers​ who he continues to learn a lot from.</p>



<p>In addition, Usman Khalid<a href=\"https://twitter.com/Usman__Khalid\"><strong>​</strong></a>, the lead organizer of WC Karachi, mentored Ramzan, helping him to develop his community skills.&nbsp;</p>



<p>With the mentorship of these contributors, Ramzan is confident supporting local WordPress groups and helped to organize ​WordCamp Karachi​, where he spoke for the first time at an international level event. He believes that WordPress has contributed much to his personal identity.&nbsp;</p>



<figure class=\"wp-block-image\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?resize=632%2C422&#038;ssl=1\" alt=\"Abdullah Ramzan among a group of community members at WordCamp Karachi 2018\" class=\"wp-image-7088\" srcset=\"https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?resize=1024%2C683&amp;ssl=1 1024w, https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?resize=300%2C200&amp;ssl=1 300w, https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?resize=768%2C512&amp;ssl=1 768w, https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?w=2048&amp;ssl=1 2048w, https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?w=1264&amp;ssl=1 1264w, https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?w=1896&amp;ssl=1 1896w\" sizes=\"(max-width: 632px) 100vw, 632px\" data-recalc-dims=\"1\" /><figcaption>Abdullah Ramzan at WordCamp Karachi 2018</figcaption></figure>



<h3><strong>WordPress and the Future:</strong></h3>



<p>As a <a href=\"https://www.meetup.com/WordPress-Lahore/members/?op=leaders&amp;sort=name\"><strong>​co-organizer of WordPress Meetup Lahore,​</strong></a> he would love to involve more people in the community leadership team, to provide a platform for people to gather under one roof, to learn and share something with each other. </p>



<p>But he has loftier ambitions. Impressed by <a href=\"https://walktowc.eu/\">Walk to WordCamp Europe</a>, Abdullah is seriously considering walking to WordCamp Asia. He also one day hopes for the opportunity to serve his country as a senator of Pakistan<a href=\"http://www.senate.gov.pk/\"><strong>​</strong></a> and intends to enter the next senate election.</p>



<h3><strong>Words of Encouragement</strong></h3>



<p>Abdullah Ramzan knows there is no shortcut to success. “You have to work hard to achieve your goals,” explained Ramzan. He still has much he wishes to accomplish and hopes to be remembered for his impact on the project.</p>



<p>Abdullah believes WordPress can never die as long as people don’t stop innovating to meet new demands. The beauty of WordPress is that it is made for everyone.</p>



<p>Ramzan encouraged, “If you seriously want to do something for yourself, do something for others first. Go for open source, you’ll surely learn how to code. You’ll learn how to work in a team. Join local meetups, meet with the folks: help them, learn from them, and share ideas.”</p>



<hr class=\"wp-block-separator\" />



<div class=\"wp-block-image\"><figure class=\"alignleft is-resized\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo.jpg?resize=109%2C82&#038;ssl=1\" alt=\"\" class=\"wp-image-7025\" width=\"109\" height=\"82\" srcset=\"https://i1.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo.jpg?w=1024&amp;ssl=1 1024w, https://i1.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo.jpg?resize=300%2C225&amp;ssl=1 300w, https://i1.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo.jpg?resize=768%2C576&amp;ssl=1 768w\" sizes=\"(max-width: 109px) 100vw, 109px\" data-recalc-dims=\"1\" /></figure></div>



<p><em>This post is based on an article originally published on HeroPress.com, a community initiative created by <a href=\"https://profiles.wordpress.org/topher1kenobe/\">Topher DeRosia</a>. HeroPress highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members over at </em><a href=\"https://heropress.com/\"><em>HeroPress.com</em></a><em>!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7086\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 5.2.3 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2019/09/wordpress-5-2-3-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Sep 2019 01:51:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7064\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:368:\"WordPress 5.2.3 is now available! This security and maintenance release features 29 fixes and enhancements. Plus, it adds a number of security fixes—see the list below. These bugs affect WordPress versions 5.2.2 and earlier; version 5.2.3 fixes them, so you&#8217;ll want to upgrade. If you haven&#8217;t yet updated to 5.2, there are also updated versions [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7645:\"
<p>WordPress 5.2.3 is now available! </p>



<p>This security and maintenance release features 29 fixes and enhancements. Plus, it adds a number of security fixes—see the list below.</p>



<p>These bugs affect WordPress versions 5.2.2 and earlier; version 5.2.3 fixes them, so you&#8217;ll want to upgrade. </p>



<p>If you haven&#8217;t yet updated to 5.2, there are also updated versions of 5.0 and earlier that fix the bugs for you.</p>



<h3>Security Updates</h3>



<ul><li>Props to&nbsp;<a href=\"https://blog.ripstech.com/authors/simon-scannell/\">Simon Scannell of RIPS Technologies</a>&nbsp;for finding and disclosing two issues. The first, a cross-site scripting (XSS) vulnerability found in post previews by contributors. The second was a cross-site scripting vulnerability in stored comments.&nbsp;</li><li>Props to&nbsp;<a href=\"https://security-consulting.icu/blog/\">Tim Coen</a>&nbsp;for disclosing an issue where validation and sanitization of a URL could lead to an open redirect.&nbsp;</li><li>Props to Anshul Jain for disclosing reflected cross-site scripting during media uploads.</li><li>Props to&nbsp;<a href=\"https://fortiguard.com/\">Zhouyuan Yang of Fortinet’s FortiGuard Labs</a>&nbsp;who disclosed a vulnerability for cross-site scripting (XSS) in shortcode previews.</li><li>Props to Ian Dunn of the Core Security Team for finding and disclosing a case where reflected cross-site scripting could be found in the dashboard.</li><li>Props to Soroush Dalili (<a href=\"https://twitter.com/irsdl?lang=en\">@irsdl</a>) from NCC Group for disclosing an issue with URL sanitization that can lead to cross-site scripting (XSS) attacks.</li><li>In addition to the above changes, we are also updating jQuery on older versions of WordPress. This change was&nbsp;<a href=\"https://core.trac.wordpress.org/ticket/47020\">added in 5.2.1</a>&nbsp;and is now being brought to older versions.&nbsp;</li></ul>



<p>You can browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.2.3&amp;order=priority\">full list of changes on Trac</a>.</p>



<p>For more info, browse the full list of changes on Trac or check out the Version&nbsp;<a href=\"https://wordpress.org/support/wordpress-version/version-5-2-3/\">5.2.3 documentation page</a>.</p>



<p>WordPress 5.2.3 is a short-cycle maintenance release. The next major release will be&nbsp;<a href=\"https://make.wordpress.org/core/5-3/\">version 5.3.</a></p>



<p>You can download WordPress 5.2.3 from the button at the top of this page, or visit your<strong> Dashboard → Updates</strong> and click <strong>Update Now</strong>. </p>



<p>If you have sites that support automatic background updates, they&#8217;ve already started the update process.</p>



<h2>Thanks and props!</h2>



<p>This release brings together contributions from more than 62 other people. Thank you to everyone who made this release possible!</p>



<p><a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>,&nbsp;<a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>,&nbsp;<a href=\"https://profiles.wordpress.org/alpipego/\">Alex Goller</a>,&nbsp;<a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>,&nbsp;<a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>,&nbsp;<a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>,&nbsp;<a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/762e5e74/\">Ashish Shukla</a>,&nbsp;<a href=\"https://profiles.wordpress.org/wpboss/\">Aslam Shekh</a>,&nbsp;<a href=\"https://profiles.wordpress.org/backermann1978/\">backermann1978</a>,&nbsp;<a href=\"https://profiles.wordpress.org/cdog/\">Catalin Dogaru</a>,&nbsp;<a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>,&nbsp;<a href=\"https://profiles.wordpress.org/aprea/\">Chris Aprea</a>,&nbsp;<a href=\"https://profiles.wordpress.org/christophherr/\">Christoph Herr</a>,&nbsp;<a href=\"https://profiles.wordpress.org/danmicamediacom/\">dan@micamedia.com</a>,&nbsp;<a href=\"https://profiles.wordpress.org/diddledan/\">Daniel Llewellyn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/donmhico/\">donmhico</a>,&nbsp;<a href=\"https://profiles.wordpress.org/iseulde/\">Ella van Durpe</a>,&nbsp;<a href=\"https://profiles.wordpress.org/epiqueras/\">epiqueras</a>,&nbsp;<a href=\"https://profiles.wordpress.org/fencer04/\">Fencer04</a>,&nbsp;<a href=\"https://profiles.wordpress.org/flaviozavan/\">flaviozavan</a>,&nbsp;<a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>,&nbsp;<a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>,&nbsp;<a href=\"https://profiles.wordpress.org/gqevu6bsiz/\">gqevu6bsiz</a>,&nbsp;<a href=\"https://profiles.wordpress.org/thakkarhardik/\">Hardik Thakkar</a>,&nbsp;<a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>,&nbsp;<a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>,&nbsp;<a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>,&nbsp;<a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeffrey Paul</a>,&nbsp;<a href=\"https://profiles.wordpress.org/jikamens/\">jikamens</a>,&nbsp;<a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa,</a> <a href=\"https://profiles.wordpress.org/karlgroves/\">karlgroves</a>,&nbsp;<a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a>,&nbsp;<a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>,&nbsp;<a href=\"https://profiles.wordpress.org/majemedia/\">Maje Media LLC</a>,&nbsp;<a href=\"https://profiles.wordpress.org/mspatovaliyski/\">Martin Spatovaliyski</a>,&nbsp;<a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>,&nbsp;<a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>,&nbsp;<a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nayana123/\">nayana123</a>,&nbsp;<a href=\"https://profiles.wordpress.org/greatislander/\">Ned Zimmerman</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nickdaugherty/\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/rabmalin/\">Nilambar Sharma</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nmenescardi/\">nmenescardi</a>,&nbsp;<a href=\"https://profiles.wordpress.org/bassgang/\">Paul Vincent Beigang</a>,&nbsp;<a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendonça</a>,&nbsp;<a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vjik/\">Sergey Predvoditelev</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sharaz/\">Sharaz Shahid</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sstoqnov/\">Stanimir Stoyanov</a>,&nbsp;<a href=\"https://profiles.wordpress.org/ryokuhi/\">Stefano Minoia</a>,&nbsp;<a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>,&nbsp;<a href=\"https://profiles.wordpress.org/isabel_brison/\">tellthemachines</a>,&nbsp;<a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vaishalipanchal/\">Vaishali Panchal</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vortfu/\">vortfu</a>,&nbsp;<a href=\"https://profiles.wordpress.org/tsewlliw/\">Will West</a>, and&nbsp;<a href=\"https://profiles.wordpress.org/yarnboy/\">yarnboy</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7064\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"The Month in WordPress: August 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2019/09/the-month-in-wordpress-august-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Sep 2019 10:00:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7059\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:374:\"This has been a particularly busy month, with a number of interesting and ambitious proposals for the WordPress project along with active progress across the entire community. Core Development and Schedule The upcoming minor release of WordPress, v5.2.3, is currently in the release candidate phase and available for testing. Following that, the next major release [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9644:\"
<p>This has been a particularly busy month, with a number of interesting and ambitious proposals for the WordPress project along with active progress across the entire community. </p>



<hr class=\"wp-block-separator\" />



<h2>Core Development and Schedule</h2>



<p>The upcoming minor release of WordPress, v5.2.3, is currently <a href=\"https://make.wordpress.org/core/2019/08/22/wordpress-5-2-3-rc-1/\">in the release candidate phase</a> and available for testing.</p>



<p>Following that, the next major release is v5.3 and the Core team has laid out <a href=\"https://make.wordpress.org/core/2019/08/21/wordpress-5-3-schedule-and-scope/\">a schedule and scope</a> for development. In addition, <a href=\"https://make.wordpress.org/core/2019/08/27/bug-scrub-schedule-for-5-3/\">a bug scrub schedule</a> and <a href=\"https://make.wordpress.org/accessibility/2019/08/28/wordpress-5-3-accessibility-focused-bug-scrub-schedule/\">an accessibility-focused schedule</a> have been set out to provide dedicated times for contributors to work on ironing out the bugs in the release.</p>



<p>Want to get involved in building WordPress Core? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Proposal for User Privacy Improvements</h2>



<p>The Core Privacy Team <a href=\"https://make.wordpress.org/core/2019/08/07/feature-plugin-discussion-a-consent-and-logging-mechanism-for-user-privacy/\">has proposed a feature plugin</a> to build a consent and logging mechanism for user privacy. This project will focus on improving the user privacy controls in WordPress Core in order to protect site owners and users alike.</p>



<p>The proposal includes some useful information about building effective controls for users, how other projects have worked on similar efforts, and what kind of time and resources the project will need in order to be developed.</p>



<p>Want to get involved in this feature project? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core-privacy channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a> where there are open office hours every Wednesday at 19:00 UTC.</p>



<h2>Core Notification System Proposal</h2>



<p><a href=\"https://make.wordpress.org/core/2019/08/05/feature-project-proposal-wp-notify/\">A proposal has been made</a> for a new feature project to build a robust notification system for WordPress Core. The aim of the project is to build a system to handle notifications for site owners that can be extended by plugin and theme developers.</p>



<p>This proposal comes on the back of <a href=\"https://core.trac.wordpress.org/ticket/43484\">a Trac ticket</a> opened 18 months ago. With weekly meetings to discuss the project, the team behind WP Notify are <a href=\"https://make.wordpress.org/core/2019/08/28/wp-notify-meeting-recap-august-26-2019/\">in the planning phase</a> while they establish exactly how to develop the feature.<br></p>



<p>Want to get involved in this feature project? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a> &#8211; meetings for this project happen every Monday at 14:00 and 22:00 UTC.</p>



<h2>Local WordPress Development Environment</h2>



<p>Members of the Core Team <a href=\"https://make.wordpress.org/core/2019/08/05/wordpress-local-environment/\">have put together a local development environment for WordPress</a> that runs on Docker. This environment provides an easy way for developers to get involved with WordPress core development. </p>



<p>The work on this was inspired by the environment used for local Gutenberg development, <a href=\"https://make.wordpress.org/core/2019/08/30/gutenberg-local-environment-rewrite/\">which has since been improved</a> based on the new work that has been done here.</p>



<p><a href=\"https://make.wordpress.org/core/2019/08/05/wordpress-local-environment/\">The announcement post</a> explains how to use the Docker environment. If you have any feedback or bug reports, please comment on the post directly.</p>



<h2>Updates for Older Versions of WordPress</h2>



<p>On July 30, the Security Team shared that security updates need to undergo the same testing and release process for every major version of WordPress. This means they have to provide long-term support for over fifteen major versions of WordPress. This requires a lot of time and effort, and <a href=\"https://make.wordpress.org/core/2019/07/29/should-security-fixes-continue-to-be-backported-to-very-old-versions-of-wordpress/\">the team has sought feedback on potential solutions for this challenge</a>. </p>



<p>Following this discussion, <a href=\"https://make.wordpress.org/core/2019/08/07/proposal-auto-update-old-versions-to-4-7/\">a proposal was made to auto-update old versions of WordPress to v4.7</a>. This proposal garnered many responses and has since been updated to incorporate feedback from comments. The current recommendation is to secure the six latest versions and to eventually auto-update all older versions of WordPress to 4.7. Since this proposal was made, it has been discussed at <a href=\"https://make.wordpress.org/hosting/2019/08/26/hosting-meeting-notes-august-19-2019/\">Hosting Team meetings</a> and <a href=\"https://make.wordpress.org/core/2019/08/16/follow-up-discussion-on-major-auto-updates/\">Dev Chat meetings</a>, and the conversation is still ongoing.</p>



<p>Want to provide feedback on this proposal? Comment on <a href=\"https://make.wordpress.org/core/2019/08/07/proposal-auto-update-old-versions-to-4-7/\">the original post</a> with your thoughts.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The recommended minimum PHP version for WordPress Core <a href=\"https://make.wordpress.org/core/2019/08/13/increasing-the-recommended-php-version-in-core/\">has been increased to 7.0</a>.</li><li>Gutenberg development continues at a rapid pace with <a href=\"https://make.wordpress.org/core/2019/08/28/whats-new-in-gutenberg-28-august/\">new updates</a> coming out every month.</li><li>The Core Team is kicking off bug scrub and triage sessions <a href=\"https://make.wordpress.org/core/2019/08/26/apac-triage-and-bug-scrub-sessions/\">at APAC-friendly times</a>.</li><li>WordCamp US announced <a href=\"https://2019.us.wordcamp.org/schedule/\">the event schedule</a> to take place on November 1-3.</li><li>The Plugin Team reminded developers that <a href=\"https://make.wordpress.org/plugins/2019/08/23/reminder-developers-must-comply-with-the-forum-guidelines/\">they need to stick to the Plugin Directory forum guidelines</a> if they choose to use them for support.</li><li>WordPress project leadership is looking at <a href=\"https://make.wordpress.org/updates/2019/07/30/update-sanctions-and-open-source/\">how to respond to political sanctions</a> in light of the open-source nature of the project.&nbsp;</li><li>The Community Team has proposed <a href=\"https://make.wordpress.org/community/2019/08/19/proposal-speaker-feedback-tool/\">a WordCamp speaker feedback tool</a> that will allow more reliable and consistent feedback for WordCamps speakers all over the world.</li><li>The Five for the Future project now has <a href=\"https://make.wordpress.org/updates/2019/08/29/five-for-the-future-proposed-scope-and-mockups/\">more complete mockups</a> and a plan to move forward.</li><li>The Theme Review Team decided to terminate the Trusted Authors program for a number of reasons <a href=\"https://make.wordpress.org/themes/2019/08/14/trusted-author-program-a-year-of-its-journey/\">outlined in the announcement post</a>.</li><li>The Design Team is taking a look at <a href=\"https://make.wordpress.org/design/2019/08/28/discussion-about-the-about-page/\">how they can improve the About page</a> in future WordPress releases.</li><li>This month saw <a href=\"https://make.wordpress.org/cli/2019/08/14/wp-cli-release-v2-3-0/\">the release of v2.3 of WP-CLI</a>, including a number of new commands and improvements.</li><li>WordCamp websites can now make use of <a href=\"https://make.wordpress.org/community/2019/08/19/wordcamp-blocks-are-live/\">custom blocks in the block editor</a> for crafting their content.</li><li>The Mobile Team are looking for testers for the v13.2 release of the <a href=\"https://make.wordpress.org/mobile/2019/08/27/call-for-testing-wordpress-for-android-13-2/\">Android</a> and <a href=\"https://make.wordpress.org/mobile/2019/08/29/call-for-testing-wordpress-for-ios-13-2/\">iOS</a> apps.</li><li>The WordCamp Asia team <a href=\"https://2020.asia.wordcamp.org/2019/08/20/wordcamp-asia-logo-a-design-journey\">published an interesting look</a> at the journey they took to design the event logo.</li><li><a href=\"https://make.wordpress.org/community/2019/08/26/call-for-volunteers-2020-global-sponsorship-working-group/\">A working group of volunteers is being formed</a> to work out the details for the Global Sponsorship Program in 2020.</li><li>In an effort to increase the accessibility of available WordPress themes, the Theme Review Team now requires that <a href=\"https://make.wordpress.org/themes/2019/08/03/planning-for-keyboard-navigation/\">all themes include keyboard navigation</a>.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7059\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"People of WordPress: Amanda Rush\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/08/people-of-wordpress-amanda-rush/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Aug 2019 21:23:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"heropress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:10:\"Interviews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7047\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:373:\"You’ve probably heard that WordPress is open source software, and may know that it’s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people’s lives for the better. This monthly series shares some of those lesser-known, amazing stories. Meet Amanda Rush from Augusta, Georgia, USA. Amanda Rush is a WordPress [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Yvette Sonneveld\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6543:\"
<p><em>You’ve probably heard that WordPress is open source software, and may know that it’s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people’s lives for the better. This monthly series shares some of those lesser-known, amazing stories.</em></p>



<h2><strong>Meet Amanda Rush from Augusta, Georgia, USA.</strong></h2>



<p>Amanda Rush is a WordPress advocate with a visual disability. She first started using computers in 1985, which enabled her to turn in homework to her sighted teachers. Screen reader technology for Windows was in its infancy then, so she worked in DOS almost exclusively.</p>



<p>After graduating high school, Amanda went to college to study computer science, programming with DOS-based tools since compilers for Windows were still inaccessible. As part of her computer science course of study, she learned HTML which began her career in web development.</p>



<h2>How Amanda got started with WordPress</h2>



<p>Amanda began maintaining a personal website, and eventually began publishing her own content using LiveJournal. However, controlling the way the page around her content looked was hard, and she soon outgrew the hosted solution.</p>



<p>So in 2005, Amanda bought customerservant.com, set up a very simple CMS for blogging, and started publishing there. She accepted the lack of design and content, and lack of easy customization because she wasn’t willing to code her own solution. Nor did she want to move to another hosted solution, as she liked being able to customize her own site, as well as publish content.</p>



<h3><strong>Hebrew dates led her to WordPress</strong></h3>



<p>At some point, Amanda was looking for an easy way to display the Hebrew dates alongside the Gregorian dates on her blog entries. Unfortunately, the blogging software she was using at the time, did not offer customization options at that level. She decided to research alternative solutions and came across a WordPress plugin that did just that.&nbsp;</p>



<p>The fact that WordPress would not keep her locked into a visual editor, used themes to customize styling, and offered ways to mark up content, immediately appealed to Amanda. She decided to give it a go.</p>



<h3><strong>Accessibility caused her to dive deeper</strong></h3>



<p>When the software Amanda used at work became completely inaccessible, she started learning about WordPress. While she was learning about this new software, <a href=\"https://en.wikipedia.org/wiki/Web_2.0\">Web 2.0</a> was introduced. The lack of support for it in the screen reader she used meant that WordPress administration was completely inaccessible. To get anything done, Amanda needed to learn to find her way in WordPress’ file structure.</p>



<p>Eventually Amanda started working as an independent contractor for the largest screen reader developer in the market, Freedom Scientific. She worked from home every day and hacked on WordPress after hours.</p>



<p>Unfortunately Amanda hit a rough patch when her job at Freedom Scientific ended. Using her savings she undertook further studies for various Cisco and Red Hat certifications, only to discover that the required testing for these certifications were completely inaccessible. She could study all she wanted, but wasn’t able to receive grades to pass the courses.</p>



<p>She lost her financial aid, her health took a turn for the worse, she was diagnosed with Lupus, and lost her apartment. Amanda relocated to Augusta where she had supportive friends who offered her a couch and a roof over her head.</p>



<h3><strong>But Amanda refused to give up</strong></h3>



<p>Amanda continued to hack WordPress through all of this. It was the only stable part of her life. She wanted to help make WordPress accessible for people with disabilities, and in 2012 joined the&nbsp; WordPress Accessibility Team. Shortly after that, she finally got her own place to live, and started thinking about what she was going to do with the rest of her working life.</p>



<p>Listening to podcasts led her to take part in <a href=\"http://wordsesh.org/\">WordSesh</a>, which was delivered completely online and enabled Amanda to participate without needing to travel. She began to interact with WordPress people on Twitter, and continued to contribute to the community as part of the WordPress Accessibility Team. Things had finally started to pick up.</p>



<h2><strong>Starting her own business</strong></h2>



<p>In 2014, Amanda officially launched her own business, <a href=\"http://www.customerservant.com/\">Customer Servant Consultancy</a>. Since WordPress is open source, and becoming increasingly accessible, Amanda could modify WordPress to build whatever she wanted and not be at the mercy of web and application developers who know nothing about accessibility. And if she got stuck, she could tap into the community and its resources.</p>



<p>Improving her circumstances and becoming more self-sufficient means Amanda was able to take back some control over her life in general. She was able to gain independence and create her own business despite being part of the blind community, which has an 80% unemployment rate.&nbsp;</p>



<p>In her own words:</p>



<blockquote class=\"wp-block-quote\"><p><em>We’re still fighting discrimination in the workplace, and we’re still fighting for equal access when it comes to the technology we use to do our jobs. But the beauty of WordPress and its community is that we can create opportunities for ourselves.</em></p><p><em>I urge my fellow blind community members to join me inside this wonderful thing called WordPress. Because it will change your lives if you let it.</em></p><cite>Amanda Rush, entrepreneur</cite></blockquote>



<hr class=\"wp-block-separator\" />



<div class=\"wp-block-image\"><figure class=\"alignleft is-resized\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo-1.jpg?fit=632%2C474&amp;ssl=1\" alt=\"\" class=\"wp-image-7026\" width=\"110\" height=\"83\" /></figure></div>



<p><em>This post is based on an article originally published on HeroPress.com, a community initiative created by <a href=\"https://profiles.wordpress.org/topher1kenobe/\">Topher DeRosia</a>. HeroPress highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members over at </em><a href=\"https://heropress.com/\"><em>HeroPress.com</em></a><em>!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7047\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"The Month in WordPress: July 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2019/08/the-month-in-wordpress-july-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Aug 2019 09:56:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7040\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:336:\"This month has been characterized by exciting plans and big announcements &#8211; read on to find out what they are and what it all means for the future of the WordPress project. WordCamp Asia Announced The inaugural WordCamp Asia will be in Bangkok, Thailand, on February 21-23, 2020. This will be the first regional WordCamp [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6983:\"
<p>This month has been characterized by exciting plans and big announcements &#8211; read on to find out what they are and what it all means for the future of the WordPress project.</p>



<hr class=\"wp-block-separator\" />



<h2>WordCamp Asia Announced</h2>



<p>The inaugural WordCamp Asia will be in Bangkok, Thailand, on February 21-23, 2020. This will be the first regional WordCamp in Asia and it comes after many years of discussions and planning. You can find more information about the event <a href=\"https://2020.asia.wordcamp.org/\">on their website</a> and subscribe to stay up to date with the latest information.</p>



<p>This is the latest flagship event in the WordCamp program, following WordCamps Europe and US. Tickets <a href=\"https://2020.asia.wordcamp.org/tickets/\">are now on sale</a> and the <a href=\"https://2020.asia.wordcamp.org/call-for-speakers/\">call for speakers</a> is open. Want to get involved in WordCamp Asia? Keep an eye out for volunteer applications, or buy a micro sponsor ticket. You can also join the #wcasia channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a> for updates.</p>



<h2>WordCamp US Planning Continues</h2>



<p>The WordCamp US organizing team is excited to announce some new additions to this year’s WCUS in St. Louis, Missouri, on November 1-3, 2019. The first is that there will be an onsite KidsCamp: child-friendly lessons that introduce your young one(s) to the wonderful world of WordPress.&nbsp; <a href=\"https://2019.us.wordcamp.org/kidscamp/\">You can register your child for KidsCamp here</a>. In addition, free, onsite childcare will be provided at this year’s event &#8211; <a href=\"https://2019.us.wordcamp.org/child-care/\">you can sign up here</a>.</p>



<p>Looking for further ways to get involved? The <a href=\"https://2019.us.wordcamp.org/call-for-volunteers-form/\">call for volunteers is now open</a>. For more information on WordCamp US, <a href=\"https://2019.us.wordcamp.org/\">please visit the event website</a>.</p>



<h2>Exploring Updates to the WordPress User &amp; Developer Survey</h2>



<p>To improve the annual WordPress User &amp; Developer Survey, <a href=\"https://make.wordpress.org/updates/2019/06/28/updates-to-the-wordpress-user-developer-survey/\">a call has been made</a> for updates and additional questions that can help us all better understand how people use WordPress.</p>



<p>To improve the survey, contributor teams are suggesting topics and information that should be gathered to inform contributor work in 2020. Please add your feedback <a href=\"https://make.wordpress.org/updates/2019/06/28/updates-to-the-wordpress-user-developer-survey/\">to the post</a>.</p>



<h2>Gutenberg Usability Testing Continues</h2>



<p>Usability tests for Gutenberg continued through June 2019, and <a href=\"https://make.wordpress.org/test/2019/07/10/gutenberg-usability-testing-for-june-2019/\">insights from three recent videos were published</a> last month. This month’s test was similar to WordCamp Europe’s usability tests, and you can read more about those in the <a href=\"https://make.wordpress.org/test/2019/07/05/wceu-usability-test-results-part-one/\">part one</a> and <a href=\"https://make.wordpress.org/test/2019/07/09/wceu-usability-test-results-part-two/\">part two</a> posts. Please help by watching these videos and sharing your observations as comments on the relevant post.</p>



<p>If you want to help with usability testing, you can also join the #research channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>, or you can write a test script that can be usability tested for Gutenberg.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li><a href=\"https://make.wordpress.org/updates/2019/07/23/proposal-a-wordpress-advisory-board/\">A proposal has been made</a> to put together a nominated WordPress Advisory Board &#8211; this is certainly an exciting development for the project.</li><li>The Design team <a href=\"https://make.wordpress.org/design/2019/06/28/wceu-contribution-day-recap-design-team/\">reported on the work they did</a> at the WordCamp Europe Contributor Day.</li><li>The Theme Review Team <a href=\"https://make.wordpress.org/themes/2019/07/22/theme-sniffer-v1-1-0-and-wpthemereview-v0-2-0-release/\">has released updated versions</a> of their ThemeSniffer tool and coding standards.</li><li>The Security team <a href=\"https://make.wordpress.org/core/2019/07/29/should-security-fixes-continue-to-be-backported-to-very-old-versions-of-wordpress/\">is looking for feedback</a> on whether security fixes should continue to be backported to very old versions of WordPress. </li><li>The Design and Community teams have worked together to come up with <a href=\"https://make.wordpress.org/community/2019/07/29/proposal-clearer-wordcamp-and-wordpress-chapter-meetup-logo-guidelines/\">official guidelines for how WordCamp logos should be designed</a>.</li><li>The Core team has implemented <a href=\"https://make.wordpress.org/core/2019/07/12/php-coding-standards-changes/\">a few changes</a> to the PHP coding standards within WordPress Core.</li><li>The Community Team <a href=\"https://make.wordpress.org/community/2019/07/26/discussion-what-to-do-in-case-of-irreconcilable-differences/\">is looking for feedback</a> on a tough decision that needs to be made regarding the implementation of the licence expectations within the meetup program.</li><li>The Design team <a href=\"https://make.wordpress.org/design/2019/07/11/block-directory-in-wp-admin-concepts/\">has presented some designs</a> for a Block Directory within the WordPress dashboard.</li><li>A recent release of WordPress saw an increase in the minimum required version of PHP &#8211; the Core team is now looking at <a href=\"https://make.wordpress.org/core/2019/07/29/proposal-for-increasing-recommended-php-version-in-wordpress/\">increasing that minimum further</a>.</li><li>The Site Health feature was first introduced in the 5.1 release of WordPress, and at WordCamp Europe this year <a href=\"https://make.wordpress.org/core/2019/07/01/new-core-component-site-health/\">a new Core component for the feature was added to the project structure</a>.</li><li>The Community Team has posted some interesting data regarding <a href=\"https://make.wordpress.org/community/2019/07/29/numbers-in-the-netherlands/\">WordCamps in the Netherlands</a> over the last few years, as well as <a href=\"https://make.wordpress.org/community/2019/07/31/wordcamps-in-2018/\">WordCamps in 2018</a>.</li><li>The WordCamp Europe team <a href=\"https://2019.europe.wordcamp.org/2019/07/15/survey-results/\">released the results of the attendee survey</a> from this year&#8217;s event in Berlin.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7040\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"People of WordPress: Ugyen Dorji\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/07/people-of-wordpress-ugyen-dorji/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jul 2019 17:20:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:9:\"heropress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:10:\"Interviews\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7013\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:386:\"You&#8217;ve probably heard that WordPress is open source software, and may know that it&#8217;s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people&#8217;s lives for the better. This monthly series shares some of those lesser-known, amazing stories. Meet Ugyen Dorji from Bhutan Ugyen lives in Bhutan, a landlocked country [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Aditya Kane\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:7264:\"
<p><em>You&#8217;ve probably heard that WordPress is open source software, and may know that it&#8217;s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people&#8217;s lives for the better. This monthly series shares some of those lesser-known, amazing stories.</em></p>



<h2><strong>Meet Ugyen Dorji from Bhutan</strong></h2>



<p>Ugyen lives in <a href=\"https://en.wikipedia.org/wiki/Bhutan\">Bhutan</a>, a landlocked country situated between two giant neighbors, India to the south and China to the north. He works for ServMask Inc and is responsible for the Quality Assurance process for All-in-One WP Migration plugin. <br><br>He believes in the Buddhist teaching that “the most valuable service is one rendered to our fellow humans,” and his contributions demonstrates this through his WordPress translation work and multi-lingual support projects for WordPress.</p>



<figure class=\"wp-block-image\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?fit=632%2C474&amp;ssl=1\" alt=\"\" class=\"wp-image-7023\" srcset=\"https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?w=1728&amp;ssl=1 1728w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?resize=300%2C225&amp;ssl=1 300w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?resize=768%2C576&amp;ssl=1 768w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?resize=1024%2C768&amp;ssl=1 1024w, https://i2.wp.com/wordpress.org/news/files/2019/07/60340743_2330687777177099_8058690662683377664_o.jpg?w=1264&amp;ssl=1 1264w\" sizes=\"(max-width: 632px) 100vw, 632px\" /><figcaption>Bhutanese contributors to the Dzongkha locale on WordPress Translation Day</figcaption></figure>



<h2><strong>How Ugyen started his career with WordPress</strong></h2>



<p>Back in 2016, Ugyen was looking for a new job after his former cloud company ran into financial difficulties.</p>



<p>During one interview he was asked many questions about WordPress and, although he had a basic understanding of WordPress, he struggled to give detailed answers. After that interview he resolved to develop his skills and learn as much about WordPress as he could.&nbsp;</p>



<p>A few months passed and he received a call from ServMask Inc, who had developed a plugin called All-in-One WP Migration. They offered him a position, fulfilling his wish to work with WordPress full-time. And because of that, Ugyen is now an active contributor to the WordPress community.</p>



<h3><strong>WordCamp Bangkok 2018</strong></h3>



<p>WordCamp Bangkok 2018 was a turning point event for Ugyen. WordCamps are a great opportunity to meet WordPress community members you don’t otherwise get to know, and he was able to attend his first WordCamp through the sponsorship of his company.</p>



<p>The first day of WordCamp Bangkok was a Contributor Day, where people volunteer to work together to contribute to the development of WordPress. Ugyen joined the Community team to have conversations with WordPress users from all over the world. He was able to share his ideas for supporting new speakers, events and organizers to help build the WordPress community in places where it is not yet booming.</p>



<p>During the main day of the event, Ugyen managed a photo booth for speakers, organizers, and attendees to capture their memories of WordCamp.&nbsp;He also got to take some time out to attend several presentations during the conference. What particularly stuck in Ugyen’s mind was learning that having a website content plan has been shown to lead to 100% growth in business development.</p>



<h3>Co-Organizing<strong> Thimphu</strong>&#8216;s <strong>WordPress Meetup</strong></h3>



<p>After attending WordCamp Bangkok 2018 as well as a local Meetup event, Ugyen decided to&nbsp;introduce WordPress to his home country and cities.&nbsp;</p>



<p>As one of the WordPress Translation Day organizers, he realized that his local language, Dzongkha, was not as fully translated as other languages in the WordPress Core Translation. That is when Ugyen knew that he wanted to help build his local community. He organized Thimphu’s first WordPress Meetup to coincide with WordPress Translation Day 4, and it was a huge success!</p>



<p>Like all WordPress Meetups, the Thimpu WordPress Meetup is an easygoing, volunteer-organized, non-profit meetup which covers everything related to WordPress. But it also keeps in mind the <a href=\"https://en.wikipedia.org/wiki/Gross_National_Happiness\">Bhutanese Gross National Happiness</a> four pillars by aiming to preserve and promote their unique culture and national language.&nbsp;</p>



<h2><strong>Big dreams get accomplished one step at a time</strong></h2>



<p>Ugyen has taken an active role in preserving his national language by encouraging his community to use WordPress, including Dzongkha bloggers, online Dzongkha news outlets, and government websites.</p>



<p>And while Ugyen has only been actively involved in the community for a short period, he has contributed much to the WordPress community, including:</p>



<ul><li>becoming a Translation Contributor for WordPress Core Translation for Dzongkha;</li><li>participating in the <a href=\"https://wptranslationday.org/\">Global WordPress Translation Day 4</a> Livestream and organizing team;</li><li>inviting WordPress Meetup Thimphu members and WordPress experts from other countries to join the <a href=\"https://wpbhutan.slack.com/\">local Slack instance</a>;</li><li>encouraging ServMask Inc. to become an event sponsor;</li><li>providing the Dzongkha Development Commission the opportunity to involve their language experts.</li></ul>



<p>When it comes to WordPress, Ugyen particularly focuses on encouraging local and international language WordPress bloggers;&nbsp;helping startups succeed with WordPress;&nbsp;and sharing what he has learned from WordPress with his Bhutanese WordPress community.</p>



<p>As a contributor, Ugyen hopes to accomplish even more for the Bhutan and Asian WordPress Communities. His dreams for his local community are big, including teaching more people about open source, hosting a local WordCamp, and helping to organize WordCamp Asia in 2020 &#8212; all while raising awareness of his community.</p>



<hr class=\"wp-block-separator\" />



<div class=\"wp-block-image\"><figure class=\"alignleft is-resized\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo-1.jpg?fit=632%2C474&amp;ssl=1\" alt=\"\" class=\"wp-image-7026\" width=\"110\" height=\"83\" /></figure></div>



<p><em>This post is based on an article originally published on HeroPress.com, a community initiative created by <a href=\"https://profiles.wordpress.org/topher1kenobe/\">Topher DeRosia</a>. HeroPress highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members over at </em><a href=\"https://heropress.com/\"><em>HeroPress.com</em></a><em>!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7013\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"The Month in WordPress: June 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wordpress.org/news/2019/07/the-month-in-wordpress-june-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jul 2019 10:07:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7009\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"June has certainly been a busy month in the WordPress community — aside from holding the largest WordPress event ever, the project has hit a number of significant milestones and published some big announcements this past month. A Wrap for WordCamp Europe 2019 WordCamp Europe 2019 took place on June 20-22. It was the largest [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:8174:\"
<p>June has certainly been a busy month in the WordPress community — aside from holding the largest WordPress event ever, the project has hit a number of significant milestones and published some big announcements this past month.</p>



<hr class=\"wp-block-separator\" />



<h2>A Wrap for WordCamp Europe 2019</h2>



<p>WordCamp Europe 2019 took place on June 20-22. It was the largest WordPress event ever, with 3,260 tickets sold and 2,734 attendees. The attendees came from 97 different countries and 1,722 of them had never attended WordCamp Europe before.</p>



<p>The event featured 60 speakers who delivered talks and workshops on a variety of topics over two conference days, most notably <a href=\"https://profiles.wordpress.org/matt/\">Matt Mullenweg</a>’s keynote that included an update on the current status of WordPress Core development, along with a lively Q&amp;A session. The full session from the live stream is <a href=\"https://youtu.be/UE18IsncB7s?t=13033\">available to watch online</a>.</p>



<p>For its eighth year, <a href=\"https://2019.europe.wordcamp.org/2019/06/25/wordcamp-europe-2020/\">WordCamp Europe will take place in Porto, Portugal</a>. The 2020 edition of the event will be held on June 4-6. If you would like to get involved with WordCamp Europe next year, fill out <a href=\"https://2020.europe.wordcamp.org/2019/06/22/call-for-organisers/\">the organizer application form</a>.&nbsp;</p>



<h2>Proposal for XML Sitemaps in WordPress Core</h2>



<p><a href=\"https://make.wordpress.org/core/2019/06/12/xml-sitemaps-feature-project-proposal/\">A proposal this month</a> suggested bringing XML sitemap generation into WordPress Core. This is a feature that has traditionally been handled by plugins, which has resulted in many different implementations across different sites. It also means that many sites do not have XML sitemaps, which can be a problem because they are hugely important to having your site correctly indexed by search engines.</p>



<p>The proposal details how core sitemaps would be structured and how the team would build them, as well as what aspects of WordPress would not be considered appropriate information to be included.</p>



<p>Want to get involved in building this feature? Comment on <a href=\"https://make.wordpress.org/core/2019/06/12/xml-sitemaps-feature-project-proposal/\">the proposal</a>, follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Translation Milestone for the Spanish Community</h2>



<p><a href=\"https://twitter.com/wp_es/status/1138015568563441665\">The WordPress community of Spain has worked hard</a> to make <a href=\"https://translate.wordpress.org/locale/es/\">the es_ES locale</a> the first in the world to fully localize all of WordPress Core along with all Meta projects, apps, and the top 200 plugins. This is made possible by having the largest translation team out of any locale, consisting of 2,951 individual contributors.</p>



<p>Want to get involved in translating WordPress into our locale? Find your locale on <a href=\"https://translate.wordpress.org/\">the translation platform</a>, follow <a href=\"https://make.wordpress.org/polyglots/\">the Polyglots team blog</a>, and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>WordPress 5.2.2 Maintenance Release</h2>



<p>On June 18, <a href=\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\">v5.2.2 of WordPress was released</a> as a maintenance release, fixing 13 bugs and improving the Site Health feature that was first published in v5.2. If your site has not already been automatically updated to this version, you can <a href=\"https://wordpress.org/download/\">download the update</a> or manually check for updates in your WordPress dashboard. Thanks to <a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, and <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a> for co-leading this release, as well as the 30 other individuals who contributed to it.</p>



<p>Want to get involved in building WordPress Core? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Full End to End Tests for WordPress Core</h2>



<p>On June 27, <a href=\"https://make.wordpress.org/core/2019/06/27/introducing-the-wordpress-e2e-tests/\">e2e (end to end) testing was introduced</a> to WordPress and included in the continuous integration pipeline. E2e testing, which has been successfully used by Gutenberg, is used to simulate real user scenarios and validate process flows. Currently, the setup requires <a href=\"https://docs.docker.com/install/\">Docker</a> to run, and a number of e2e test utilities are already available in the&nbsp; <a href=\"https://github.com/WordPress/gutenberg/tree/master/packages/e2e-test-utils/src\">@wordpress/e2e-test-utils</a> package, in the Gutenberg repository.&nbsp;</p>



<p>Want to use this feature? The more tests that are added, the more stable future releases will be! Follow the <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core-js channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Feature Packages from the Theme Review Team</h2>



<p>Following a <a href=\"https://make.wordpress.org/themes/2019/06/07/proposal-theme-feature-repositories/\">proposal for theme feature repositories</a>, an <a href=\"https://make.wordpress.org/themes/2019/06/24/feature-packages-update/\">update to the features package was announced</a>. Two new packages have been created that require code review and testing. The first is an Autoload Package, a foundational package for theme developers who are not currently using Composer (although <a href=\"https://getcomposer.org/\">Composer</a> is recommended instead of this package). The second is a Customizer Section Button Package that allows theme authors to create a link/button to any URL.</p>



<p>There are other proposed ideas for packages that require feedback and additional discussion. Want to add your suggestions and thoughts? Join the conversation on the <a href=\"https://make.wordpress.org/themes/2019/06/24/feature-packages-update/\">Theme Review team blog</a> and join the #themereview channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>Development continues on the Gutenberg project, with <a href=\"https://make.wordpress.org/core/2019/06/26/whats-new-in-gutenberg-26th-june/\">the latest release</a> including layouts for the Columns block, Snackbar notices, markup improvements, and accessibility upgrades.</li><li>The Community team <a href=\"https://make.wordpress.org/community/2019/06/26/wordcamp-europe-2019-recap-of-community-team-activities-at-contributor-day-plans-for-the-future/\">published the results of their work</a> at the WordCamp Europe contributor day.</li><li>The Polyglots team <a href=\"https://make.wordpress.org/polyglots/2019/06/26/proposal-for-handling-pte-requests/\">has put together a proposal</a> for a new way to handle PTE requests.</li><li>This year’s recipient of the Kim Parsell Memorial Scholarship for WordCamp US <a href=\"https://wordpressfoundation.org/2019/2019-kim-parsell-memorial-scholarship-recipient-carol-gann/\">is Carol Gann</a>.</li><li>The Amurrio WordPress community <a href=\"http://wpamurrio.es/wordpress-amurrio-mega-meetup-i-edition/\">hosted their first “mega meetup”</a> &#8211; this is a great event format that bridges the gap between regular meetup event and WordCamp.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"7009\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WordPress 5.2.2 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2019/06/wordpress-5-2-2-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Jun 2019 18:14:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6993\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:348:\"WordPress 5.2.2 is now available! This maintenance release fixes 13 bugs and adds a little bit of polish to the Site Health feature&#160;that made its debut in 5.2. For more info, browse the&#160;full list of changes on Trac or check out the Version 5.2.2 documentation page. WordPress 5.2.2 is a short-cycle maintenance release. The next [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Mary Baum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3961:\"
<p>WordPress 5.2.2 is now available! This maintenance release fixes 13 bugs and adds a little bit of polish to the Site Health feature&nbsp;<a href=\"https://wordpress.org/news/2019/05/jaco/\">that made its debut in 5.2</a>. </p>



<p>For more info, browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&amp;resolution=fixed&amp;milestone=5.2.2&amp;order=priority\">full list of changes on Trac</a> or check out <a href=\"https://wordpress.org/support/wordpress-version/version-5-2-2/\">the Version 5.2.2 documentation page.</a></p>



<p>WordPress 5.2.2 is a short-cycle maintenance release. The next major release will be version 5.3; check <a href=\"https://make.wordpress.org/core/\">make.wordpress.org/core</a> for details as they happen.  </p>



<p>You can&nbsp;download&nbsp;<a href=\"https://wordpress.org/download/\">WordPress 5.2.2</a>&nbsp;or visit&nbsp;<strong>Dashboard → Updates</strong>&nbsp;and click&nbsp;<strong>Update Now</strong>. Sites that support automatic background updates have already started to update automatically.</p>



<p><a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a> and <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a> co-led this release, with invaluable guidance from our Executive Director, Josepha Haden Chomphosy, and contributions from 30 other contributors. Thank you to everyone who made this release possible!</p>



<p><a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/jankimoradiya/\">Janki Moradiya</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jitendrabanjara1991/\">jitendrabanjara1991</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>, <a href=\"https://profiles.wordpress.org/immeet94/\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">palmiak</a>, <a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendonça</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly/\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shashank3105/\">Shashank Panchal</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">vaishalipanchal</a>, <a href=\"https://profiles.wordpress.org/vrimill/\">vrimill</a>, and <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6993\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:48:\"
		
		
				
		
				

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:4:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"The Month in WordPress: May 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/06/the-month-in-wordpress-may-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Jun 2019 10:21:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Month in WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=6987\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:319:\"This month saw the 16th anniversary since the launch of the first release of WordPress. A significant milestone to be sure and one that speaks to the strength and stability of the project as a whole. In this anniversary month, we saw a new major release of WordPress, some exciting new development work, and a [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:6602:\"
<p>This month saw the 16th anniversary since <a href=\"https://wordpress.org/news/2003/05/wordpress-now-available/\">the launch of the first release of WordPress</a>. A significant milestone to be sure and one that speaks to the strength and stability of the project as a whole. In this anniversary month, we saw a new major release of WordPress, some exciting new development work, and a significant global event.</p>



<hr class=\"wp-block-separator\" />



<h2>Release of WordPress 5.2</h2>



<p>WordPress 5.2 “Jaco” <a href=\"https://wordpress.org/news/2019/05/jaco/\">was released on May 7</a> shipping some useful site management tools, such as the Site Health Check and PHP Error Protection, as well as a number of accessibility, privacy, and developer updates. You can read <a href=\"https://make.wordpress.org/core/2019/04/16/wordpress-5-2-field-guide/\">the field guide for this release</a> for more detailed information about what was included and how it all works.<br></p>



<p>327 individual volunteers contributed to the release. If you would like to be a part of that number for future releases, follow <a href=\"https://make.wordpress.org/core\">the Core team blog</a> and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>A Successful WordPress Translation Day 4</h2>



<p>WordPress Translation Day is a 24-hour event organised by <a href=\"https://make.wordpress.org/polyglots/\">the Polyglots team</a> where community members from all over the world come together to translate WordPress into their local languages. For the fourth edition held on 11 May, 183 brand new contributors joined the Polyglots team from 77 communities across 35 countries in Africa, Asia, Europe, North America, South America, and Oceania.<br></p>



<p>While the WP Translation Day is a great time for focussed contributions to localizing WordPress, but these contributions can happen at any time of the year, so if you would like to help make WordPress available in your local language, follow <a href=\"https://make.wordpress.org/polyglots\">the Polyglots team blog</a> and join the #polyglots channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Updated Plugin Guidelines Proposal</h2>



<p>The Plugins team <a href=\"https://make.wordpress.org/plugins/2019/05/14/proposal-to-modify-plugin-guidelines/\">has proposed some updates</a> to the guidelines for developers on the Plugin Directory. The majority of the proposed changes are intended to address significant issues faced by developers who do not speak English as a first language, making the Plugin DIrectory a more accessible and beneficial place for everyone.<br></p>



<p>The proposal will be open for comments until late June, so the community is encouraged to get involved with commenting on them and the direction they will take the Plugin Directory. If you would like to be involved in this discussion, comment on <a href=\"https://make.wordpress.org/plugins/2019/05/14/proposal-to-modify-plugin-guidelines/\">the proposal</a> and join the #plugin review team in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Continued Gutenberg Development</h2>



<p>Since the block editor was first released as part of WordPress Core in v5.0, development has continued in leaps and bounds with a new release every two weeks. <a href=\"https://make.wordpress.org/core/2019/05/29/whats-new-in-gutenberg-29th-may/\">The latest update</a> includes some great incremental improvements that will be merged into the 5.2.2 release of WordPress along with the other recent enhancements.<br></p>



<p>In addition to the editor enhancements, work has been ongoing in the Gutenberg project to bring the block editing experience to the rest of the WordPress dashboard. This second phase of the project has been going well and <a href=\"https://make.wordpress.org/design/2019/05/31/gutenberg-phase-2-friday-design-update-20/\">the latest update</a> shows how much work has been done so far.<br></p>



<p>In addition to that, the Block Library project that aims to bring a searchable library of available blocks right into the editor is deep in the planning phase with <a href=\"https://make.wordpress.org/design/2019/05/28/block-library-initial-explorations/\">a recent update</a> showing what direction the team is taking things.<br></p>



<p>If you would like to get involved in planning and development of Gutenberg and the block editor, follow the <a href=\"https://make.wordpress.org/core/\">Core</a> and <a href=\"https://make.wordpress.org/design/\">Design</a> team blogs and join the #core, #design, and #core-editor channels in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The 5.2.2 release of WordPress <a href=\"https://make.wordpress.org/core/2019/05/28/5-2-2-release-agenda/\">is currently in development</a> with a planned release date of 13 June.</li><li>Version 2.1.1 of the WordPress Coding Standards <a href=\"https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/releases/tag/2.1.1\">has been released</a> containing seven small, but relevant fixes.</li><li>The Theme Review Team <a href=\"https://make.wordpress.org/themes/2019/05/07/trusted-authors-changes/\">have updated the details</a> of how the Trusted Authors Program works.</li><li><a href=\"https://make.wordpress.org/community/2019/05/29/who-wants-to-test-the-new-wordcamp-blocks/\">WordCamp-specific blocks have been launched for WordCamp sites</a> with organizers needing to sign up in order to test them out.</li><li>Continuing the growing trend of other platforms adopting the Gutenberg editor, it has now <a href=\"https://octobercms.com/plugin/reazzon-gutenberg\">been ported to a plugin for OctoberCMS</a>.</li><li>Version 3.0 of the popular WordPress development environment, Varying Vagrant Vagrants (VVV), <a href=\"https://varyingvagrantvagrants.org/blog/2019/05/15/vvv-3-0-0.html\">was released this month</a>.</li><li>The Community Team <a href=\"https://make.wordpress.org/community/2019/05/31/the-4-gets-in-wordpress-community-organizing/\">published some info</a> clarifying what organizers get (and don’t get) from being involved with their local communities. </li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em><br></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:7:\"post-id\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"6987\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:30:\"com-wordpress:feed-additions:1\";a:1:{s:4:\"site\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"14607090\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 27 Sep 2019 15:43:44 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Tue, 24 Sep 2019 07:18:19 GMT\";s:4:\"link\";s:63:\"<https://wordpress.org/news/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `enojr_options` VALUES("160","_transient_timeout_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1569642225","no");
INSERT INTO `enojr_options` VALUES("161","_transient_feed_mod_9bbd59226dc36b9b26cd43f15694c5c3","1569599025","no");
INSERT INTO `enojr_options` VALUES("162","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1569642226","no");
INSERT INTO `enojr_options` VALUES("163","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: Gatsby Raises $15M, Plans to Invest More Heavily in WordPress and CMS Integrations\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94300\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"https://wptavern.com/gatsby-raises-15m-plans-to-invest-more-heavily-in-wordpress-and-cms-integrations\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5857:\"<p><a href=\"https://www.gatsbyjs.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Gatsby Inc</a>. CEO Kyle Mathews announced a <a href=\"https://www.gatsbyjs.org/blog/2019-09-26-announcing-gatsby-15m-series-a-funding-round/\" rel=\"noopener noreferrer\" target=\"_blank\">$15M Series A funding round</a> today, just one year after creating the company with GatsbyJS core contributors. The open source Gatsby project started in 2015 to provide a framework for developers to quickly build websites with React. As the project soared in popularity, Mathews formed a company to fund its ongoing development and further invest in the growing Gatsby ecosystem of products.</p>
<p>This round of funding will enable Gatsby to grow its 35-person team while investing in open source and cloud services that complement the company&#8217;s products.</p>
<p>&#8220;With Gatsby, we’re striving to create a business model that will drive many millions of dollars of investment in open-source tools and enable people to build the next generation of web experiences,&#8221; Mathews said.</p>
<p>At the forefront of the company&#8217;s vision is the idea of &#8220;reinventing website development.&#8221; Gatsby has popularized the concept of a “<a href=\"https://www.gatsbyjs.org/blog/2018-10-04-journey-to-the-content-mesh/\" rel=\"noopener noreferrer\" target=\"_blank\">content mesh</a>,” a platform that provides the infrastructure layer for a decoupled website and reimagines the role of a CMS within this architecture.</p>
<p>Gatsby&#8217;s goal of creating more integrations for CMS&#8217;s was a big part of Mathews&#8217; funding announcement. Instead of writing off LAMP stack architecture as slow and obsolete, Gatsby is creating bridges to the CMS&#8217;s that power a large portion of the web:</p>
<blockquote><p>Instead of a monolithic CMS powering everything, Gatsby ties together specialized services with a modern development experience and optimized website delivery.</p>
<p>This content mesh empowers developers while preserving content creators’ workflows. It gives developers access to great cloud services without the pain of manual integration.</p>
<p>Web developers from dozens of web CMS communities like WordPress and Drupal are going “headless” and using Gatsby as the presentation layer for their CMS.</p>
<p>We’re forming partnerships with these communities to create seamless integrations between their solutions and Gatsby.</p></blockquote>
<p>Gatsby will be using some of its funding to invest more heavily in the WordPress ecosystem. The company hired <a href=\"https://wptavern.com/jason-bahl-joins-the-gatsby-team-to-work-on-wpgraphql-full-time\" rel=\"noopener noreferrer\" target=\"_blank\">hiring Jason Bahl</a>, creator of the GraphQL for WordPress project, in June, and plans to add more WordPress developers.</p>
<p>&#8220;We recently hired someone else to work alongside Jason in developing WPGraphQL (announcement coming soon!) and are currently hiring for several roles on the team,&#8221; Mathews told the Tavern.</p>
<p>WordPress powers <a href=\"https://w3techs.com/technologies/details/cm-wordpress/all/all\" rel=\"noopener noreferrer\" target=\"_blank\">34.6% of the top 10 million websites</a> and Matt Mullenweg has previously estimated its ecosystem to be a $10 billion industry. The CMS is <a href=\"https://joost.blog/cms-market-share-a-numbers-analysis/\" rel=\"noopener noreferrer\" target=\"_blank\">showing no signs of decline</a>, and is a market that Gatsby product developers are strategically targeting.</p>
<p>WordPress adopted React as its JavaScript framework in 2017, and built its new Gutenberg editor on top of it. Although some early adopters began digging deeper into React and creating their own products with it, the majority of PHP developers have been slow to move in that direction. Gatsby provides a bridge for those who are just getting started.</p>
<p>&#8220;We think that for many web developers, a Gatsby project may be the first time they are using React, GraphQL, webpack or even Node.js,&#8221; Mathews said. &#8220;And that’s not just the case for WordPress developers &#8211; the same can be true for professionals in the Drupal, Rails, or .NET ecosystems.</p>
<p>&#8220;It’s our goal to make a framework that empowers developers to use these technologies easily, then dive deeper as they gain more experience. So, instead of taking days to configure webpack for the first time, you can use a Gatsby Theme that connects to WordPress as a data source, and automatically get a blazing fast site. Later, you can learn the innards of the system, and begin customizing Gatsby yourself.&#8221;</p>
<p>While Gatsby as a framework enables developers to bypass a lot of the technical and tooling jargon that has made modern development so complex, it is still a framework geared almost exclusively towards developers. Mathews said the company&#8217;s vision will continue to focus on enabling developers, not on creating solutions to make Gatsby more accessible to the non-technical crowd.</p>
<p>&#8220;We are focused on making Gatsby the best choice for WordPress developers who want a flexible and powerful presentation layer for their headless WordPress sites,&#8221; he said. &#8220;Non-technical team members or clients will still use WordPress to create and manage content, while the web developers on their team or at the agency they hired get to be productive using the best development tools available.&#8221;</p>
<p>Gatsby plans to use the funding to invest $3 million per year in open source, including the core Gatsby project, official plugins, and more learning materials. The funding is also good news for the future of the <a href=\"https://www.wpgraphql.com/\" rel=\"noopener noreferrer\" target=\"_blank\">WPGraphQL</a> project, which should see deeper integration with Gatsby in the near future.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 26 Sep 2019 22:35:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: Long-Needed Date/Time Improvements Land in Core\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94295\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://wptavern.com/long-needed-date-time-improvements-land-in-core\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4026:\"<div class=\"wp-block-image\"><img /></div>



<p>After more than a year and several WordPress updates, an <a href=\"https://make.wordpress.org/core/2019/09/23/date-time-improvements-wp-5-3/\">overhaul of the core Date/Time component</a> concluded.  WordPress 5.3 will ship with fixes for long-standing bugs and new API functions.</p>



<p>Andrey &#8220;Rarst&#8221; Savchenko spearheaded this project and worked through most of the issues in his <a href=\"https://github.com/Rarst/wp-date\">WP Date</a> fork of WordPress.  Much of his work toward addressing the problems with this core component goes back further with the initialization of his <a href=\"https://github.com/Rarst/wpdatetime\">WPDateTime project</a>.</p>



<p>Diving into the Date/Time component is no small feat.  Addressing one issue leads to another.  It&#8217;s a rabbit hole that few in the community have navigated.  Many developers were also unaware of the issues.  However, the bugs lingered for years, and users had no working solution for the problems they were facing.</p>



<p>The most common errors were caused by core bugs or developer errors due to compatibility issues, described Savchenko.  This would cause user-facing issues such as post scheduling and other time-based operations.</p>



<p>With the release of WordPress 5.3, all existing functions should behave more reliably.  Developers working on the component fixed several bugs and updated incorrect inline code documentation for many core functions. Along with the fixes, 5.3 will ship with new <a href=\"https://github.com/Rarst/wp-date/issues/4\">Date/Time API functions</a>.  The updated API includes unified time zone retrieval, localization, and PHP interoperability functions.</p>



<p>Savchenko called it &#8220;the slow descent into madness&#8221; when asked of the catalyst for diving into the Date/Time component and its underlying issues.  &#8220;I started to notice serious bugs in the component from WordPress Stack Exchange questions about them, and the more I looked over years the more clear the dire state of it became to me.&#8221;</p>



<p>One of the major problems is the way WordPress handles timestamps.  &#8220;I actually had to invent the &#8216;WordPress timestamp&#8217; term,&#8221; said Savchenko.  &#8220;There was no name for it in core development and inline documentation incorrectly called these Unix timestamps before.&#8221;  WordPress adds a time zone offset to the real Unix timestamp, which causes issues with upstream PHP and external systems.  </p>



<p>WordPress timestamps couldn&#8217;t be removed from core without breaking backward compatibility.  Plugin and theme developers should avoid working with the WordPress timestamp and opt to use the <a href=\"https://make.wordpress.org/core/2019/09/23/date-time-improvements-wp-5-3/\">recommended methods</a> outlined in Savchenko&#8217;s post.</p>



<p>WordPress date functions were originally written in PHP 4, a version of PHP so long-dead that it&#8217;s almost not worth digging up the end-of-life date (it&#8217;s <a href=\"https://www.php.net/eol.php\">11 years</a>, by the way).  PHP 5.2 introduced the PHP <code>DateTime</code> and <code>DateTimeZone</code> classes and has continued receiving improvements over the years.  WordPress date functions were never updated to utilize newer standards.  The platform&#8217;s more recent bump to a minimum of PHP 5.6 also meant that the <code>DateTimeImmutable</code> class introduced in PHP 5.5 would be available.  The version bump helped land the new API functions in WordPress 5.3.</p>



<p>Some bugs go as far back as 7 years, such as <a href=\"https://core.trac.wordpress.org/ticket/20973\">shorthand formats not working with the core date_i18n() function</a>, which was fixed in WordPress 5.1.  With any luck, core may also adopt such features as <a href=\"https://core.trac.wordpress.org/ticket/18146\">user-based timezones</a> in the future, which would better handle time differences on WordPress installs with users all over the world.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 26 Sep 2019 16:33:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Gary: Talking with WP&amp;UP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"https://pento.net/?p=5120\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"https://pento.net/2019/09/26/talking-with-wpup/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:348:\"<p>At WordCamp Europe this year, I had the opportunity to chat with the folks at WP&amp;UP, who are doing wonderful work providing mental health support in the WordPress community.</p>



<p><a href=\"https://wpandup.org/podcast/getting-to-the-core-of-wordpress-021/\">Listen to the podcast</a>, and check out the services that WP&amp;UP provide!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 26 Sep 2019 04:35:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Gary\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"BuddyPress: BuddyPress 5.0.0 Release Candidate 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=308016\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://buddypress.org/2019/09/buddypress-5-0-0-release-candidate-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2087:\"<p>Hi!</p>



<p><a href=\"https://downloads.wordpress.org/plugin/buddypress.5.0.0-RC2.zip\">The second release candidate for BuddyPress 5.0.0</a> is now available for an ultimate round of testing!</p>



<p>Since the <a href=\"https://buddypress.org/2019/09/buddypress-5-0-0-release-candidate/\">first release candidate</a>, we&#8217;ve improved the way BP REST API Controllers are loaded inside BuddyPress component classes.</p>



<p>This is an important milestone as we progress toward the BuddyPress 5.0.0 final release date. &#8220;Release Candidate&#8221; means that we think the new version is ready for release, but with more than 200,000 active installs, hundreds of BuddyPress plugins and Thousands of WordPress themes, it’s possible something was missed. BuddPress 5.0.0 is&nbsp;scheduled to be released&nbsp;on&nbsp;<strong>Monday, September 30</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.0.0 yet, <strong>now is the time!</strong> </p>



<div class=\"wp-block-button aligncenter is-style-squared\"><a class=\"wp-block-button__link has-background\" href=\"https://downloads.wordpress.org/plugin/buddypress.5.0.0-RC2.zip\">Download and test the 5.0.0-RC2</a></div>



<div class=\"wp-block-spacer\"></div>



<p><em>PS: as usual you alternatively get a copy via our Subversion repository.</em></p>



<p>A detailed changelog will be part of our official release note, but&nbsp;you can get a quick overview by reading the post about the&nbsp;<a href=\"https://buddypress.org/2019/08/buddypress-5-0-0-beta1/\">5.0.0 Beta1</a>&nbsp;release.</p>



<div class=\"wp-block-image\"><img src=\"https://plugins.svn.wordpress.org/buddypress/assets/icon.svg\" alt=\"\" width=\"33\" height=\"33\" /></div>



<p><strong>If you think you&#8217;ve found a bug</strong>, please let us know reporting it on&nbsp;<a href=\"https://buddypress.org/support\">the support forums</a>&nbsp;and/or&nbsp;on&nbsp;<a href=\"https://buddypress.trac.wordpress.org/\">our development tracker</a>.</p>



<p>Thanks in advance for giving this second release candidate a test drive!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 26 Sep 2019 02:31:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"imath\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"WPTavern: Hacktoberfest 2019 Registration is Now Open\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94243\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wptavern.com/hacktoberfest-2019-registration-is-now-open\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3413:\"<p><a href=\"https://hacktoberfest.digitalocean.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Hacktoberfest</a> has started back up again for its sixth year running, sponsored by <a href=\"http://digitalocean.com\" rel=\"noopener noreferrer\" target=\"_blank\">DigitalOcean</a> and <a href=\"https://dev.to/\" rel=\"noopener noreferrer\" target=\"_blank\">DEV</a>. The annual event brings together open source communities from all over the world for virtual and <a href=\"https://hacktoberfest.digitalocean.com/events\" rel=\"noopener noreferrer\" target=\"_blank\">local collaboration</a>. Organizers are expecting approximately 150,000 participants this year.</p>
<p>The first 50,000 participants who make four pull requests to any GitHub-hosted repositories between October 1-31, will receive a commemorative Hacktoberfest T-shirt. Organizers have introduced a one-week review period for PRs this year in order to give maintainers the opportunity to flag any spammy PRs as invalid. The goal is to encourage participants to submit more thoughtful contributions.</p>
<p>More than 21,000 issues on GitHub have already been <a href=\"https://github.com/search?q=label%3Ahacktoberfest+state%3Aopen&type=Issues\" rel=\"noopener noreferrer\" target=\"_blank\">labeled for Hacktoberfest</a>. Maintainers who want to have their projects included should identify issues best suited to new contributors and apply the &#8220;Hacktoberfest&#8221; label. Organizers also recommend creating a CONTRIBUTING.md file with contribution guidelines and adopting a code of conduct for the project.</p>
<p>Adding WordPress to a search for Hacktoberfest issues displays <a href=\"https://github.com/search?utf8=%E2%9C%93&q=label%3Ahacktoberfest+state%3Aopen+wordpress&type=Issues&ref=advsearch&l=&l=\" rel=\"noopener noreferrer\" target=\"_blank\">120 issues</a> that are related in some way to themes, plugins, apps, and other products with WordPress-specific needs. The event is a good opportunity for maintainers to get more exposure for their projects and help new contributors gain confidence through a structured contribution process.</p>
<p>This year Hacktoberfest&#8217;s organizers are also featuring <a href=\"https://github.com/topics/climate-change\" rel=\"noopener noreferrer\" target=\"_blank\">projects focused on combating climate change</a>. These include repos for open source technologies, such as an <a href=\"https://github.com/CodeForAfrica/ClimateChangeProjections\" rel=\"noopener noreferrer\" target=\"_blank\">embeddable map that shows climate change projections</a>, an <a href=\"https://github.com/juancoob/Vegginner\" rel=\"noopener noreferrer\" target=\"_blank\">app targeting consumption habits</a>, and <a href=\"https://github.com/sphericalpm/ghgdata\" rel=\"noopener noreferrer\" target=\"_blank\">greenhouse gas emissions data packaged for exploration and charting</a>, to name a few.</p>
<p>Hacktoberfest is open to contributors at any level of experience. For those just getting started, DigitalOcean has created an <a href=\"https://www.digitalocean.com/community/tutorial_series/an-introduction-to-open-source\" rel=\"noopener noreferrer\" target=\"_blank\">Introduction to Open Source</a> series that covers the basics of git and how to create a pull request. DEV also has a <a href=\"https://dev.to/tvanblargan/crash-course-git-lingo-1enj\" rel=\"noopener noreferrer\" target=\"_blank\">Git crash course</a> available to get new contributors up to speed.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 25 Sep 2019 22:39:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"WPTavern: Human Made Releases Publication Checklist Plugin Designed for the Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94238\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://wptavern.com/human-made-releases-publication-checklist-plugin-designed-for-the-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2502:\"<p>Human Made has created a <a href=\"https://github.com/humanmade/publication-checklist/\" rel=\"noopener noreferrer\" target=\"_blank\">Publication Checklist</a> plugin built specifically for the block editor. It was developed as a headline feature of <a href=\"https://humanmade.com/2019/06/17/a-technical-introduction-to-altis-enterprise-augmented-wordpress-platform/\" rel=\"noopener noreferrer\" target=\"_blank\">Altis</a>, the company&#8217;s enterprise publishing platform based on WordPress, but is also available as a standalone plugin that developers can customize for their own particular use cases.</p>
<p>Ryan McCue, Human Made&#8217;s Director of Engineering, shared screenshots of the plugin on <a href=\"https://twitter.com/rmccue/status/1173550662296190976\" rel=\"noopener noreferrer\" target=\"_blank\">Twitter</a> but noted that it may require more manual configuration when used outside of Altis. Developers familiar with React can extend the checklist to provide a more interactive experience for users completing the required publishing tasks.</p>
<p>&#8220;Because this is built for the block editor, you can build the UI for your checks in React, allowing users to fix issues inline, or providing richer interaction; e.g. &#8216;jump to block failing this check,\'&#8221; McCue said.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-25-at-10.43.20-AM.png?ssl=1\"><img /></a></p>
<p>Status of the publishing tasks is also shown in its own column in the posts list table, a useful feature for giving editorial teams a better overall picture of posts in progress. (The plugin also provides a way to disable this view.)</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/publication-checklist-posts-list-table.jpeg?ssl=1\"><img /></a></p>
<p>It&#8217;s important to note that the Publication Checklist plugin only provides a framework for the pre-publish checks, and does not include a settings interface for users to create their own checks. For this reason, the current version is more geared towards developers who are capable of registering checks using the provided function. The checks display a warning if incomplete but users are still allowed to publish. A more strict enforcement that blocks publishing can also be applied. For more information on customizing the plugin, check out the <a href=\"https://github.com/humanmade/publication-checklist/\" rel=\"noopener noreferrer\" target=\"_blank\">documentation</a> on GitHub.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 25 Sep 2019 17:44:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: Theme Review Team Restructures Into Project Representatives\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94224\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"https://wptavern.com/theme-review-team-restructures-into-project-representatives\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5229:\"<p>The WordPress Theme Review Team (TRT) restructured its administrative duties and laid out its <a href=\"https://make.wordpress.org/themes/2019/09/24/new-theme-review-team-structure/\">new team organization</a> after yesterday&#8217;s semimonthly team meeting. This is not the first time the TRT has restructured to meet the growing demands of the official theme directory over the years.  The team is moving toward a flat structure that spreads its responsibilities to various project representatives.</p>



<p>The original team consisted of a purely merit-based system where members worked their way up the ranks, becoming moderators and eventually admins.  Each level provided more access and responsibility.  In 2017, the team restructured to a <a href=\"https://make.wordpress.org/themes/2017/04/08/restructuring-the-theme-review-team/\">lead-based system</a> in which two team leads rotated every six months.  The time limit was put in place to prevent burnout.  Some leads ran the team beyond the six-month limit during this time, but it was not always easy to find replacements who wanted to take on the full responsibilities of managing everything.  There was also concern among some team members that the rotation schedule wasn&#8217;t strictly followed with some leads overstaying their allotted time.</p>



<p>In meetings and discussions over the last several months, various members drafted proposals on changing the team structure.  The now-former team leads and a group of moderators created the new plan to split the team into specific projects, each with at least one representative.</p>



<p>The following are the new sub-teams and representatives.</p>



<ul><li>Theme review representatives: Sandilya Kafle and Carolina Nymark</li><li>Theme packages representative: Ari Stathopoulos</li><li>Automation representative: Denis Žoljom</li><li>Theme handbook representative: Ana Alfieri</li><li>Communications representative: William Patton</li></ul>



<p>The five projects cover the team&#8217;s current duties and spread out the workload. &#8220;That&#8217;s kind of what this is about,&#8221; said William Patton.  &#8220;It&#8217;s making sure that no one single person handles all the things and that it&#8217;s shared between all.&#8221;</p>



<p>The new structure doesn&#8217;t mean there&#8217;s no room for other projects.  If a team member has a particular itch they want to scratch, they&#8217;re open to spearhead that project.  All the power is no longer consolidated into a couple of people&#8217;s hands.</p>



<p>&#8220;Sharing the load and spreading people&#8217;s specific skills between things they know and are investing time into makes sense at this point,&#8221; said Patton.</p>



<p>The team will no longer rotate leads (or representatives in this case) every six months.  If someone needs to step down from their representative role or take a break, finding a new representative will be handled on a case-by-case basis.  &#8220;We all have our strengths and passions. The thing that we also need to work on is finding people who are willing to participate and eventually take over when we feel tired,&#8221; said Denis Žoljom.</p>



<p>Žoljom has been leading the automation project for while by maintaining the Theme Review coding standards and Theme Sniffer plugin.  He&#8217;s currently looking to move the WPThemeReview ruleset to the official WordPress GitHub.  &#8220;This is necessary because we want to use it in Tide,&#8221; said Žoljom.  Tide is an automated tool for improving code quality in plugins and themes.</p>



<p>&#8220;My personal goal would be to see if we can improve the review process &#8211; either by working on the GitHub review idea I had a few months ago, or by working on the automated tools that help the users,&#8221; said Žoljom.</p>



<p>The theme review representatives will handle the traditional role of overseeing the reviewing responsibilities of the team.  Little will change in that regard since it&#8217;s the primary duty of the TRT.  They will continue moderating themes and handling guideline changes.  &#8220;However, they can consult with other reps to make the final decision and to make new changes,&#8221; said Sandilya Kafle.</p>



<p>The WordPress docs team has now handed over responsibility of the <a href=\"https://developer.wordpress.org/themes/\">theme developer handbook</a> to the TRT.  &#8220;I think we should try to keep coherence between the two handbooks, so we avoid saying one thing in one and another in the other,&#8221; said Ana Alfieri about the differences between the developer and review handbooks.  At times, such difference have been points of contention between TRT members.  Having both handbooks in sync on best practices will help keep reviewers and theme authors on the same page.</p>



<p>Ari Stathopoulos recently took over as the <a href=\"https://wptavern.com/behind-new-packages-project-lead-theme-review-team-launches-admin-notices-solution\">representative for theme packages</a> in the past month.  The packages project aims to build standardized drop-in modules for developers to use in their themes.  This specific project may also have various developers handling specific packages.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 25 Sep 2019 17:18:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: WordPress 5.3 to Introduce New Admin Email Verification Screen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94193\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"https://wptavern.com/wordpress-5-3-to-introduce-new-admin-email-verification-screen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2769:\"<p>WordPress 5.3 is set to introduce an admin email verification screen that will be shown every six months after an admin has logged in. The feature was proposed seven months ago in a <a href=\"https://core.trac.wordpress.org/ticket/46349\" rel=\"noopener noreferrer\" target=\"_blank\">ticket</a> that contributor <a href=\"https://www.andreidraganescu.info/\" rel=\"noopener noreferrer\" target=\"_blank\">Andrei Draganescu</a> opened as part of the Site Health component improvements.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/admin-email-verification.png?ssl=1\"><img /></a></p>
<p>Draganescu said the idea came from discussions in the #core-php channel regarding WSOD (White Screen of Death) recovery emails, which are sent when a site experiences a fatal error and the administrator may be locked out of their WordPress site. Participants in the discussion raised the issue of how common it is for admin email addresses to be outdated or set to a &#8220;catch all&#8221; address that is never checked. The email address may also be set automatically by the host during the process of a one-click installation.</p>
<p>The &#8220;Why is this important?&#8221; link leads to a WordPress support article that describes the <a href=\"https://wordpress.org/support/article/settings-general-screen/#email-address\" rel=\"noopener noreferrer\" target=\"_blank\">various uses for the admin email address</a>, such as new user registration notifications, comment approval, and maintenance messages.</p>
<p>Although it wasn&#8217;t the stated intention for the new admin email verification screen, the feature could become important for improving communication prior to automatic updates. Requiring admins to verify their email addresses after six months could ensure that more addresses are kept current, especially for admins who check their sites infrequently.</p>
<p>When the WordPress security team <a href=\"https://wptavern.com/proposal-to-auto-update-old-versions-of-wordpress-to-4-7-sparks-heated-debate\" rel=\"noopener noreferrer\" target=\"_blank\">proposed auto-updating older versions of WordPress to 4.7</a>, one of the chief concerns is whether WordPress will be able to reach admins whose emails have been abandoned. This new admin email verification screen will not be be useful for older WordPress sites, but in the future, when auto-updating for major versions becomes the standard, it will help ensure more administrators are getting those notices to a working address.</p>
<p>A new <code>admin_email_check_interval</code> filter is available for developers to customize the interval for redirecting the user to the admin email confirmation screen. Those who find it to be unnecessary or annoying can set a very large interval for the check.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 24 Sep 2019 18:30:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Twenty Twenty Bundled in Core, Beta Features Overview\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94038\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/twenty-twenty-bundled-in-core-beta-features-overview\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5884:\"<div class=\"wp-block-image\"><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/twenty-editor.jpg?ssl=1\" target=\"_blank\" rel=\"noreferrer noopener\"><img /></a></div>



<p>Twenty Twenty, the upcoming default WordPress theme, was committed to core and shipped with <a href=\"https://wptavern.com/wordpress-5-3-beta-1-ready-for-testing-includes-12-gutenberg-releases-and-new-twenty-nineteen-default-theme\">WordPress 5.3 Beta 1</a> yesterday.</p>



<p>Like most core themes, Twenty Twenty is simple in function.  It comes packaged with a handful of custom features and options, but it remains true to the mission of being an easy-to-use default theme.</p>



<p>The theme has personality.  Its headings are bold and opinionated.  Its pull quotes grab your attention.  It&#8217;s unafraid of making a splash with its design.   This is a blog theme that&#8217;s meant to showcase what the block editor is capable of doing.   It is a refreshing change of pace from the current slew of themes landing in the directory.</p>



<p>Twenty Twenty is not ideal for every use case.  Some users will no doubt dislike the design choices.  Others will love everything about it.</p>



<p><em>Note: Twenty Twenty is still in beta, so its features could change between now and the official release of WordPress 5.3.</em></p>



<h2>Customizer Options</h2>



<div class=\"wp-block-image\"><img />Hue-only picker for the accent color in the customizer.</div>



<p>The theme has a few custom options available within the customizer:</p>



<ul><li>A retina logo option, which scales the logo image to half its size to make it sharper on hi-res screens.</li><li>An option for showing or hiding a search icon in the header.</li><li>A choice between showing the full post text or summary (excerpt) on archive pages.</li><li>A header and footer background color.</li><li>An accent color used for links and other elements.</li><li>Support for the core custom background feature.</li></ul>



<p>The accent color option is an interesting choice.  Rather than providing the full breadth of all colors, the theme includes a hue-only color picker.  This feature allows users to select from a more limited set of colors within an accessible color range.</p>



<p>There is also a ticket for removing core <a href=\"https://github.com/WordPress/twentytwenty/issues/480\">custom background image support</a> to help users avoid accessibility issues.</p>



<h2>Custom Page Templates</h2>



<a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/twenty-cover.jpg?ssl=1\" target=\"_blank\" rel=\"noreferrer noopener\"><img /></a>Cover template options in the customizer.



<p>Twenty Twenty has a fresh take on creating a cover page not seen in previous default themes.  The &#8220;Cover Template&#8221; works for both posts and pages.  When selecting it, the template displays the post featured image similar to the cover block in core.  The featured image spans the full width of the screen and extends behind the header and navigation area.  The post title and byline/meta are set over the image.</p>



<p>The theme provides a few options for customizing the output of the cover area and allows the user to:</p>



<ul><li>Set a fixed background for a parallax effect.</li><li>Add an overlay background color that sits over the featured image.</li><li>Change the color of the text on top of the image.</li><li>Choose a blend mode for the overlay background color.</li><li>Alter the overlay background color opacity.</li></ul>



<p>Having a core theme explore this feature is a nice. Ideally, users would be able to create a featured cover area on a per-post basis and adjust the colors for the specific image on that post.  However, core has yet to bundle such a feature with the block editor.  There is an open Gutenberg ticket for <a href=\"https://github.com/WordPress/gutenberg/issues/16281\">expanding the editor outside of the post content</a> that may help theme authors address this common feature, but we&#8217;re likely several releases from seeing that become a reality.</p>



<p>The theme also includes a wide (full width) template, which is a fairly common feature.  At the moment, this template doesn&#8217;t seem to do anything in particular when assigned to a page.  There&#8217;s an <a href=\"https://github.com/WordPress/twentytwenty/issues/185\">open GitHub ticket</a> that addresses what it should do at some point.  Considering that the theme has no left/right sidebar, it&#8217;d be interesting to see how this template functions.</p>



<h2>Page Loading Speed</h2>



<p>Page load is something to keep an eye on.  Twenty Twenty currently ships a 100 kb stylesheet on top of the block editor&#8217;s 40 kb CSS file (from the Gutenberg plugin).  This number doesn&#8217;t include the font and JavaScript files also loaded for the page.  This is a far cry from the behemoth 223 kb stylesheet included in Twenty Nineteen, but it&#8217;s still concerning because more development time means that more code will likely get added as tweaks are made and bugs are fixed.  </p>



<p>To be fair, the block editor has many elements to style with no unified design framework for theme authors to take advantage of.  Keeping a Gutenberg-ready stylesheet under 100 kb that also styles each block is a feat of engineering few can master.</p>



<h2>Follow Twenty Twenty Development</h2>



<p>Theme development is currently happening on the <a href=\"https://github.com/WordPress/twentytwenty/\">Twenty Twenty GitHub repository</a>.  If you want to track its changes as the theme is imported into core, the changes are happening on the <a href=\"https://core.trac.wordpress.org/ticket/48110\">Import Twenty Twenty</a> Trac ticket.</p>



<p>The theme still has work to be done before it&#8217;s ready for public release.  Now would be a great time to start testing it and reporting issues.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 24 Sep 2019 17:29:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"BuddyPress: An online community learning hub to deepen studies during IRL meetings\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=307967\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"https://buddypress.org/2019/09/an-online-community-learning-hub-to-deepen-studies-during-irl-meetings/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6001:\"<div><em>This is a guest post by Tanner Moushey, Founder and Lead Engineer of <a href=\"https://study.church/about/\">StudyChurch</a>. He is a BP REST API early adopter and we thought his achievments implementing Headless BuddyPress was a great source of inspirations for the BuddyPress community. Many thanks to him for taking the time to share with us about this case study.</em></div>



<p>Peer reviewed by <a class=\"bp-suggestions-mention\" href=\"https://buddypress.org/members/imath/\" rel=\"nofollow\">@imath</a></p>



<div class=\"wp-block-image\"><img src=\"https://buddypress.org/wp-content/uploads/1/2019/09/StudyChurch-Organization-Dashboard.png\" alt=\"\" /></div>



<p><a href=\"https://study.church/\">StudyChurch</a> is an ambitious startup seeking to make a mark in the church product marketplace. With a unique approach to online interaction, StudyChurch combines elements of engagement and learning in a way that is both simple and intuitive for the end user.</p>



<div class=\"wp-block-spacer\"></div>



<h2>Background</h2>



<p>I began working on StudyChurch as a side project in 2015. It started as a proof of concept and an excuse to dive deeply into BuddyPress. I wanted to leverage the group and activity components that BuddyPress provides and combine that with a custom study module that I created with a custom post type, BackboneJS, and the WordPress REST API. Answers to study questions were stored in WordPress Comments and synced to a custom BuddyPress activity type which was then used to create the discussion interface. Each question had an activity component under it to show off the other group answers and corresponding discussions.</p>



<p>I finished the first draft of the project after several months and before too long I had groups signing up to use the system. I continued to make minor modifications over the next few years but kept running into complaints about speed and the user interface.</p>



<p>When I was approached in 2018 by a publisher that wanted to use StudyChurch on a larger scale it sounded like a great opportunity to rebuild.</p>



<div class=\"wp-block-spacer\"></div>



<h2>Implementing Headless BuddyPress </h2>



<p>One of the big changes that I wanted to make in the rebuild was to switch to a JavaScript front end. I wanted something that was going to allow us to make numerous asynchronous data requests without using Ajax, which can be slow and difficult to maintain over a large project. I decided on VueJS and started building out the API to handle the data that was previously controlled by the BuddyPress templates. </p>



<div class=\"wp-block-spacer\"></div>



<h3>Building a custom API with the BuddyPress REST API </h3>



<p>I’d done quite a bit of work extending the WordPress REST API on previous projects and was excited to discover the <strong>BuddyPress REST API</strong> that extended it. This took care of a lot of the structure and allowed me to focus my time on building out our custom modules and functionality. Anytime I ran into something that needed to be more flexible, I’d submit a patch to the BuddyPress REST API repository and would get a prompt resolution.</p>



<p>Now that we are able to post and retrieve data through the API, the user interactive elements on the site are noticeably faster and the overall load on the server is much less. Not only that, but we are ready for a native app once we get to that point.</p>



<div class=\"wp-block-image\"><img src=\"https://buddypress.org/wp-content/uploads/1/2019/09/studychurch-case-study-image-1024x482.png\" alt=\"\" class=\"wp-image-307971\" /></div>



<div class=\"wp-block-spacer\"></div>



<h3>Creating&nbsp;a VueJS front end </h3>



<p>Building a completely JavaScript front end for BuddyPress was fun challenge. I underestimated how many different components I’d need to build out since I wasn’t able to rely on the BuddyPress default templates, but the end result was well worth the effort.With VueJS we were able to leverage a lot of prebuilt UI packages (like&nbsp;<a href=\"https://element.eleme.io/#/en-US\">Element</a>) to do a lot of the heavy lifting for us. Since we were no longer tied to the BuddyPress template engine, we were able to get creative with how we displayed information and handled user interactions. The end result was a clean, fast, and user friendly interface that was simple and straightforward to use.</p>



<p>I made a few modifications to allow WordPress and BuddyPress recognize our front end app and use it for BuddyPress components. I solved this with a pretty simple hook into the template include filter and included our template instead of the default. A few custom rewrite rules handled any non-BuddyPress url structures I needed to support and I soon had a fully functional and detached front end.</p>



<div class=\"wp-block-spacer\"></div>



<h2>Conclusion</h2>



<p>StudyChurch is now a powerful, robust social network ready for scale. We are still working on improving the system and adding new features which are now easier and faster to implement with the new structure.</p>



<p>We’ve received some great feedback from users who find the app fast and intuitive. We are hoping to build out a native app in the near future.</p>



<p>I’m so thankful for the work done by all of the volunteers who’ve put so much time into WordPress, BuddyPress, and now the BuddyPress REST API. I think there are going to be many more projects like StudyChurch in the near future that will leverage these great tools to build amazing and helpful solutions.</p>



<p>Feel free to reach out if you have any questions or comments on what we’ve done with StudyChurch. Also, you are welcome to browse our code base on <a href=\"https://github.com/studychurch/sc-dashboard\" target=\"_blank\" rel=\"noreferrer noopener\">GitHub</a>.</p>



<p>You can read more about StudyChurch and other projects we work on at <a href=\"https://iwitnessdesign.com/\" target=\"_blank\" rel=\"noreferrer noopener\">iwitnessdesign.com</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 24 Sep 2019 09:07:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"imath\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"WPTavern: WordPress 5.3 Beta 1 Ready for Testing, Includes 12 Gutenberg Releases and New Twenty Twenty Default Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94165\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:128:\"https://wptavern.com/wordpress-5-3-beta-1-ready-for-testing-includes-12-gutenberg-releases-and-new-twenty-nineteen-default-theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2577:\"<p>WordPress core contributors worked together today to package up <a href=\"https://wordpress.org/news/2019/09/wordpress-5-3-beta-1/\" rel=\"noopener noreferrer\" target=\"_blank\">5.3 Beta 1</a> for release on schedule. The Core slack channel was abuzz this afternoon as developers pushed through last-minute commits and fixed issues ahead of shipping the beta.</p>
<p>Iterations on the block editor are a major part of of this release. WordPress 5.3 will include the last 12 Gutenberg plugin releases. If you have already been using the plugin, you may have forgotten how many features it has that still haven&#8217;t made it into core WordPress. This includes significant improvements to group, column, and gallery blocks, Accessibility Navigation mode, the new inserter help panel, &#8220;snackbar&#8221; notices, and the typewriter experience, to highlight a few big items that have been rolled into 5.3.</p>
<p>The highly anticipated Twenty Twenty default theme is also available in the beta, which which we will explore in greater detail on WP Tavern this week. Its design is <a href=\"https://wptavern.com/first-look-at-twenty-twenty-new-wordpress-default-theme-based-on-chaplain\" rel=\"noopener noreferrer\" target=\"_blank\">based on the Chaplin theme from Anders Norén</a> and showcases what is possible with the block editor.</p>
<p>Some of the UI changes introduced in Gutenberg are starting to make their way into other parts of the WordPress admin.</p>
<p>&#8220;These improved styles fix many accessibility issues, improve color contrasts on form fields and buttons, add consistency between editor and admin interfaces, modernize the WordPress color scheme, add better zoom management, and more,&#8221; release coordinator Francesca Marano said in the 5.3 beta 1 announcement.</p>
<p>A few other notable additions to 5.3 that need testing include the following:</p>
<ul>
<li>Support for resuming uploads on large file sizes</li>
<li>Automatic image rotation during upload</li>
<li>Improvements to Site Health checks</li>
<li>Time/Date component fixes</li>
<li>PHP 7.4 Compatibility and removal of deprecated functionality</li>
</ul>
<p>If you&#8217;re ready to take the beta for a test drive, the easiest way is to install the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress Beta Tester</a> plugin and select the “bleeding edge nightlies” option. The <a href=\"https://make.wordpress.org/core/5-3/\" rel=\"noopener noreferrer\" target=\"_blank\">official release</a> is targeted for November 12, 2019.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 24 Sep 2019 02:56:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Google Search Console Adds Breadcrumbs Report, Sends Out Warnings for Structured Data Errors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"https://wptavern.com/google-search-console-adds-breadcrumbs-report-sends-out-warnings-for-structured-data-errors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5150:\"<p>Google recently announced a new Breadcrumbs report available in the Search Console to inform site owners about markup issues. In 2015, Google <a href=\"https://webmasters.googleblog.com/2015/04/better-presentation-of-urls-in-search.html\" rel=\"noopener noreferrer\" target=\"_blank\">introduced support for schema.org structured data</a>, including the breadcrumbs URL structure, in order better present URLs in search results. The Search Console&#8217;s new report uses this data to help site owners fix any issues preventing their breadcrumbs from displaying as rich search results.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Great news, we have a new report on Search Console <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f4e2.png\" alt=\"📢\" class=\"wp-smiley\" /> As of today, if you have Breadcrumb <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f35e.png\" alt=\"🍞\" class=\"wp-smiley\" /> structured data in your site, you\'ll see a new report under Enhancements (see screenshot). Check if you have errors and get to work! <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f6e0.png\" alt=\"🛠\" class=\"wp-smiley\" /> <a href=\"https://t.co/b8I4vbJwb9\">pic.twitter.com/b8I4vbJwb9</a></p>
<p>&mdash; Google Webmasters (@googlewmc) <a href=\"https://twitter.com/googlewmc/status/1174693878835875840?ref_src=twsrc%5Etfw\">September 19, 2019</a></p></blockquote>
<p></p>
<p>Over the weekend, the console started emailing out notices to those who have errors in the breadcrumb structured data on their sites. It includes how many URLs are affected, along with a link to the new report.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-23-at-9.17.17-AM.png?ssl=1\"><img /></a></p>
<p>One common error that users are seeing is a &#8220;Missing field &#8216;item,\'&#8221; which references one of the properties Google requires for displaying that content as a rich result. The &#8216;item&#8217; property is the URL to the webpage that represents the breadcrumb, as Google prefers the final crumb to be linked.</p>
<p>WordPress site owners have started reporting breadcrumb issues in the support forums for various plugins and themes. <a href=\"https://wordpress.org/plugins/breadcrumb-navxt/\">Breadcrumb NavXT</a>, a plugin that is active on 800,000 sites, allows users to generate customizable breadcrumb trails. There are already half a dozen <a href=\"https://wordpress.org/support/plugin/breadcrumb-navxt/\" rel=\"noopener noreferrer\" target=\"_blank\">support threads</a> opened regarding Breadcrumb markup errors listed in the console. Recommendations for fixing this issue vary based on the specific property that is missing and the breadcrumb configuration the user has in place.</p>
<p>Breadcrumb NavXT plugin author John Havlik has <a href=\"https://wordpress.org/support/topic/missing-field-id-in-breadcrumbs-on-google-search-console/page/2/#post-11958307\" rel=\"noopener noreferrer\" target=\"_blank\">advised</a> some users to remove the schema.org markup for unlinked breadcrumb templates in order to remove the error, although this may not offer the best presentation in search snippets. Others have suggested allowing the %link% tag in the unlinked breadcrumb template and Havlik <a href=\"https://github.com/mtekk/Breadcrumb-NavXT/issues/226\" rel=\"noopener noreferrer\" target=\"_blank\">added this to the 6.4.0 milestone for the plugin</a> over the weekend.</p>
<p>The <a href=\"https://wordpress.org/plugins/wordpress-seo/\" rel=\"noopener noreferrer\" target=\"_blank\">Yoast SEO</a> plugin also has an option for adding breadcrumbs and multiple users are <a href=\"https://wordpress.org/support/topic/breadcrumbs-missing-field-id-error-in-google-search-sonsole/\" rel=\"noopener noreferrer\" target=\"_blank\">reporting</a> <a href=\"https://wordpress.org/support/topic/google-breadcrumbs-markup-issues/page/2/\" rel=\"noopener noreferrer\" target=\"_blank\">errors</a> in the Google Search Console. Solutions vary, depending on what types of pages are outputting the error, but the most common advice Yoast support team members are offering is to check to see if there is a theme or plugin that is adding conflicting breadcrumb markup.</p>
<p>There is no easy prescribed fix that will apply to all situations. It depends on how a site owner has configured breadcrumbs through a plugin or if they are automatically generated by a theme.</p>
<p>If you received a notice from Google Search Console, the first step is to determine whether it&#8217;s a theme or a plugin that is generating your breadcrumbs. Next, browse the support forums for the theme/plugin that provides the breadcrumbs and see if the author recommends a fix or is working on one.</p>
<p>Although breadcrumbs do not currently have a direct affect on rankings, they are prominently displayed in search snippets and generally contribute to a positive user experience. For more information on solving specific errors, check out <a href=\"https://developers.google.com/search/docs/data-types/breadcrumb\" rel=\"noopener noreferrer\" target=\"_blank\">Google&#8217;s documentation on Breadcrumb structured data</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Sep 2019 18:57:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordPress.org blog: WordPress 5.3 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7114\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2019/09/wordpress-5-3-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9089:\"<p>WordPress 5.3 Beta 1 is now available!</p>



<p><strong>This software is still in development,</strong> so we don’t recommend running it on a production site. Consider setting up a test site to play with the new version.</p>



<p>You can test the WordPress 5.3 beta in two ways:</p>



<ul><li>Try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (choose the “bleeding edge nightlies” option)</li><li>Or <a href=\"https://wordpress.org/wordpress-5.3-beta1.zip\">download the beta here</a> (zip).</li></ul>



<p>WordPress 5.3 is slated for release on <a href=\"https://make.wordpress.org/core/5-3/\">November 12, 2019</a>, and we need your help to get there. Here are some of the big items to test, so we can find and resolve as many bugs as possible in the coming weeks.</p>



<h2>Block Editor: features and improvements</h2>



<p>Twelve releases of the Gutenberg plugin are going to be merged into 5.3 which means there’s a long list of exciting new features.&nbsp;</p>



<p>Here are just a few of them:</p>



<ul><li>Group block and grouping interactions</li><li>Columns block improvements (width support + patterns)</li><li>Table block improvements (text alignment support, header/footer support, colors)</li><li>Gallery block improvements (reordering inline, caption support)</li><li>Separator block improvements (color support)</li><li>Latest Posts block improvements (support excerpt, content)</li><li>List block improvements (indent/outdent shortcuts, start value and reverse order support)</li><li>Button block improvements (support target, border radius)</li><li>Animations and micro interactions (moving blocks, dropdowns, and a number of small animations to improve the UX)</li><li>Accessibility Navigation Mode which will allow you to navigate with the keyboard between blocks without going into their content.</li><li>Block Style Variations API</li></ul>



<p>Plus a number of other improvements, amongst them:</p>



<ul><li>Data Module API improvements (useSelect/useEffect)</li><li>Inserter Help Panel</li><li>Extensibility: DocumentSettingsPanel</li><li>Snackbar notices</li><li>Typewriter Experience</li><li>Fix a number of Accessibility report issues</li></ul>



<p>If you want to see all the features for each release, here are direct links to the release posts: <a href=\"https://make.wordpress.org/core/2019/09/19/whats-new-in-gutenberg-18-september/\">6.5</a>, <a href=\"https://make.wordpress.org/core/2019/08/28/whats-new-in-gutenberg-28-august/\">6.4</a>, <a href=\"https://make.wordpress.org/core/2019/08/14/whats-new-in-gutenberg-14-august/\">6.3</a>, <a href=\"https://make.wordpress.org/core/2019/07/31/whats-new-in-gutenberg-31-july/\">6.2</a>, <a href=\"https://make.wordpress.org/core/2019/07/10/whats-new-in-gutenberg-10-july/\">6.1</a>, <a href=\"https://make.wordpress.org/core/2019/06/26/whats-new-in-gutenberg-26th-june/\">6.0</a>, <a href=\"https://make.wordpress.org/core/2019/06/12/whats-new-in-gutenberg-12th-june/\">5.9</a>, <a href=\"https://make.wordpress.org/core/2019/05/29/whats-new-in-gutenberg-29th-may/\">5.8</a>, <a href=\"https://make.wordpress.org/core/2019/05/15/whats-new-in-gutenberg-15th-may/\">5.7</a>, <a href=\"https://make.wordpress.org/core/2019/05/01/whats-new-in-gutenberg-1st-may/\">5.6</a>, <a href=\"https://make.wordpress.org/core/2019/04/17/whats-new-in-gutenberg-17th-april/\">5.5</a>, and <a href=\"https://make.wordpress.org/core/2019/04/03/whats-new-in-gutenberg-3rd-april/\">5.4</a>.</p>



<h3>Continuous effort on performance</h3>



<p>The team working on the block editor managed to shave off 1.5 seconds of loading time for a particularly sizeable post (~ 36,000 words, ~ 1,000 blocks) since WordPress 5.2.</p>



<h2>A new default theme: welcome Twenty Twenty</h2>



<p>WordPress 5.3 introduces <a href=\"https://make.wordpress.org/core/2019/09/06/introducing-twenty-twenty/\">Twenty Twenty</a>, the latest default theme in our project history.&nbsp;</p>



<p>This elegant new theme is based on the WordPress theme <a href=\"https://www.andersnoren.se/teman/chaplin-wordpress-theme/\">Chaplin</a> which was released on the WordPress.org theme directory earlier this summer.&nbsp;</p>



<p>It includes full support for the block editor, empowering users to find the right design for their message.</p>



<h2>Wait! There is more</h2>



<p>5.3 is going to be a rich release with the inclusion of numerous enhancements to interactions and the interface.</p>



<h2>Admin interface enhancements</h2>



<p>Design and Accessibility teams worked together to port some parts of Gutenberg styles into the whole wp-admin interface. Both teams are going to iterate on these changes during the 5.3 beta cycle. These improved styles fix many accessibility issues, improve color contrasts on form fields and buttons, add consistency between editor and admin interfaces, modernize the WordPress color scheme, add better zoom management, and more.</p>



<h3>Big Images are coming to WordPress</h3>



<p>Uploading non-optimized, high-resolution pictures from your smartphone isn’t a problem anymore. WordPress now supports resuming uploads when they fail as well as larger default image sizes. That way pictures you add from the block editor look their best no matter how people get to your site.</p>



<h3>Automatic image rotation during upload</h3>



<p>Your images will be correctly rotated upon upload according to the EXIF orientation. This feature was first proposed nine years ago. Never give up on your dreams to see your fixes land in WordPress!</p>



<h3>Site Health Checks</h3>



<p>The improvements introduced in 5.3 make it easier to identify and understand areas that may need troubleshooting on your site from the Tools -&gt; Health Check screen.</p>



<h3>Admin Email Verification</h3>



<p>You’ll now be periodically asked to check that your admin email address is up to date when you log in as an administrator. This reduces the chance that you’ll get locked out of your site if you change your email address.</p>



<h2>For Developers</h2>



<h3>Time/Date component fixes</h3>



<p>Developers can now work with <a href=\"https://make.wordpress.org/core/2019/09/23/date-time-improvements-wp-5-3/\">dates and timezones</a> in a more reliable way. Date and time functionality has received a number of new API functions for unified timezone retrieval and PHP interoperability, as well as many bug fixes.</p>



<h3>PHP 7.4 Compatibility</h3>



<p>The WordPress core team is actively preparing to support PHP 7.4 when it is released later this year. WordPress 5.3 contains <a href=\"https://core.trac.wordpress.org/query?status=accepted&status=assigned&status=closed&status=new&status=reopened&status=reviewing&keywords=~php74&milestone=5.3&order=priority\">multiple changes</a> to remove deprecated functionality and ensure compatibility. Please test this beta release with PHP 7.4 to ensure all functionality continues to work as expected and does not raise any new warnings. </p>



<h3>Other Changes for Developers</h3>



<ul><li>Multisite<ul><li>Filter sites by status<ul><li><a href=\"https://core.trac.wordpress.org/ticket/37392\">https://core.trac.wordpress.org/ticket/37392</a>&nbsp;</li><li><a href=\"https://core.trac.wordpress.org/ticket/37684\">https://core.trac.wordpress.org/ticket/37684</a>&nbsp;</li></ul></li><li>Save database version in site meta<ul><li><a href=\"https://core.trac.wordpress.org/ticket/41685\">https://core.trac.wordpress.org/ticket/41685</a>&nbsp;</li></ul></li></ul></li><li>Code modernization and PHP 7.4 support<ul><li><a href=\"https://core.trac.wordpress.org/ticket/47678\">https://core.trac.wordpress.org/ticket/47678</a>&nbsp;</li><li><a href=\"https://core.trac.wordpress.org/ticket/47783\">https://core.trac.wordpress.org/ticket/47783</a></li></ul></li><li>Toggle password view<ul><li><a href=\"https://core.trac.wordpress.org/ticket/42888\">https://core.trac.wordpress.org/ticket/42888</a></li></ul></li></ul>



<p>Keep your eyes on the <a href=\"https://make.wordpress.org/core/\">Make WordPress Core blog</a> for more <a href=\"https://make.wordpress.org/core/tag/5-3+dev-notes/\">5.3 related developer notes</a> in the coming weeks detailing other changes that you should be aware of.</p>



<h2>What’s next</h2>



<p>There have been over 400 tickets fixed in WordPress 5.3 so far with numerous bug fixes and improvements to help smooth your WordPress experience.</p>



<h2>How to Help</h2>



<p>Do you speak a language other than English? <a href=\"https://translate.wordpress.org/projects/wp/dev/\">Help us translate WordPress into more than 100 languages</a>!</p>



<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://core.trac.wordpress.org/newticket\">file one on WordPress Trac</a> where you can also find a list of <a href=\"https://core.trac.wordpress.org/tickets/major\">known bugs</a>.<br /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Sep 2019 18:36:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Francesca Marano\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"WPTavern: WPHelpful: A User Feedback Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94129\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wptavern.com/wphelpful-a-user-feedback-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7082:\"<div class=\"wp-block-image\"><img /></div>



<p><a href=\"https://wordpress.org/plugins/wphelpful/\">WPHelpful</a> is a plugin created by Zack Gilbert and Paul Jarvis that allows users to rate the helpfulness of a post.  It can be a useful addition to sites that offer tutorials, lessons, documentation, or any content where user feedback is warranted. Version 1.0 is available for free in the official WordPress plugin directory, but it also has a <a href=\"https://wphelpful.com/\">pro version</a> that offers additional features.</p>



<p>I enjoyed giving this plugin a test drive.  As a former business owner, I could see where this plugin would&#8217;ve helped me gather feedback from my customers on product documentation and better catered to their needs.</p>



<p>WPHelpful has huge potential, but its version 1.0 is still a 1.0.  It&#8217;s far from being a polished product at this stage.  It needs time to mature as a good free plugin.  The current batch of pro features should have made the cut for the free version.</p>



<p>The free plugin available in the plugin directory won&#8217;t get you far unless you just need a basic rating system.  It is limited to:</p>



<ul><li>Showing the feedback form on posts and pages.</li><li>Changing the colors for the form button.</li><li>Adding custom CSS (a feature already available on all WP sites via the customizer).</li></ul>



<p>All other features and settings are available in the pro version.  Unless your goal is to simply allow user ratings on posts or pages, you can&#8217;t do much with a free copy.  There are existing plugins with a more mature codebase for handling basic ratings.</p>



<p>One of the most notable aspects of the free version is that it allows you to test the pro settings in a development environment. This provides an opportunity to decide if you want to shell out the money to go pro. I am now officially recommending that every other plugin developer do this when possible.</p>



<h2>What the Plugin Gets Right</h2>



<div class=\"wp-block-image\"><img /></div>



<p>The plugin is simple to use.  You can choose to automatically append the form to posts on the front end or opt to display the form with the <code>[wphelpful]</code> shortcode.</p>



<p>If nothing else, users shouldn&#8217;t have any problems getting the plugin up and running.  I tested it against a variety of themes with solid results.</p>



<p>A custom [Gutenberg] block would&#8217;ve kicked user-friendliness up a notch.  Plugin authors need to start thinking in terms of building a block first and a shortcode second.  I&#8217;m hoping this makes the feature list for version 2.0.</p>



<h2>Post Types: Paywall for the Most Useful Feature</h2>



<p>The most important feature for this plugin is the ability to select which post types the feedback form can be used on.  Unfortunately, this feature is behind a paywall, limiting user feedback to only posts and pages.  This is a foundational feature that would be nicer in the free version.</p>



<p>The post type feature is also limited in the pro setting.  In 1.0, you cannot pick post types individually.  The drop-down field limits you to a single post type, all post types, or pages plus all custom types.  There&#8217;s no way to select two different custom post types.</p>



<p>The plugin doesn&#8217;t use the proper post type label, so you may get some weird labels like &#8220;Wp Area Types&#8221; (from the Gutenberg plugin) or &#8220;Jt Documentation Types&#8221; (a custom post type on my test install).</p>



<p>Non-public post types also show up in the list. So, post types that don&#8217;t have front-end output show up in the select form.</p>



<p>These issues are easy fixes, and I&#8217;m hoping this review sheds light onto these problems so they might be corrected for users.</p>



<h2>How the Plugin Could Offer Better Pro Features</h2>



<div class=\"wp-block-image\"><img />Screenshot of the current post feedback report.</div>



<p>Plugin authors need to eat.  There&#8217;s always a delicate balance that developers must strike between offering a useful free plugin and making enough of a return on their investment to continue maintaining the code.</p>



<p>Currently, most of the plugin&#8217;s pro features are basic items like custom colors and form labels.  These are things that would better serve users in the free version.</p>



<p>A more useful pro feature would be a &#8220;Reports&#8221; screen in the admin that offered options such as:</p>



<ul><li>Sorting posts by rating and total ratings.</li><li>Displaying a graph of user feedback by month, year, etc.</li><li>Other reports that provided an overall look at feedback.</li></ul>



<p>The plugin also only allows logged-in users to provide feedback.  That&#8217;s certainly an easier way to go to avoid spammers and bots.  Due to the added complexity, a pro extension for enabling any site visitor to provide feedback would be worth exploring.</p>



<h2>How Does the Code Stack Up?</h2>



<p>I&#8217;m going to get a bit technical here. Feel free to skip ahead if programming is not your thing.</p>



<p>What the plugin needs is time to mature.  Version 1.0 is not supposed to be the best a plugin can be.  It&#8217;s about shipping a minimum viable product, so I&#8217;m a bit forgiving.  If this were 2.0 or 3.0, I&#8217;d be unrelenting.</p>



<p>There&#8217;s a lot to like about the architectural decisions.  Much of it is set up in a way that it should be relatively easy to maintain in the long term.  This is important because it means that correcting issues, such as those listed below, shouldn&#8217;t be tough to fix.</p>



<p>There are code issues that need patches. The plugin currently:</p>



<ul><li>Uses a PHP variable for textdomains (not all translation tools run in a PHP environment).</li><li>Hasn&#8217;t internationalized all of its user-facing text, so not everything can be translated.</li><li>Registers multiple options in the database instead of storing all options together, which creates unnecessary clutter.</li><li>Doesn&#8217;t clean up after itself and delete its options upon uninstall.</li></ul>



<p>These are not insurmountable issues, and they don&#8217;t break anything to the point of making the plugin unusable.  They&#8217;re just issues that need to be addressed.</p>



<h2>The Final Verdict</h2>



<p>Version 1.0 of WPHelpful lacks the feature set to be a particularly great free plugin.  It could be useful in some limited cases.  However, you&#8217;ll probably want to opt for the pro version to get the features that would make this plugin worth using.</p>



<p>WPHelpful has potential. I could see it growing an audience of 100K, 500K, or more users over time with more polishing.  It&#8217;s not there yet.  The plugin doesn&#8217;t have enough meat on its bones for me to recommend it yet, but I&#8217;m hopeful that future versions will offer a more robust experience.</p>



<p>If you&#8217;re looking for an easy-to-use free plugin that works with just posts and pages, it could serve your needs.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Sep 2019 18:01:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: GitHub Adds Dependency Graphs, Security Alerts for PHP Repos\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94088\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"https://wptavern.com/github-adds-dependency-graphs-security-alerts-for-php-repos\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4157:\"<div class=\"wp-block-image\"><img /></div>



<p>PHP developers everywhere can rejoice as GitHub adds the long-awaited <a href=\"https://github.blog/2019-09-18-dependency-graph-supports-php-repos-with-composer-dependencies/\">dependency graphs feature for PHP repositories</a> that use Composer.  The feature provides security alerts, shows dependency insights, and displays the dependents of a given repository.  If enabled, it can also automatically send security fixes to the repository via pull requests.</p>



<p>GitHub initially added support for JavaScript and Ruby when <a href=\"https://github.blog/2017-11-16-introducing-security-alerts-on-github/\">rolling out dependency graphs in 2017</a>. They added <a href=\"https://github.blog/2019-07-02-yarn-support-for-security-alerts/\">support for Yarn lock files</a> in July of this year. This has been a boon to the JavaScript community as it alerts developers of vulnerabilities in code they&#8217;re using and shipping to users.</p>



<p>&#8220;We&#8217;re also seeing PHP and Composer grow in popularity&#8211;PHP is the fourth most popular language on GitHub and Composer is the fourth most starred PHP project,&#8221; wrote Justin Hutchings, Senior Product Manager at GitHub.  The company has taken notice of the trends.  JavaScript is a hot topic in many developer circles today, but PHP frameworks such as Laravel and Symfony continue growing in popularity and dominate among <a href=\"https://github.com/topics/php\">popular PHP repositories</a>.</p>



<p>Composer is the <em>de facto</em> standard for PHP dependency management.  Core WordPress first <a href=\"https://core.trac.wordpress.org/ticket/43558\">added Composer support</a> for development environments in version 5.1.  While it&#8217;s not a part of the release package, this was some small victory after a <a href=\"https://core.trac.wordpress.org/ticket/23912\">years-long discussion</a> of adding a basic <code>composer.json</code> file to core.  Core hasn&#8217;t fully embraced Composer or any type of PHP dependency management, but plugin and theme authors are using it more than a few short years ago.  The new alerts and automatic pull requests will offer one more avenue for catching security issues with plugins and themes.</p>



<p>GitHub seems to be rolling this feature out in waves.  After checking some repositories with dependency graphs enabled, some still do not have their PHP dependencies listed.  It may take some time, but developers should start seeing dependencies appear that are listed in their <code>composer.json</code> or <code>composer.lock</code> files.</p>



<p>Public repositories should begin seeing automatic security alerts when an issue is found.  GitHub will start notifying repository owners of these alerts via web notifications or email, depending on what the account holder has set as their preference.  Developers with private repos or who have disabled dependency graphs will need to enable them to take advantage of the new feature.</p>



<p>Security alerts on old repositories could become an annoyance.  GitHub recommends archiving those repos.  &#8220;Archived repositories send a signal to the rest of the community that they aren&#8217;t maintained and don&#8217;t receive security alerts,&#8221; explained Hutchings.</p>



<p>Developers who have opted into GitHub&#8217;s <a href=\"https://help.github.com/en/articles/configuring-automated-security-fixes\">automatic security fixes beta</a> feature can now enjoy automatic pull requests (PRs) from GitHub when vulnerabilities are found.  GitHub creates a PR with the minimum possible secure version.  The developer can then merge the PR at their discretion.</p>



<p>Dependency graphs also make for a much nicer experience when browsing a repository&#8217;s dependencies.  Previously, developers would need to dive into a project&#8217;s <code>composer.json</code> or view them from Packagist, the official package directory for Composer.  Developers can now click on a link to view a dependent repository.</p>



<p>Rolling this feature out for PHP repos is a welcome addition and should help more projects keep their code secure.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 20 Sep 2019 17:45:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"BuddyPress: A new place to learn how to build on top of BuddyPress!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=307844\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://buddypress.org/2019/09/bp-devhub-1-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4575:\"<p>Hi!</p>



<p>We’re very excited to officially announce the launch of a new development resources site on the BuddyPress.org network.</p>



<div class=\"wp-block-image\"><a href=\"https://developer.buddypress.org/\" target=\"_blank\" rel=\"noreferrer noopener\"><img src=\"https://buddypress.org/wp-content/uploads/1/2019/09/bpdevhub-landing-page-1024x652.png\" alt=\"\" class=\"wp-image-307848\" /></a></div>



<p>Today we are inaugurating <strong><a href=\"https://developer.buddypress.org/\">developer.buddypress.org</a></strong> with a complete <a href=\"https://developer.buddypress.org/bp-rest-api/\">handbook documenting the BP REST API</a>. This API will be introduced into our next major version which is scheduled on September 30, 2019. We thought you’d be interested to have a tool to help you discover the BuddyPress REST endpoints and their parameters to start playing with them (You’ll need <a href=\"https://buddypress.org/2019/09/buddypress-5-0-0-release-candidate/\">BuddyPress 5.0.0-RC1</a> to have even more fun with it!).</p>



<div class=\"wp-block-spacer\"></div>



<h2 id=\"rest-api-handbook\">Using the BP REST API Handbook</h2>



<p>The main part of the handbook is the «&nbsp;Developer Endpoint Reference&nbsp;». We grouped these endpoints according to the component they belongs to.</p>



<div class=\"wp-block-image\"><img src=\"https://buddypress.org/wp-content/uploads/1/2019/09/bpdevhub-02-911x1024.png\" alt=\"\" class=\"wp-image-307845\" /><a rel=\"noreferrer noopener\" href=\"https://buddypress.org/wp-content/uploads/1/2019/09/bpdevhub-02.png\" target=\"_blank\">View the full screenshot in a new tab.</a></div>



<p>Each page of the reference is firstly introducing the component and describing the data schema of items contained into the REST responses. Then for each verb (or method), you&#8217;ll find the available arguments, their definition and an example of use with the <code><a href=\"https://bpdevel.wordpress.com/2019/09/12/let-us-start-using-the-bp-rest-api/\">bp.apiRequest()</a></code> JavaScript function. Below is a screenshot of the method to get a specific Activity.</p>



<div class=\"wp-block-image\"><a href=\"https://developer.buddypress.org/bp-rest-api/reference/activity/#retrieve-a-specific-activity\"><img src=\"https://buddypress.org/wp-content/uploads/1/2019/09/bpdevhub-verb-example.png\" alt=\"\" class=\"wp-image-307851\" /></a></div>



<h2>The future of this development resources hub</h2>



<p>You can have a good idea of what’s coming next into this developer oriented site looking at its current landing page. We will first work on building the full <a href=\"https://buddypress.trac.wordpress.org/ticket/6812\">PHP Code Reference for BuddyPress</a>: functions, classes and hooks.<br /></p>



<p>Then, we haven’t planned anything yet <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/263a.png\" alt=\"☺\" class=\"wp-smiley\" /> and we’re very opened to ideas and of course contributions about the «&nbsp;how&nbsp;» step and the «&nbsp;do&nbsp;» one.</p>



<div class=\"wp-block-spacer\"></div>



<h2>About the editing workflow</h2>



<p>Unlike the BuddyPress Codex, it’s not possible for everyone to directly edit the content of the BP REST API Handbook or the future PHP Code Reference.</p>



<div class=\"wp-block-image\"><a href=\"https://buddypress.trac.wordpress.org/newticket\"><img src=\"https://buddypress.org/wp-content/uploads/1/2019/09/new-ticket.png\" alt=\"\" class=\"wp-image-307857\" /></a></div>



<p>But you can always report issues or suggest improvements using our <a href=\"https://buddypress.trac.wordpress.org\">Bug Tracker</a> making sure to select the «&nbsp;<strong>BuddyPress.org sites</strong>&nbsp;» option of the components dropdown of your ticket.</p>



<div class=\"wp-block-spacer\"></div>



<h2>Props</h2>



<p>The first version of the development resources hub was built thanks to the involvement of these contributors:</p>



<p><a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone B Gorges (boonebgorges)</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby (johnjamesjacoby)</a>,&nbsp;<a href=\"https://profiles.wordpress.org/imath/\">Mathieu Viet (imath)</a>,  <a href=\"https://profiles.wordpress.org/tw2113/\">Michael Beckwith (tw2113)</a>,&nbsp;<a href=\"https://profiles.wordpress.org/espellcaste/\">Renato Alves (espellcaste)</a>,&nbsp;<a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar (netweb)</a>.</p>



<p>Many thanks to them <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f609.png\" alt=\"😉\" class=\"wp-smiley\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 20 Sep 2019 14:47:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"imath\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"Post Status: Salesforce Ventures invests $300 million in Automattic, at a $3 billion valuation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=68901\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://poststatus.com/salesforce-ventures-automattic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6125:\"<p>Salesforce Ventures is the investment arm of Salesforce. Prior to this investment in <a href=\"https://automattic.com/\">Automattic</a>, Salesforce Ventures had <a href=\"https://www.salesforce.com/company/ventures/funds/\">announced</a> $875 million raised across 11 fund initiatives — but none that amounts to $300 million. Previosuly, each fund has been between $50 to $125 million spread across several <a href=\"https://www.crunchbase.com/organization/salesforce-ventures/investments/investments_list\">investments</a>.</p>



<p>I believe <a href=\"https://www.salesforce.com/company/ventures/\">Salesforce Ventures</a> called up funds specifically for this strategic investment in Automattic, which would likely put their total dollars invested (or committed to existing funds) well beyond $1 billion, and the $300 million into Automattic would be their largest investment to date, to my knowledge.</p>



<p>Salesforce Ventures states on their website that they are exclusively seeking investments in &#8220;enterprise cloud&#8221; companies. In Automattic Founder and CEO Matt Mullenweg&#8217;s <a href=\"https://ma.tt/2019/09/series-d/\">announcement</a> about the funding, he specifically noted how Salesforce CEO Marc Benioff, &#8220;helped open my eyes to the incredible traction WordPress <a href=\"https://wpvip.com/\">and WP VIP</a> has seen in the enterprise market, and how much potential there still is there.&#8221; I am curious to see how Automattic changes their approach to VIP in particular, in light of this.</p>



<p>$300 million is a lot of money. Salesforce is joining Insight Venture Partners, Tiger Global, and True Ventures as primary outside investors in Automattic. </p>



<p>Given that Salesforce was the lead and only investor here, they now own a significant stake in Automattic — and it will be interesting to see what kind of confluence that enables between the two companies. Automattic CEO Matt Mullenweg tells me, &#8220;Automattic has been a long-time customer of Salesforce’s products, and we think there are lots of opportunities for closer integration.&#8221;</p>



<p>Since Automattic recently acquired Tumblr and brought on a few hundred new employees from it, it&#8217;s natural to think the new fundraising is related. I asked Matt about that, and he said it was unrelated in terms of financial justification, but they did, &#8220;disclose the Tumblr transaction to Salesforce during [their] discussions.&#8221;</p>



<p>Automattic hasn&#8217;t raised money since 2014, and it seems like this round is similar to prior ones, wherein the money helps spur their growth plans along but that they are operationally profitable — or close to it. Matt <a href=\"https://techcrunch.com/2019/09/19/automattic-raises-300-million-at-3-billion-valuation-from-salesforce-ventures/\">told Techcrunch</a>, &#8220;The roadmap is the same. I just think we might be able to do it in five years instead of ten.&#8221;</p>



<p>Matt called the investment proof of Salesforce&#8217;s own &#8220;tremendous vote of confidence for Automattic and for the open web.&#8221; Salesforce does have some history of supporting <a href=\"https://opensource.salesforce.com/\">open source projects</a>, although that shouldn&#8217;t be equated to an investment in Automattic as a company; it is a vote of confidence for companies that rely on open-source platforms as a part of their line of business.</p>



<p>Automattic is the single most significant contributor to WordPress and related open-source projects. It also relies on open-source software for its product development — particularly Jetpack and WooCommerce — and features like Gutenberg as the core experience for writing and site-building. How that blend of open source software and business development plays out, in the long run, is certainly of high interest to the open-source community.</p>



<p>I have long discussed on various platforms how I think there are a handful of companies that are big enough to acquire Automattic someday. I still think Automattic is more likely to go public at some point, but if they are acquired, Salesforce is definitely one of those few with the resources to make it happen, and perhaps the operational congruence as well.</p>



<p>Reaching a $3 billion valuation is an amazing feat that Automattic has achieved. Matt has said before that he believes each of their primary lines of business — WordPress.com, WooCommerce, and Jetpack — can be multi-billion dollar opportunities. I agree with him, particularly for WooCommerce. I think there&#8217;s a good chance WooCommerce will end up several times more valuable than all their other lines of business combined. <span class=\"pullquote alignleft\">I would love to see these new funds be funnelled into the incredible opportunity in the eCommerce landscape; one only needs to look at what Shopify has done to see what&#8217;s possible, and just how successful it can be.</span> </p>



<p>I asked Matt why he was attracted to an investment from Salesforce&#8217;s VC arm, rather than an investment-only style firm. He said, &#8220;I love Salesforce’s philosophy, how they cultivate such a fantastic community, how they support progressive policies in San Francisco and the other cities they operate in, how they’ve been founder-led, their scale, their leadership, and their longevity in defining an entirely new class of software and being the most significant player in it.&#8221;</p>



<p>I love the point about Salesforce defining a class of software — and I have realized recently just how huge their developer community is — so I really appreciate this comment from Matt. Making commercial and SaaS software is a well-established business now. Automattic is in a unique position as the most powerful player in an <em>open</em> ecosystem proud of its independence. This provides many unique opportunities for Automattic the business and unique challenges for Automattic the WordPress community member.</p>



<p><em>Image credit: <a href=\"https://ma.tt/2019/09/series-d/\">Matt Mullenweg</a>, whose blog I brazenly stole it from.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Sep 2019 23:05:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: WordPress Community Contributors to Host Free Online Diversity Workshop Ahead of WordCamp US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93735\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://wptavern.com/wordpress-community-contributors-to-host-free-online-diversity-workshop-ahead-of-wordcamp-us\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5663:\"<p>WordCamp US will <a href=\"https://2019.us.wordcamp.org/2019/08/08/wordcamp-us-debuts-community-track/\" rel=\"noopener noreferrer\" target=\"_blank\">debut a new Community Track</a> in November that will feature sessions and workshops on topics like meetups, WordCamps, diversity and inclusion, and kids/youth. Jill Binder, Allie Nimmons, Aurooba Ahmed, and David Wolfpaw will be hosting a workshop called &#8220;Creating a Welcoming and Diverse Space&#8221; at the event. In order to adequately prepare for presenting on this sensitive topic, the team will be <a href=\"https://make.wordpress.org/community/2019/09/13/call-for-participants-creating-a-welcoming-and-diverse-space-online-workshop-on-sun-oct-6/\" rel=\"noopener noreferrer\" target=\"_blank\">running the workshop in a live, interactive Zoom call on Sunday, October 6</a>.</p>
<p>In light of the recent news about <a href=\"https://wptavern.com/php-central-europe-conference-canceled-due-to-lack-of-speaker-diversity\" rel=\"noopener noreferrer\" target=\"_blank\">a central European PHP conference getting canceled due to a lack of a diverse lineup</a>, the broader PHP community is becoming more conscious of the importance of recruiting speakers that better represent their communities.</p>
<p>&#8220;The <a href=\"https://tiny.cc/wpdiversity\" rel=\"noopener noreferrer\" target=\"_blank\">Diverse Speaker Workshops</a> that I’m running in WordPress and am <a href=\"https://diversein.tech/\" rel=\"noopener noreferrer\" target=\"_blank\">bringing to other technologies</a> have been just as important for years as they are now,&#8221; training leader <a href=\"https://diversein.tech\" rel=\"noopener noreferrer\" target=\"_blank\">Jill Binder</a> said. &#8220;These workshops are an essential piece to the whole puzzle for creating diverse communities, attendance at events, public speakers, and ultimately, leaders and organizers.&#8221;</p>
<p>Binder said there are many factors in society that work against having diversity in a tech event’s public speaker lineup, but one that her team is specifically tackling in these workshops is <a href=\"https://en.wikipedia.org/wiki/Impostor_syndrome\" rel=\"noopener noreferrer\" target=\"_blank\">imposter syndrome</a>.</p>
<p>&#8220;Our workshops help folks bust through their impostor syndrome and develop a topic, title, pitch, bio, and outline, more confidence in public speaking, and the motivation to start speaking,&#8221; Binder said.</p>
<p>&#8220;The new workshop that Allie, Aurooba, David, and I are creating for WordCamp US on &#8216;Creating a Welcoming and Diverse Space&#8217; is another important piece to the puzzle. We are going to be teaching mindset, community, environment, speakers, and allyship. It will be an interactive workshop where people will walk away with an action list they can start implementing in their communities (whether in person or online) right away.&#8221;</p>
<p>Some organizers of tech events have claimed that for certain events it is impossible to create a diverse lineup of speakers due to the demographics of the community and lack of willing participants.</p>
<p>Binder said that in her experience it is unlikely that more diverse people are unwilling to speak but rather that the event is not being created with more kinds of people in mind. She offered a few suggestions for organizers to consider in planning ahead for a welcoming and diverse space:</p>
<ul>
<li>Have the event at different times that work for people with families. For example, don’t hold them all at 9pm at night. Weekend afternoons may work. Ask those with children what works for them.</li>
<li>Consider venues that are not centered around alcohol (like bars and pubs). This opens up the event to attendees who are under 21, recovering addicts, folks who belong to a religious group that prohibits alcohol, and many other people who don’t feel safe or welcome in an alcohol-focused environment.</li>
<li>Choose venues that have accessible alternatives to stairs, such as elevators and ramps.</li>
<li>Try to have more diversity in the organizing team.</li>
<li>Bring in more diverse speakers. Don’t know how? Check out the Diverse Speaker Workshop – <a href=\"https://tiny.cc/wpdiversity\" rel=\"noopener noreferrer\" target=\"_blank\">in WordPress</a> and in <a href=\"https://diversein.tech/\" rel=\"noopener noreferrer\" target=\"_blank\">other techs communities.</a></li>
</ul>
<p>She also recommends organizers directly invite more people into their communities.</p>
<p>&#8220;Ask people in your network to introduce you to diverse people they may know who work with WordPress or your technology,&#8221; Binder said. &#8220;You can even go out and find those communities in your area – online and in person – or ask people to make an introduction for you to those groups. Examples of groups: Ladies Learning Code, Black Girls Code. Form genuine, friendly relationships with community members so that they can help you reach the WordPress enthusiasts in their communities.&#8221;</p>
<p>Binder said the team will go into more detail on these topics during the workshop. Anyone who would like to learn more is welcome to attend the online public rehearsal for the workshop on October 6, at 3pm-5pm ET. This is a unique opportunity for those who cannot attend WordCamp US to join in on one of the interactive workshops. <a href=\"https://make.wordpress.org/community/2019/09/13/call-for-participants-creating-a-welcoming-and-diverse-space-online-workshop-on-sun-oct-6/\" rel=\"noopener noreferrer\" target=\"_blank\">Comment on the Community team&#8217;s post</a> with contact information and workshop leaders will send the zoom link and more information.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Sep 2019 22:14:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: Bayleaf: A Food and Recipe Blog Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94041\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wptavern.com/bayleaf-a-food-and-recipe-blog-theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5971:\"<div class=\"wp-block-image\"><img /></div>



<p>With the WordPress theme directory dominated by business-oriented themes, it&#8217;s sometimes tough to find themes that cater to more specific user groups. If you dig deep enough, you&#8217;ll find something outside the norm.  <a href=\"https://wordpress.org/themes/bayleaf/\">Bayleaf</a> is a blog theme specifically designed for sharing food and recipes.  </p>



<p>The theme is designed and developed by <a href=\"https://vedathemes.com/\">Vedathemes</a>.  They currently have three themes in the theme directory, which follow the same clean design trend of Bayleaf.</p>



<p>Food-related themes excite me.  In my off-time, I&#8217;m often browsing recipe blogs and looking for my next culinary experiment.  The problem with many such sites is their designs have too much noise instead of just showcasing the content visitors are looking for.  I was pleasantly surprised at the minimalist and open approach in the <a href=\"https://vedathemes.com/bayleaf-pro/\">Bayleaf demo</a>.</p>



<p><em>Admittedly, I was drawn in by all the yummy food pics.</em></p>



<p>The theme author has obviously taken a look at the food blogs and built a design that showcases what&#8217;s possible without adding complexity.  The related posts feature is also a nice extra for site visitors who&#8217;ll likely look for related recipes.</p>



<p>Bayleaf combines the Poppins and Montserrat font families to create bold headers that are complimented by readable body copy.  The theme comes with options for displaying a sidebar on single posts or pages, but I&#8217;d recommend opting out.  The design works best without a sidebar, allowing more breathing room for sharing food images.</p>



<p>The theme is slowly building an audience since its release in February.  It currently has 1,000+ installs and a five-star rating from six reviews in the theme directory.</p>



<h2>Create a Unique Look with the Display Posts Widget</h2>



<div class=\"wp-block-image\"><img /></div>



<p>Bayleaf&#8217;s most prominent custom feature is its Display Posts widget.  By placing this widget in the Homepage Above Content or Homepage Below Content sidebar, users have a ton of variety with how their site looks.  No two homepages need look alike.</p>



<p>The widget comes with six list, grid, and slider styles to choose from. It supports custom post types and taxonomies, so users can use it for content such as events, products, or anything else they want to showcase.</p>



<p>My first thought when viewing the demo was, <em>Not another complicated slider with a hard-to-configure customizer experience.</em> While I&#8217;m not usually a fan of sliders, configuring this one was easy.  Plus, the grid and list styles offered alternative options.</p>



<p>A lot of themes overdo features like this, offering a clunky experience within the customizer.  However, Bayleaf keeps it simple by packaging the feature as a widget with just enough variety to cover most use cases.</p>



<p>My one complaint with the Display Posts widget is that it was hard to find at first.  At this point, it should be standard practice to prefix custom widgets with the theme name.  &#8220;Bayleaf: Display Posts&#8221; would&#8217;ve been far easier to pick from the widget lineup.</p>



<h2>Handling Block Editor Support</h2>



<div class=\"wp-block-image\"><img /></div>



<p>I tested Bayleaf against the latest public release of the Gutenberg plugin. The theme is not without a few problems, which is par for the course with most themes supporting the block editor.  The Gutenberg plugin&#8217;s development is fast-paced, and it&#8217;s tough for theme authors to keep up.  Something that works one week could break the next.</p>



<p>The theme takes a minimalist approach with regards to the editor, allowing the default editor styles to handle much of the layout.  With the break-neck pace of change, this can sometimes be a better approach than attempting to manage every style.</p>



<p>There are areas where Bayleaf could be more opinionated.  For example, the alignment and typography for the post title aren&#8217;t a one-to-one match between the editor and front end.  The content width is wider on the front end than the editor, which means the number of characters per line doesn&#8217;t match.  There are several minor items where the block editor overrules theme styles.</p>



<p>The theme doesn&#8217;t offer a 100% WYSIWYG experience, but it&#8217;s close enough at this stage and doesn&#8217;t break anything.  Most issues are trivial and will simply take some adjustment time, assuming Gutenberg development settles a bit.</p>



<h2>How Does the Code Stand Up?</h2>



<p>Bayleaf isn&#8217;t pushing any boundaries, but it&#8217;s solid in comparison to the average theme.  It&#8217;s based on the Underscores starter, which serves as the <em>de facto</em> standard for many themes in the official directory.</p>



<p>The theme doesn&#8217;t have a ton of custom code, so there are few places it could go wrong.</p>



<p>Like all themes in the official directory, it undergoes a rigorous review process.  It&#8217;s <a href=\"https://themes.trac.wordpress.org/query?keywords=~theme-bayleaf\">Trac history</a> doesn&#8217;t show anything worrisome.  Vedathemes seems to have a good grasp of building themes that meet the official theme review standards.</p>



<h2>The Final Verdict</h2>



<p>You won&#8217;t find a boatload of options in Bayleaf.  What you will find is a clean design that gets out of the way but with enough features to have fun tinkering around on your blog for a couple of hours.  The Display Posts widget can get you pretty far with little work.</p>



<p>If you&#8217;re looking for a change to your food or recipe blog, you can&#8217;t go wrong giving this theme a run. </p>



<p>The theme could also be used for other types of sites.  There are no specific features that limit its use to only food blogging.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Sep 2019 18:49:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: Automattic Raises $300M in Series D Investment Round, Valuation Jumps to $3 Billion\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94026\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"https://wptavern.com/automattic-raises-300m-in-series-d-investment-round-valuation-jumps-to-3-billion\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6254:\"<p><a href=\"https://automattic.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Automattic</a> announced another round of funding today, a $300 million Series D investment from <a href=\"https://www.salesforce.com/company/ventures/\" rel=\"noopener noreferrer\" target=\"_blank\">Salesforce Ventures</a>, giving the company a $3 billion valuation post-funding. The last time Automattic raised money was $160 million in a Series C round in 2014. Since that time the company has grown to more than 950 employees and made strategic acquisitions, including <a href=\"https://wptavern.com/automattic-acquires-woocommerce\" rel=\"noopener noreferrer\" target=\"_blank\">WooCommerce</a> in 2015 and <a href=\"https://wptavern.com/automattic-acquires-tumblr-plans-to-rebuild-the-backend-powered-by-wordpress\" rel=\"noopener noreferrer\" target=\"_blank\">Tumblr</a> (closing in 2019).</p>
<p>CEO Matt Mulleneweg <a href=\"https://ma.tt/2019/09/series-d/\" rel=\"noopener noreferrer\" target=\"_blank\">said</a> the funds will enable the company to speed up and scale its product development, as well as continue the company&#8217;s continual contributions to WordPress:</p>
<blockquote><p>For Automattic, the funding will allow us to accelerate our roadmap (perhaps by double) and scale up our existing products—including WordPress.com, WordPress VIP, WooCommerce, Jetpack, and (in a few days when it closes) Tumblr. It will also allow us to increase investing our time and energy into the future of the open source WordPress and Gutenberg.</p></blockquote>
<p>In 2016, Mullenweg <a href=\"https://wptavern.com/woocommerce-powers-42-of-all-online-stores\" rel=\"noopener noreferrer\" target=\"_blank\">identified both Jetpack and WooCommerce as “multi-billion dollar opportunities”</a> that could each be larger than WordPress.com in the future. Jetpack has grown from 1+ million users in 2016 to more than 5 million today. The plugin&#8217;s product team has aggressively expanded its commercial plans and features and is one of the first to experiment with offering <a href=\"https://wptavern.com/jetpack-7-6-improves-amp-compatibility-adds-preview-and-upgrade-nudge-for-blocks-only-available-on-paid-plans\" rel=\"noopener noreferrer\" target=\"_blank\">previews and commercial upgrade nudges for blocks in WordPress&#8217; editor</a>.</p>
<p>WooCommerce has also grown to more than 5 million active installs (from 1+ million in 2015 at the time of acquisition). The e-commerce platform has a more challenging market with formidable competitors like Shopify, which recently <a href=\"https://observer.com/2019/09/shopify-ebay-amazon-ecommerce-growth/\" rel=\"noopener noreferrer\" target=\"_blank\">overtook eBay as the second largest shopping site after Amazon</a>. Shopify <a href=\"https://investors.shopify.com/Investor-News-Details/2019/Shopify-Announces-Second-Quarter-2019-Financial-Results/default.aspx\" rel=\"noopener noreferrer\" target=\"_blank\">reported $362 million in revenue</a> during its last quarter with $153 million coming from subscriptions to the Shopify platform.</p>
<p>I asked Mullenweg about how the funding might help Automattic make WooCommerce more user-friendly and competitive. Despite going up against the seemingly indomitable e-commerce powerhouses, Mullenweg sees WooCommerce&#8217;s platform an opportunity for growing independent stores on the web.</p>
<p>&#8220;WooCommerce already represents the best way to marry content and commerce, and has a huge advantage being so tightly integrated from a user perspective with WordPress itself,&#8221; Mullenweg said. &#8220;However it also inherits some of the barriers WordPress has to adoption, particularly from new users. I think that Gutenberg will help a ton, as it&#8217;s better than any of the builders the eCommerce players have, and when that gets combined with the flexibility, control, and scalability you get from WP + WooCommerce it&#8217;s going to be huge. There&#8217;s a ton of work left to do, though, and we&#8217;re trying to grow that team as quickly as possible to keep up with the opportunity.&#8221;</p>
<p>Mullenweg declined to share any information about Jetpack and WooCommerce&#8217;s revenue today but confirmed that they have not yet eclipsed WordPress.com.</p>
<p>&#8220;What I can say is that WP.com is still our biggest business, and WooCommerce was our fastest growing last year,&#8221; he said.</p>
<p>Automattic&#8217;s most recent round of funding will help the company better monetize these products that have grown in tandem with WordPress&#8217; market share, which W3Techs puts at <a href=\"https://w3techs.com/technologies/details/cm-wordpress/all/all\" rel=\"noopener noreferrer\" target=\"_blank\">34.5%</a> of the top 10 million websites. Independent stores sitting on top of this large chunk of the web represent a significant market that Automattic is currently dominating in the WordPress space.</p>
<p>The Tumblr acquisition also affords another opportunity to introduce e-commerce solutions to more of Automattic&#8217;s customers. Mullenweg previously said the Tumblr app receives 20X more daily signups than the WordPress mobile app. The social network/blogging hybrid also has a significantly younger user base, based on <a href=\"https://weareflint.co.uk/main-findings-social-media-demographics-uk-usa-2018\" rel=\"noopener noreferrer\" target=\"_blank\">a 2018 study</a> that found 43 percent of internet users between the ages of 18 to 24 years old used Tumblr. It&#8217;s an untapped market for e-commerce, as Tumblr users who want to sell currently have to use a service like Shopify or Ecwid and generate a Tumblr-compatible widget.</p>
<p>Mullenweg said the acquisition hasn&#8217;t closed yet but Automattic may explore e-commerce on Tumblr in 2020.</p>
<p>&#8220;Once it closes there will be a few months of normal integration work and getting the teams working together, making sure we have harmonized policies on support, content moderation, anti-spam, ads, and all of those lower-level things,&#8221; he said. &#8220;Beyond that I’ve seen what you’re seeing — a lot of Tumblr users want access to more customization and e-Commerce. There are no specific plans yet but I imagine that’s something the team will consider for next year’s roadmap.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Sep 2019 16:15:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Automattic’s Series D\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=50121\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://ma.tt/2019/09/series-d/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3727:\"<p>Today <a href=\"https://automattic.com/\">Automattic</a> announced it has closed a new $300 million Series D, with <a href=\"https://www.salesforce.com/company/ventures/\">Salesforce Ventures</a> taking the entire round. This puts us at a post-round valuation of $3 billion, three times what it was after our last fundraising round in 2014. It&#8217;s a tremendous vote of confidence for Automattic and for the open web.</p>



<p>I met <a href=\"https://twitter.com/Benioff\">Marc Benioff</a> earlier this year, and it became obvious to both of us that <a href=\"https://salesforce.com/\">Salesforce</a> and Automattic shared a lot of principles and philosophies. Marc is a mindful leader and his sensibilities and sense of purpose feel well aligned with our own mission to make the web a better place. He also helped open my eyes to the incredible traction WordPress <a href=\"https://wpvip.com/\">and WP VIP</a> has seen in the enterprise market, and how much potential there still is there. I’ve also loved re-connecting with <a href=\"https://twitter.com/btaylor\">Bret Taylor</a> who is now Salesforce’s President and Chief Product Officer. Bret’s <a href=\"https://en.wikipedia.org/wiki/Bret_Taylor\">experience</a> across Google Maps, Friendfeed, Facebook, Quip, and now transforming Salesforce makes him one of the singular product thinkers out there and our discussion of Automattic’s portfolio of services have been very helpful already.</p>



<p>For Automattic, the funding will allow us to accelerate our roadmap (perhaps by double) and scale up our existing products—including <a href=\"https://wordpress.com/\">WordPress.com</a>, <a href=\"https://wpvip.com/\">WordPress VIP</a>, <a href=\"https://woocommerce.com/\">WooCommerce</a>, <a href=\"https://jetpack.com/\">Jetpack</a>, and (in a few days when it closes) <a href=\"https://www.tumblr.com/\">Tumblr</a>. It will also allow us to increase investing our time and energy into the future of the open source <a href=\"https://wordpress.org/\">WordPress</a> and <a href=\"https://wordpress.org/gutenberg/\">Gutenberg</a>.</p>



<p>The Salesforce funding is also a vote of confidence for the future of work. Automattic has grown to more than 950 employees working from 71 countries, with no central office for several years now. <a href=\"https://distributed.blog/\">Distributed work</a> is going to reshape how we spread opportunity more equitably around the world. There continue to be new heights shown of what can be achieved in a distributed fashion, with <a href=\"https://about.gitlab.com/2019/09/17/gitlab-series-e-funding/\">Gitlab announcing a round at $2.75B earlier this week</a>.</p>



<p>Next year Automattic celebrates 15 years as a company! The timing is fortuitous as we&#8217;ve all just returned from <a href=\"https://ma.tt/2018/10/the-importance-of-meeting-in-person/\">Automattic&#8217;s annual Grand Meetup</a>, where more than 800 of us got together in person to share our experiences, explore new ideas, and have some fun. I am giddy to work alongside these wonderful people for another 15 years and beyond.</p>



<p>If you&#8217;re curious my previous posts on our fundraising, here&#8217;s our <a href=\"https://ma.tt/2006/04/a-little-funding/\">2006 Series A</a>, <a href=\"https://ma.tt/2008/01/act-two/\">2008 Series B</a>, <a href=\"https://ma.tt/2013/05/automattic-secondary/\">2013 secondary</a>, and <a href=\"https://ma.tt/2014/05/new-funding-for-automattic/\">2014 Series C</a>. As before, happy to answer questions in the comments here. <a href=\"https://techcrunch.com/2019/09/19/automattic-raises-300-million-at-3-billion-valuation-from-salesforce-ventures/\">I also did an exclusive interview with Romain Dillet on (WP-powered) Techcrunch</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Sep 2019 13:01:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"WPTavern: Gutenberg 6.5 Adds Experimental Block Directory Search to Inserter and New Social Links Block\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=94000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"https://wptavern.com/gutenberg-6-5-adds-experimental-block-directory-search-to-inserter-and-new-social-links-block\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3773:\"<p>Gutenberg 6.5 was released today with a rough prototype that adds one-click search and installation of blocks from the block directory to the inserter. Selected blocks are automatically installed as a plugin in the background and inserted into the editor with one click.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/block-directory-experiment.gif?ssl=1\"><img /></a></p>
<p>The <a href=\"https://github.com/WordPress/gutenberg/pull/17431\" rel=\"noopener noreferrer\" target=\"_blank\">pull request</a> for the experiment indicates that it&#8217;s still very much a work in progress. It extends the inserter to fetch a list of suggestBlocks similar to reusableBlocks, and the list is currently served from a mock API.</p>
<p>The prototype is can be turned on under the <strong>Gutenberg > Experiments</strong> menu, a relatively new Settings page that was <a href=\"https://github.com/WordPress/gutenberg/pull/16626\" rel=\"noopener noreferrer\" target=\"_blank\">added in Gutenberg 6.3</a>. This menu also allows testers to enable the experimental Navigation Menu Block, Widgets Screen, and Legacy Widget Block.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-18-at-8.46.59-PM.png?ssl=1\"><img /></a></p>
<p>Block Navigation has also been added to the experimental Navigation Block in this release. This addition is considered a first start that is expected to evolve over time.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/09/block-navigator.png?ssl=1\"><img /></a></p>
<p>&#8220;Regardless of how the UI evolves for this block, I think there will always be a need for representing the menu structure as a child block tree with all menu hierarchies mapped out consistently and not hidden (dropdowns, etc),&#8221; Gutenberg engineer Matias Ventura <a href=\"https://github.com/WordPress/gutenberg/issues/16812\" rel=\"noopener noreferrer\" target=\"_blank\">said</a>.</p>
<p>&#8220;Luckily, we already have a view that handles that representation in the &#8216;block navigator.&#8217; That means if the navigation menu block is represented through child blocks, we&#8217;ll get this view for free.&#8221;</p>
<p>In the future, Gutenberg engineers may allow for drag-and-drop reordering of items in the navigator and may explore rendering the view inline or in a modal launched from the navigation menu block.</p>
<h3>Gutenberg 6.5 Adds New Social Links Block</h3>
<p>Gutenberg 6.5 also adds a new social links block under the widgets panel. It allows users to place social links anywhere within the content by clicking on the icons and pasting in their social URLs. The gif below demonstrates how the block works, although the grey placeholder icons have since been removed in favor of opacity changes to indicate unconfigured blocks.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/social-links-block.gif?ssl=1\"><img /></a></p>
<p>This release introduces a handful of other notable updates, including support for <a href=\"https://github.com/WordPress/gutenberg/pull/17253\" rel=\"noopener noreferrer\" target=\"_blank\">border radius changes in the button block</a>, support for <a href=\"https://github.com/WordPress/gutenberg/pull/17101\" rel=\"noopener noreferrer\" target=\"_blank\">adding captions to images in the Gallery block</a>, and the addition of <a href=\"https://github.com/WordPress/gutenberg/pull/16490\" rel=\"noopener noreferrer\" target=\"_blank\">local autosaves</a>.</p>
<p>The 6.5 release post has not yet been published but the plugin update is available in the admin and a full list of enhancements and bug fixes can be found in the <a href=\"https://wordpress.org/plugins/gutenberg/#developers\" rel=\"noopener noreferrer\" target=\"_blank\">changelog</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Sep 2019 03:41:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"WPTavern: EditorsKit Adds Nofollow Options for Links, Fixes Bug with Gutenberg Metaboxes Overlapping in Chrome\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93971\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:120:\"https://wptavern.com/editorskit-adds-nofollow-options-for-links-fixes-bug-with-gutenberg-metaboxes-overlapping-in-chrome\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3528:\"<p><a href=\"https://wordpress.org/plugins/block-options/\" rel=\"noopener noreferrer\" target=\"_blank\">EditorsKit</a> is becoming somewhat of a &#8220;hotfix&#8221; plugin for Gutenberg, especially with the additions to the 1.14 release this week. Developer Jeffrey Carandang added new link formats for nofollow rel attribute options, along with a fix for an annoying bug in Chrome that causes Gutenberg metaboxes to overlap. He has been closely monitoring feedback on both Gutenberg and EditorsKit, introducing features for which users have an immediate need.</p>
<p>Google recently announced <a href=\"https://wptavern.com/google-announces-new-ways-to-identify-nofollow-links-progress-on-related-gutenberg-ticket-is-currently-stalled\" rel=\"noopener noreferrer\" target=\"_blank\">new ways to identify nofollow links</a> with two additional rel attribute options for specifying links as sponsored and/or user-generated content. The Gutenberg core team has expressed hesitation on a <a href=\"https://github.com/WordPress/gutenberg/pull/16609#issuecomment-527921959\">PR that would add nofollow link options</a>, invoking WordPress&#8217; <a href=\"https://wordpress.org/about/philosophy/\" rel=\"noopener noreferrer\" target=\"_blank\">80/20 rule</a>.</p>
<p>Since the related PR doesn&#8217;t seem to be a priority, with no movement for two weeks, Carandang decided to add the nofollow and sponsored rel attribute options to EditorsKit, so users can start following Google&#8217;s recommendations without having to switch to HTML mode. He also managed to make it work with the version of Gutenberg included in core.</p>
<p><a href=\"https://cloudup.com/cqP3APNEF3j\"><img src=\"https://i1.wp.com/cldup.com/kLcfVSl1UW.gif?resize=627%2C495&ssl=1\" alt=\"Nofollow link options\" width=\"627\" height=\"495\" /></a></p>
<p>Chrome users may have noticed that <a href=\"https://github.com/WordPress/gutenberg/issues/17406\" rel=\"noopener noreferrer\" target=\"_blank\">the block editor has a nasty bug with metaboxes overlapping</a>, obscuring the main content area. This problem was introduced in the recent Chrome 77 update and is present on WordPress 5.2.3 and older versions.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/metabox-overlapping.png?ssl=1\"><img /></a></p>
<p>Chrome developers are aware of the issue and a fix will be in the next release. Version 78 is expected October 22. Since it is a bug with Chrome, the Gutenberg team has opted not to release a fix/workaround for this problem. In the meantime, they recommend updating to WordPress 5.3 if it is released before the Chrome bug is fixed. This isn&#8217;t likely, as 5.3 is scheduled for mid-November.</p>
<p>The Gutenberg team also recommend using a different browser or installing the Gutenberg plugin to fix the issue. Andrea Fercia noted on the ticket that the plugin is still listed among WordPress&#8217; beta plugins and may not be advisable to use in production on some sites. Users with a technical background can implement one of several CSS solutions in the ticket, but this is a frustrating bug for users who don&#8217;t know how to apply code fixes.</p>
<p>Carandang added a fix for this bug to the most recent version of EditorsKit. So far his strategy of being responsive to users&#8217; requests seems to have been successful, as his Gutenberg utility plugin now has more than 1,000 active installs. He said he is happy to add hot fixes for EditorsKit users and will remove them once the fixes have been added to Chrome and/or the block editor.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 18 Sep 2019 19:42:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"WPTavern: Behind New Packages Project Lead, Theme Review Team Launches Admin Notices Solution\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93936\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"https://wptavern.com/behind-new-packages-project-lead-theme-review-team-launches-admin-notices-solution\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7754:\"<p>As part of the WordPress Theme Review Team&#8217;s plan to <a href=\"https://wptavern.com/wordpress-theme-review-team-seeks-to-curb-obtrusive-admin-notices-with-new-requirement-to-follow-core-design-patterns\">curb obtrusive admin notices</a>, the team pushed version 1.0 of its <a href=\"https://github.com/WPTRT/admin-notices\">Admin Notices</a> package to the public.  The new package provides a standard API for theme authors to display admin notices.</p>



<p>Ari Stathopoulos took over as the packages project lead in late August.  Stathopoulos is the primary developer and creator of the highly-rated <a href=\"https://kirki.org/\">Kirki customizer framework</a>, which currently has 300,000+ active installs as a plugin.  However, the framework is also available as separate modules that theme authors can bundle within their themes.</p>



<p>The Admin Notices package is the third package produced by the team and the first that Stathopoulos has spearheaded.</p>



<p>Adding a basic admin notice in WordPress is relatively easy for most developers. However, handling features such as persistent dismissible actions is more complex.  The Admin Notices package handles this out of the box.</p>



<p>Some options for the package include the ability to:</p>



<ul><li>Set a title and message.</li><li>Select a type that adds in the appropriate UI class (info, success, warning, error).</li><li>Choose which admin screens the notice appears on.</li><li>Limit the message by user capability so that it doesn&#8217;t appear for all users.</li></ul>



<div class=\"wp-block-image\"><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/wptrt-admin-notices-002.png?ssl=1\" target=\"_blank\" rel=\"noreferrer noopener\"><img /></a></div>



<p>The above screenshot shows an example of a basic admin notice output for the four available types.  The dismiss action is handled by JavaScript and works without reloading the page.  Once dismissed, users will no longer see the notice.</p>



<p>&#8220;I think the hardest thing about it was deciding how restrictive we wanted it to be,&#8221; said Stathopoulos of the challenges building this package. The package restricts theme authors to paragraph, link, bold, and italic elements in version 1.0.  It doesn&#8217;t leave a lot of room for experimentation, but standardization is the goal.  The more elements allowed, the more likely the tool doesn&#8217;t solve the team&#8217;s problem of keeping admin notices unobtrusive.</p>



<h2>User Notifications Are a Complex Problem</h2>



<p>WordPress doesn&#8217;t provide a formal API for user notifications.  However, it does provide a standard set of CSS classes and a hook for attaching notices.  The Codex also has some examples of <a href=\"https://codex.wordpress.org/Plugin_API/Action_Reference/admin_notices\">best practices</a>.  The lack of a formal API has left theme and plugin authors to their own devices.  Users have suffered because of wildly varying implementations and common issues such as <a href=\"https://wptavern.com/please-stop-abusing-wordpress-admin-notices\">non-dismissible advertisements</a>.</p>



<p>Tim Hengeveld <a href=\"https://core.trac.wordpress.org/ticket/43484\">proposed a Notification Center API</a> on Trac in 2018.  The ticket has a healthy, ongoing discussion and some UI proposals.  The proposal is still marked as &#8220;Awaiting Review,&#8221; and it&#8217;s unlikely that it&#8217;ll ship anytime sooner than WordPress 5.4 or later.</p>



<p>Currently, many plugins and themes also use admin notices for user onboarding, which is a separate problem in need of a solution.  There&#8217;s a 4-year-old ticket that discusses <a href=\"https://core.trac.wordpress.org/ticket/34116\">WordPress new-user onboarding</a>, but there&#8217;s not much movement to solve this problem for plugins and themes.</p>



<p>While the TRT&#8217;s package doesn&#8217;t tackle all issues associated with user notifications, it does help limit some of the short-term damage.</p>



<h2>More Packages in the Works</h2>



<p>More packages are currently being built and others are in the planning stages.</p>



<p>The goal of the overall project is to provide theme authors with drop-in modules they can bundle with their themes.  The packages are all written in PHP 5.6+ in hopes to push theme authors toward more modern coding practices (relatively speaking, since PHP 7.4 will be released this year).  It will also help streamline the review process if more theme authors adopt the packages rather than building everything in-house.</p>



<p>&#8220;If we build packages for the most-requested things, we&#8217;ll hopefully empower people to build quality themes easier,&#8221; explained Stathopoulos.  &#8220;I think of packages as building blocks for themes.&#8221;</p>



<p>Stathopoulos is working on a customizer control for selecting a color with alpha transparency, which could be released as early as next week.  It will provide theme users with more control over how their colors appear for themes that implement it.</p>



<p>&#8220;After we build the basics I want to focus on packages that would enhance a11y and privacy in themes &#8211; two areas where themes are falling short,&#8221; he said.  &#8220;It would help a lot of people, and that is ultimately our goal.&#8221;</p>



<p>Theme authors have grown accustomed to installing JavaScript and CSS packages via NPM over the past few years.  However, their use of Composer as a PHP dependency manager has lagged.  In some part, this could be due to WordPress&#8217; previous reluctance to bump its minimum version of PHP.  Many packages available on Packagist, the main Composer repository, do not work with older versions of PHP.  WordPress&#8217; recent jump to PHP 5.6+ and plans to move to 7+ in the future may push more theme authors to consider PHP dependency management.</p>



<p>The TRT has a <a href=\"https://packagist.org/packages/wptrt/\">Packagist account</a> and has made all of its packages installable via Composer.</p>



<h2>No Requirement to Use Packages Yet</h2>



<p>There are no current plans for the TRT to start requiring the use of these packages for specific features, but a few team members have proposed doing so.</p>



<p>&#8220;There are valid reasons to enforce the use of these packages, but it can&#8217;t happen overnight,&#8221; said Stathopoulos. &#8220;We want themes in the repository to have some standards, it can not be the wild west. Code quality has to improve. These packages are a way to make life easier for people, and ultimately save time for everyone.&#8221;</p>



<p>Stathopoulos is open to theme authors building custom implementations if they can improve upon what the team has built, but he prefers that authors &#8220;discuss their ideas in the package repository and submit a pull-request so that the whole community can benefit.&#8221;</p>



<p>Getting theme authors involved is one area where the team has struggled.  Contributing to the packages could benefit the entire community.  &#8220;Most people don&#8217;t even know about them since they are not listed anywhere,&#8221; said Stathopoulos.  &#8220;Theme Authors currently have to look for them, and in order to look for them someone needs to tell them they exist (which doesn&#8217;t happen).&#8221;  One of the next steps would be getting the packages listed in the TRT&#8217;s documentation.</p>



<p>Working together on common theme features could provide a bridge between theme authors and reviewers, allowing them to solve issues together.</p>



<hr class=\"wp-block-separator\" />



<p><em>Note: The author of this article was involved with the initial theme packages proposal and a developer on its initial package releases.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 18 Sep 2019 18:06:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"HeroPress: Life Stacks Up –  From A Small Town Boy To A Geek Entrepreneur\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2963\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:192:\"https://heropress.com/essays/life-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur/#utm_source=rss&utm_medium=rss&utm_campaign=life-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10001:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2019/09/091719-min-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: For me, WordPress means freedom, self expression, and adaptability.\" /><p>A six year old is in deep thought. His gaze stuck on an intricate structure made with wooden sticks – a large rectangular box in the centre, a tall stick, some knitting threads running up and down. All this is arranged in a shelf in a common terrace wall of two middle class Indian homes.</p>
<p>The boy is holding what seems like a paper cup telephone – two paper cups with a thread running between. Soon, he smiles and throws one paper cup over the wall to the other side. His counterpart on the other side picks up his side of the &#8220;telephone&#8221; and they start talking.</p>
<p>&#8220;I made a TV using the sticks. I&#8217;m now going to set up a power line&#8230;&#8221;</p>
<p>&#8220;Awesome, I&#8217;ll be there after my homework!&#8221;</p>
<p>Aha! Now it makes sense. The kids are pretend-playing, and this one in particular is into science and model making. He has made an elaborate television model with limited resources.</p>
<p>Fast forward six years, and the boy is writing programs on a school computer. Couple years later he’s making model rockets and planes.</p>
<p>Fast forward another six years, and the boy is sitting with Bill Gates, being one of the eight national winners in a competition.</p>
<p>He goes on to launch India&#8217;s first electronic magazine, a web solutions business, local language versions of Linux and OpenOffice, a content management system, few books and a string of businesses that have made millions of dollars.</p>
<p>And he fondly remembers meeting Matt Mullenweg and Chris Lema at WordCamp San Francisco in 2014. His web agency business had gone bust around 2011, and his WordPress plugins business was picking up. Those meetings strengthened his conviction for WordPress and he doubled down on his plugins. Today his team takes care of 200,000+ active users across two dozen of their plugins – both free and premium.</p>
<p>That small town boy is me.</p>
<h3>Who I Am</h3>
<p>My name is Nirav Mehta. I live in Mumbai, and I&#8217;m super passionate content, commerce and contribution. I run three businesses – two in WordPress (<a href=\"https://www.storeapps.org/\">StoreApps.org</a> – where we solve problems for growing WooCommerce stores,<a href=\"http://icegram.com/\"> Icegram.com</a> – where creators find tools to inspire, engage and convert their audiences), and one SaaS business (<a href=\"https://www.putler.com/\">Putler</a> – meaningful analytics for e-commerce).</p>
<p>I have done some or other form of writing for over two decades. I&#8217;ve done open source for my whole life and used Drupal and Joomla earlier. As a matter of fact, I created a content management system using PHP back in 2000. But I liked the simplicity and community of WordPress. So when I wanted to start two blogs in 2006, I jumped on to WordPress.</p>
<blockquote><p>And it was amazing. WordPress simplified a whole lot of things, allowed customization and had extensive plugin ecosystem.</p></blockquote>
<p>I continued blogging and tinkering with WordPress. WordPress kept growing, and when I was looking for &#8220;the next big thing&#8221; around 2011, I figured I can bet on e-commerce with WordPress.</p>
<p>There was no WooCommerce back then, and we built an extension to WPeC – an e-commerce plugin that was popular at that time. Smart Manager – the plugin we built – allowed managing products, orders and customers using an easy spreadsheet like interface. It quickly became popular. When WooCommerce came along, we ported our WPeC plugins to WooCommerce, and also became an official third-party developers with our Smart Coupons plugin. StoreApps – our WooCommerce plugins business continues to be our top business today.</p>
<p>WordPress has changed my life. For me, WordPress means freedom, self expression and adaptability.</p>
<h3>Where I Came From</h3>
<p>I&#8217;m from a small town, I am not an engineer, I didn&#8217;t do an MBA. I don&#8217;t have a godfather. But I&#8217;ve always wanted to contribute to a larger community, I&#8217;m a stickler for elegant solutions that solve practical problems and I&#8217;m ready to delay gratification. I believe grit and humility are essential. I&#8217;m a curious lifetime learner. I&#8217;ve realized that money is important, it&#8217;s a great resource. But I&#8217;ve also learnt that the joy of seeing someone benefit from your work far surpasses anything else.</p>
<p>WordPress fits perfectly here. It gives me a platform to reach out to the whole world. It&#8217;s built on community and greater good. There are lots of opportunities and entry barriers are low.</p>
<h3>What WordPress Has Given Me</h3>
<p>WordPress allowed me to exercise my creative skills and easily build solutions on top of the core platform. I am not a great marketer, and WordPress and WooCommerce enabled me to build strong businesses by tapping into their distribution prowess. WordPress was easy to learn, so when we found people with the right mindset, they became productive soon.</p>
<p>Icegram – our onsite and email marketing plugins business – is a clear example of the power of WordPress. Icegram Engage shows popups, header-footer bars and many other types of visitor engagement and call to action messages. Maintaining such a solution on a large scale would require huge server costs and sys-op efforts. We could avoid all that because we could keep most of the functionality in WordPress. It also provided a cleaner and much better user experience than typical SaaS solutions. When I wrote the initial code for it, I wanted to keep the frontend logic in JavaScript – and of course, WordPress allowed doing that. Eventually, it was also easy to migrate to a hybrid model – where complex functions are performed on our servers and rest remains in WordPress.</p>
<blockquote><p>WordPress has given me great friends. I&#8217;ve met so many talented people online and at WordCamps! Me and my WordPress friends have done amazing adventures together! And the circle keeps expanding. You will find amazing people in WordPress!</p></blockquote>
<p>When you look at my life, and if important events were plotted as a chart, you won&#8217;t see a straight curve. It&#8217;s a bundle of long lull-times with gyrating ups and downs in between. I studied behavior patterns, data modelling and visualization for Putler – our multi-system analytics solution for online businesses. I also get to see numbers from many other businesses. I wanted to analyze how businesses work. What causes success.</p>
<p>And one big, common takeaway &#8211; in both business and life &#8211; is that results are non-linear. There is no single cause to any result.</p>
<h3>Back To You</h3>
<p>It all starts simple. What you do today, is shaped by something you did earlier, and will shape something else you&#8217;ll do in the future.</p>
<p>Every little act of courage, every little getting out of your comfort zone, every new thing you learn, every setback, every little success&#8230; It all keeps building who you are.</p>
<p>You see, life stacks up!</p>
<p>Do not despair, do not lose faith. Series of actions produce a result, and you have the ability to act.</p>
<p>So stay on!</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Life Stacks Up &#8211;  From A Small Town Boy To A Geek Entrepreneur\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Life%20Stacks%20Up%20%2D%20%20From%20A%20Small%20Town%20Boy%20To%20A%20Geek%20Entrepreneur&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Flife-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Life Stacks Up &#8211;  From A Small Town Boy To A Geek Entrepreneur\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Flife-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Flife-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur%2F&title=Life+Stacks+Up+%26%238211%3B++From+A+Small+Town+Boy+To+A+Geek+Entrepreneur\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Life Stacks Up &#8211;  From A Small Town Boy To A Geek Entrepreneur\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/life-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur/&media=https://heropress.com/wp-content/uploads/2019/09/091719-min-150x150.jpg&description=Life Stacks Up -  From A Small Town Boy To A Geek Entrepreneur\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Life Stacks Up &#8211;  From A Small Town Boy To A Geek Entrepreneur\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/life-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur/\" title=\"Life Stacks Up &#8211;  From A Small Town Boy To A Geek Entrepreneur\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/life-stacks-up-from-a-small-town-boy-to-a-geek-entrepreneur/\">Life Stacks Up &#8211;  From A Small Town Boy To A Geek Entrepreneur</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 18 Sep 2019 03:00:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Nirav Mehta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: GPL Author Richard Stallman Resigns from Free Software Foundation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93898\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"https://wptavern.com/gpl-author-richard-stallman-resigns-from-free-software-foundation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8749:\"<p><a href=\"https://stallman.org/\" rel=\"noopener noreferrer\" target=\"_blank\">Richard Stallman</a>, free software movement activist and originator of the &#8220;copyleft&#8221; concept, has <a href=\"https://www.fsf.org/news/richard-m-stallman-resigns\" rel=\"noopener noreferrer\" target=\"_blank\">resigned from his position as director of the board and president of the Free Software Foundation (FSF)</a>, which he established in 1985. This resignation comes on the heels of his resignation from MIT’s Computer Science and Artificial Intelligence Lab (CSAIL) after remarks he made regarding a 17-year old victim of sex trafficker Jeffrey Epstein, characterizing her as seeming “entirely willing.”</p>
<p>Stallman <a href=\"https://www.stallman.org/archives/2019-jul-oct.html#14_September_2019_(Statements_about_Epstein)\" rel=\"noopener noreferrer\" target=\"_blank\">blamed media coverage</a> for misinterpreting his comments as a defense of Epstein two days before announcing his <a href=\"https://www.stallman.org/archives/2019-jul-oct.html#16_September_2019_(Resignation)\" rel=\"noopener noreferrer\" target=\"_blank\">resignation from MIT</a> on his personal blog:</p>
<blockquote><p>To the MIT community, I am resigning effective immediately from my position in CSAIL at MIT. I am doing this due to pressure on MIT and me over a series of misunderstandings and mischaracterizations.</p></blockquote>
<p>The remarks in question were sent on a department-wide CSAIL mailing list in response to an MIT student email calling for a protest against Jeffrey Epstein’s donation to the school. Selam Jie Gano, the MIT graduate who exposed Stallman&#8217;s comments in a <a href=\"https://medium.com/@selamie/remove-richard-stallman-fec6ec210794\" rel=\"noopener noreferrer\" target=\"_blank\">post</a> on Medium, also leaked the full thread to <a href=\"https://www.vice.com/en_us/article/9ke3ke/famed-computer-scientist-richard-stallman-described-epstein-victims-as-entirely-willing\" rel=\"noopener noreferrer\" target=\"_blank\">Vice</a>.</p>
<p>In the email thread, which was also circulated to undergraduate students, Stallman became pedantic about the definition of assault and the use of the term &#8216;rape&#8217; after a student pointed out the laws of the location and the victim&#8217;s age:</p>
<blockquote><p>I think it is morally absurd to define “rape” in a way that depends on minor details such as which country it was in or whether the victim was 18 years old or 17.</p></blockquote>
<p>These comments caused media organizations to dig up old posts from Stallman&#8217;s blog where he <a href=\"https://stallman.org/archives/2012-jul-oct.html#15_September_2012_(Censorship_of_child_pornography)\" rel=\"noopener noreferrer\" target=\"_blank\">demands an end to the censorship of &#8220;child pornography&#8221;</a> and <a href=\"https://stallman.org/archives/2006-may-aug.html?fbclid=IwAR09M66FT8o8cYpAZCkW07KCWwNtXWJgvAz02H5K6_iwrGyWIhY24OuJ5Js#05%20June%202006%20(Dutch%20paedophiles%20form%20political%20party)\" rel=\"noopener noreferrer\" target=\"_blank\">says</a> he is &#8220;skeptical of the claim that voluntarily pedophilia harms children.&#8221;</p>
<p>Why Stallman felt it necessary to lend his controversial views to public comments on rape, assault, and child sex trafficking on a public mailing list is a mystery, but he has a long history of being outspoken when it comes to politics and civil liberties.</p>
<p>This particular incident seemed to be the straw that broke the camel&#8217;s back, unleashing a flood of outrage from the the free software and broader tech communities who demanded Stallman&#8217;s removal from the FSF. Critics cited two decades of behaviors and statements that many have found to be disturbing and offensive. The Geek Feminism Wiki maintains a <a href=\"https://geekfeminism.wikia.org/wiki/Richard_Stallman\" rel=\"noopener noreferrer\" target=\"_blank\">catalog</a> that includes some of these references.</p>
<p>&#8220;The free software community looks the other way while they build their empires on licenses that sustain Stallman&#8217;s power,&#8221; Software engineer  and founder of RailsBridge Sarah Mei <a href=\"https://twitter.com/sarahmei/status/1172283772428906496\" rel=\"noopener noreferrer\" target=\"_blank\">said</a> in a Tweetstorm calling on the FSF to remove Stallman from his positions of influence.</p>
<p>&#8220;Your refusal to part ways with him &#8211; despite well-known incidents that have pushed women and others out of free software for decades &#8211; might have been ok 10 years ago. Maybe even two years ago. It&#8217;s not ok now.&#8221;</p>
<p>The Software Freedom Conservancy also issued a <a href=\"https://sfconservancy.org/news/2019/sep/16/rms-does-not-speak-for-us/\" rel=\"noopener noreferrer\" target=\"_blank\">statement</a> calling for Stallman&#8217;s removal, titled &#8220;Richard Stallman Does Not and Cannot Speak for the Free Software Movement:&#8221;</p>
<blockquote><p>When considered with other reprehensible comments he has published over the years, these incidents form a pattern of behavior that is incompatible with the goals of the free software movement. We call for Stallman to step down from positions of leadership in our movement.</p>
<p>We reject any association with an individual whose words and actions subvert these goals. We look forward to seeing the FSF&#8217;s action in this matter and want to underscore that allowing Stallman to continue to hold a leadership position would be an unacceptable compromise. Most importantly, we cannot support anyone, directly or indirectly, who condones the endangerment of vulnerable people by rationalizing any part of predator behavior.</p></blockquote>
<p>In a <a href=\"https://twitter.com/sarahmei/status/817378684638068736\" rel=\"noopener noreferrer\" target=\"_blank\">2017 Twitter thread</a>, Mei shared some context on her perspective of how Stallman&#8217;s influence has had a ripple effect of damage throughout the free software and open source communities:</p>
<blockquote><p>In the 90s, Richard Stallman&#8217;s attitude towards women alienated me (and many others) from any interest in or support for &#8220;free software.&#8221; Viewing software through the Richard Stallman/GNU/&#8221;free as in freedom&#8221; lens would have run our industry into the ground. But it was the only alternative to proprietary software for ~20 years. So lots of folks worked on it despite finding Stallman problematic. This was the period when women largely declined to be part of computing, despite having pretty reasonable representation through the 80s.</p>
<p>In the early 2000s, &#8220;open source&#8221; was a breath of fresh air. All of the usefulness! None of the built-in arrogance, privilege, or misogyny! But just because it wasn&#8217;t built in doesn&#8217;t mean it disappeared. As folks converted, the behaviors normalized by Stallman and others followed. Our drive now for diversity/inclusion wasn&#8217;t even conceivable until we discarded GNU, Stallman, and &#8220;free software&#8221; in favor of &#8220;open source.&#8221; It&#8217;s not an accident that the communities who still, today, embrace that outdated philosophy are the least diverse and the most hostile.</p></blockquote>
<p>Stallman is the author of the GPL, which he wrote with the help of lawyers. For the most part, the free software community is able to objectively separate the license from the man who conceived it. The FSF&#8217;s sister organization in Europe <a href=\"https://fsfe.org/news/2019/news-20190917-01.html\" rel=\"noopener noreferrer\" target=\"_blank\">welcomed Stallman&#8217;s resignation</a>, echoing the sentiments of many who value his contributions but are unwilling to support his public representation of the organization:</p>
<blockquote><p>On 16 September, one of our independent sister organizations, the US-based Free Software Foundation (FSF), announced the resignation of Richard M. Stallman as its president. While we recognize Stallman&#8217;s role in founding the Free Software movement, we welcome the decision.</p></blockquote>
<p>The FSF has the opportunity to redefine itself after the resignation of its founder and supporters are hopeful that the free software movement can find a better way forward without Stallman&#8217;s influence.</p>
<p>&#8220;I believe in Free Software and have published most of my work open source under LGPL/GPL/AGPL (notably including Cydia, Cycript, WinterBoard, ldid, and now my work on Orchid),&#8221; software engineer Jay Freeman <a href=\"https://twitter.com/saurik/status/1173810527853670402\" rel=\"noopener noreferrer\" target=\"_blank\">said</a>. &#8220;I&#8217;m glad to see Richard Stallman leave, and hope this starts a new era for the Free Software Foundation.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Sep 2019 23:58:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Yoast to Reward Contributors with the Yoast Care Fund\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wptavern.com/yoast-to-reward-contributors-with-the-yoast-care-fund\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4284:\"<p>Yoast, a company primarily known for its popular Yoast SEO plugin, announced a new program earlier this month called <a href=\"https://yoast.com/yoast-care/\">Yoast Care</a>.  The project aims to reward volunteers in the WordPress community.  &#8220;Care&#8221; stands for &#8220;Community Appreciation REwards.&#8221;</p>



<p>Thousands of people contribute to WordPress.  Some choose to contribute code.  Others answer dozens of support questions every day in the forums.  Many spend their free time actively running or helping with the various <a href=\"https://make.wordpress.org\">Make WordPress</a> teams.  Many people do it because they love WordPress or have found a home within the community, but not all of them get paid for their work toward the open-source platform.</p>



<p>Contributing untold hours is often a thankless job.  The many millions of WordPress users will never know about the time and effort these volunteers pour into the project.  They are in the trenches doing the work that keeps WordPress running.  They don&#8217;t wear capes, but they are the unsung heroes of the community.</p>



<p>&#8220;We visit a lot of WordCamps and know a lot of people. We notice that some people have a hard time making a living from just their WordPress-work,&#8221; said Marieke van de Rakt, CEO of Yoast. &#8220;We wanted to do something for these people. We can&#8217;t hire them all.&#8221;</p>



<p>Yoast Care will grant $500 to around 50 volunteers each year.  The company has already set aside $25,000 for the first year and has an open application process for nominating contributors.</p>



<p>&#8220;We&#8217;re aiming for people that do not get paid for their work on WordPress,&#8221; said van de Rakt, founder of Yoast Academy and CEO of Yoast. &#8220;It has to be a person that is active in a Make WordPress team.&#8221;</p>



<p>Some within the community have noted that Yoast is a for-profit company and that such programs are more about PR.  At the heart of the discussion is whether the fund will obscure the longstanding issue of how to properly fund contributors to open-source projects ($500 only goes so far).  Others have pointed out that the program is a step in the right direction and could push other companies to follow suit.</p>



<p>The fund could help those who need it most.  It may help a volunteer replace their worn-out laptop, cover a freelancer during a low-income month, or boost someone in need of cash flow for their new WordPress project.</p>



<p>The application process is open for anyone to fill out, but applicants can&#8217;t throw their own names into the hat.  The form for applying also asks for up to 3 references to confirm the nominee&#8217;s work. The team has already received many applications.</p>



<p>Taco Verdonscho is leading the Yoast Care project for the company&#8217;s community team.  Such a program is no small task to run, and the rewards will be spread out through the year.  </p>



<p>&#8220;It is a lot of work,&#8221; said van de Rakt.  &#8220;They&#8217;ve really thought it through (what the demands are), so I think it&#8217;s rather easy to decide whether or not the application can be rewarded. But, still after that, we need to do an interview and make it happen financially. So there are a lot of people involved.&#8221;</p>



<p>Outside of a cash reward, Yoast will feature winners in a blog post that highlights his or her contributions to WordPress.</p>



<p>Yoast is not new to community outreach and funding those in need.  Last year, the team <a href=\"https://wptavern.com/yoast-launches-fund-to-increase-speaker-diversity-at-tech-conferences\">launched the Yoast Diversity Fund</a>.  The program was created to help minorities and other underrepresented groups afford to speak at conferences.  It covers travel, accommodations, childcare, and other costs.  The Diversity Fund is still <a href=\"https://yoast.com/yoast-diversity-fund/apply/\">accepting applications</a>.</p>



<p>Most within the inner WordPress community know at least one or two people who deserve some appreciation for all the work they do.  If you know someone who fits this description, you can nominate them via the <a href=\"https://yoast.com/community/yoast-care-fund/\">Yoast Care application page</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 17 Sep 2019 17:51:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"BuddyPress: BuddyPress 5.0.0 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=307797\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://buddypress.org/2019/09/buddypress-5-0-0-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2517:\"<p>Hello!</p>



<p>The first release candidate for BuddyPress 5.0.0 is now available for a last round of testing!</p>



<p>This is an important milestone as we progress toward the BuddyPress 5.0.0 final release date. &#8220;Release Candidate&#8221; means that we think the new version is ready for release, but with more than 200,000 active installs, hundreds of BuddyPress plugins and Thousands of WordPress themes, it’s possible something was missed. BuddPress 5.0.0 is&nbsp;scheduled to be released&nbsp;on&nbsp;<strong>Monday, September 30</strong>, but we need&nbsp;<em>your</em>&nbsp;help to get there—if you haven’t tried 5.0.0 yet, <strong>now is the time!</strong> </p>



<div class=\"wp-block-button aligncenter is-style-squared\"><a class=\"wp-block-button__link has-background\" href=\"https://downloads.wordpress.org/plugin/buddypress.5.0.0-RC1.zip\">Download and test the 5.0.0-RC1</a></div>



<div class=\"wp-block-spacer\"></div>



<p><em>PS: as usual you alternatively get a copy via our Subversion repository.</em></p>



<p>A detailed changelog will be part of our official release note, but&nbsp;you can get a quick overview by reading the post about the&nbsp;<a href=\"https://buddypress.org/2019/08/buddypress-5-0-0-beta1/\">5.0.0 Beta1</a>&nbsp;release.</p>



<div class=\"wp-block-image\"><img src=\"https://plugins.svn.wordpress.org/buddypress/assets/icon.svg\" alt=\"\" width=\"33\" height=\"33\" /></div>



<h2>Plugin and Theme Developers </h2>



<p>Please test your plugins and themes against BuddyPress 5.0.0. If you find compatibility problems, please be sure to post to this specific <a href=\"https://buddypress.org/support/topic/buddypress-5-0-0-release-candidate/\">support topic</a> so we can figure those out before the final release.</p>



<h2>Polyglots, we need you!</h2>



<p>Do you speak a language other than English?&nbsp;<a href=\"https://translate.wordpress.org/projects/wp-plugins/buddypress/\">Help us translate BuddyPress into many languages!</a>&nbsp;This release also marks the&nbsp;<a href=\"https://make.wordpress.org/polyglots/handbook/glossary/#string-freeze\">string freeze</a>&nbsp;point of the 5.0.0 release schedule.</p>



<p><strong>If you think you&#8217;ve found a bug</strong>, please let us know reporting it on&nbsp;<a href=\"https://buddypress.org/support\">the support forums</a>&nbsp;and/or&nbsp;on&nbsp;<a href=\"https://buddypress.trac.wordpress.org/\">our development tracker</a>.</p>



<p>Thanks in advance for giving the release candidate a test drive!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Sep 2019 23:15:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"imath\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: New Attock WordPress Meetup Empowers Pakistani Women Freelancers and Business Owners\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93733\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"https://wptavern.com/new-attock-wordpress-meetup-empowers-pakistani-women-freelancers-and-business-owners\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10042:\"<p><a href=\"https://2019.lahore.wordcamp.org/\" rel=\"noopener noreferrer\" target=\"_blank\">WordCamp Lahore</a> is getting rebooted on November 30 &#8211; December 1, at the National University of Computer and Emerging Sciences. The first edition of the event was planned for 2016 but was derailed by local disagreements and ultimately <a href=\"https://wptavern.com/karachi-to-host-first-wordcamp-in-pakistan-following-cancellation-of-wordcamp-lahore\" rel=\"noopener noreferrer\" target=\"_blank\">canceled</a>. For the past three years organizers have worked to strengthen their local meetup groups and follow suggestions from the WordPress Foundation before reapplying.</p>
<p>WordCamp Lahore lead organizer <a href=\"https://www.meshpros.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Muhammad Kashif</a> said his team is expecting more than 350 attendees, with the majority of them coming from the local community. The <a href=\"https://www.meetup.com/WordPress-Lahore/\" rel=\"noopener noreferrer\" target=\"_blank\">Lahore WordPress meetup group</a> is thriving and has grown to 4,383 members who regularly meet in various groups across the area.</p>
<p>&#8220;We still have attendees from other cities and in closing I encourage them to start local chapters and offer any help they need,&#8221; Kashif said. He works as a Master Trainer for a government training program called <a href=\"https://www.erozgaar.pitb.gov.pk/\" rel=\"noopener noreferrer\" target=\"_blank\">eRozgaar</a> that trains unemployed youth in more than <a href=\"https://www.erozgaar.pitb.gov.pk/#erb08\" rel=\"noopener noreferrer\" target=\"_blank\">25 centers</a> across Punjab. The program was launched by the Punjab Government in March 2017 and <a href=\"https://www.erozgaar.pitb.gov.pk/#erb06\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress is a major part of the eRozgaar curriculum</a>.</p>
<p>&#8220;I manage the WordPress curriculum and in a recent update I have included community building, which is about Meetups and WordCamp events,&#8221; Kashif said. He reports that eRozgaar trainees have collectively earned more than $1 million US dollars to date after going through the 3.5 month-program.</p>
<p>&#8220;The program is making a big impact, especially for women who can&#8217;t go out for jobs,&#8221; Kashif said. &#8220;They are making good money from freelancing and WordPress is playing a big part in that.&#8221;</p>
<p>Kashif attributes some of Pakistan&#8217;s current economic challenges to a rapidly growing population and poor planning from past governments. The job opportunities have not grown as fast as the population, which was one of the reasons the government created the eRozgaar training program.</p>
<p>As the result of having WordPress in the curriculum that is used across so many areas of Punjab, new meetups are starting to pop up in other cities. <a href=\"https://www.salmanoreen.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Salma Noreen</a>, one of the program&#8217;s trainers who Kashif worked with, started <a href=\"https://www.meetup.com/Attock-WordPress-Meetup/\" rel=\"noopener noreferrer\" target=\"_blank\">a meetup in Attock</a> and is the first female WordPress meetup organizer in Pakistan. She plans to apply for WordCamp Attock in 2020.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/09/this-too.jpg?ssl=1\"><img /></a>Salma Noreen, first female WordPress meetup organizer in Pakistan</p>
<p>&#8220;Attock is a small city but love for WordPress is big and I am so happy to see other women participating in the WordPress community,&#8221; Noreen said.</p>
<p>&#8220;Every year, 1000+ people graduate in this city after 16 years of education. But we don&#8217;t have many jobs in this small city, so a small number of people who are backed by financially good families can move to other big cities like Lahore and Karachi for jobs and learning opportunities. The remaining people&#8217;s future is always a question mark.</p>
<p>&#8220;Being a woman, I was more worried about women, as we have a cultural barrier that most women cannot get permission to relocate or go out of home for a regular 9 to 5 job. Introducing them to WordPress and then guiding them on how to find online clients has helped many to earn a decent living from home.&#8221;</p>
<p>For the past 10 years, Noreen worked primarily as a freelancer and has completed more than 3,500 projects in web development. She is mentoring new WordPress users in her city to become successful freelancers and online store owners using resources like Udemy courses, YouTube, public blogs, and the WordPress codex.</p>
<p>&#8220;I am still struggling but yes I am confident that one day everyone will be making enough from home,&#8221; she said.</p>
<p>The Attock WordPress meetup is averaging 60-70 attendees in recent months, where members share their knowledge, experience, and best practices. For many of those attending, the meetup group was their first introduction to the software. Noreen describes the local community as &#8220;crazy about WordPress&#8221; and eager to have their own WordCamp in 2020.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/group-photo-2.jpg?ssl=1\"><img /></a>Attock WordPress meetup</p>
<p>One meetup member, Uroosa Samman, is a graduate of Environmental Science studies but is now working with WordPress after attending the monthly meetups.</p>
<p>&#8220;I didn&#8217;t have any WordPress or coding background during my education,&#8221; Samman said. &#8220;It was difficult for me to learn tech things. The meetups were very helpful and motivational for me, so I decided to start working in tech. Since the events were organized by a female organizer, it was comfortable for us to attend. I am able to provide my services as a freelancer and I am developing my own WordPress e-commerce store. If I get stuck in any issue related to WordPress, I immediately contact this community and they are always ready to help each other.&#8221;</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/FB_IMG_1564500844418.jpg?ssl=1\"><img /></a>Women attending a recent Attock WordPress Meetup</p>
<p>Shahryar Amin, a recent college graduate, was uncertain about his future until he discovered WordPress through Noreen&#8217;s support and the Attock meetup:</p>
<blockquote><p>Just a few months ago, I was completely devastated financially. Pakistan is going through turbulent time, and its economy has never been performing this low. So, fresh graduates like me had their dreams absolutely shattered, when after four months of rigorous effort, we were unable to find a source of livelihood. That was truly a testing time.</p>
<p>Moving back to my small city, I was not much hopeful for the future. My hometown, Attock, is a remote city with limited opportunities to advance one’s career. But ironically, that turned out to be a wrong assumption. I moved back to my city after nearly four years, and it had some phenomenal changes which I couldn’t resist noticing. The most<br />
impressive of them was WordPress meetups. </p>
<p>That was the first time I became familiar with the platform. I was curious, and that got me to the very first meetup organized by Ms. Salma Noreen. She is a remarkable soul, and I can’t thank her more for putting up such effort for an ignored city like ours. I learned my basics from these meetups, and as my interest become my passion, I was spending more and more hours on learning WordPress through the internet. I had no programming skills, but fortunately one don’t need any to setup a website on WordPress. </p>
<p>As I delved further into it, I discovered some very useful plugins, like Elementor, Divi and Visual composer, and at that moment I decided to become a designer using WordPress. I won’t say that I have become an expert in WordPress, but I am paying back the community by sharing my knowledge as a speaker at the very last meetup on July 30. Also, I have been working as a freelance designer on various online platforms, and WordPress expertise has truly been rewarding me financially.</p></blockquote>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-16-at-3.01.35-PM.png?ssl=1\"><img /></a>Shahryar Amin speaking at a recent Attock WordPress meetup</p>
<p>Attock resident Sania Nisar has a degree in software engineering and used to spend several days creating a simple website before discovering WordPress. She has never had any formal training through paid courses but is now working as a WordPress professional with the knowledge she gained from attending WordPress meetups and online resources.</p>
<p>&#8220;WordPress Attock is playing a vital role in empowering women in my vicinity,&#8221; Nisar said. &#8220;It is difficult for the women of Attock to travel to big cities like Islamabad to gain knowledge. However, WordPress Attock has efficiently solved this problem by providing an engaging learning platform for the women of this city. Today I am a successful freelancer and a WordPress professional.&#8221;</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/09/meetup1.jpg?ssl=1\"><img /></a></p>
<p>Noreen said her team hopes to bring 15 to 20 people from Attock to attend WordCamp Lahore. The trip is expensive and takes approximately seven hours so not many will be able to make it but there will be other camps in the region that are nearer for Attock residents.</p>
<p>Last year a WordCamp was held in Islamabad, and the second WordCamp Karachi took place in August 2019. WordCamp Lahore will be Pakistan&#8217;s fourth WordCamp, held in the country&#8217;s second-most populous city. Attendees will have the opportunity to meet and connect with WordPress professionals and enthusiasts from across Pakistan. Speaker applications are open and sessions will be held in Urdu and English. Regular admission is Rs 1,700.00 and <a href=\"https://2019.lahore.wordcamp.org/tickets/\" rel=\"noopener noreferrer\" target=\"_blank\">tickets are now on sale</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Sep 2019 22:04:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WPTavern: Justin Tadlock Joins WP Tavern\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93843\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wptavern.com/justin-tadlock-joins-wp-tavern\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4839:\"<p>The kid scampered ahead of his classmates.  He wanted to be one of the first to set foot in the building, but he stopped as he got to the first step.  He looked up to count the floors.  One, two, three…it wasn&#8217;t <em>The Times</em>.  He was awestruck all the same.  <em>The Birmingham News</em>.</p>



<p>Truth be told, the kid was a man grown in 2007, but he was still a kid at heart.  His graduation was fast approaching.  He&#8217;d soon leave The Plains, his home of Auburn, Alabama.  He needed to get some experience at smaller, local papers before landing a job at <em>The Birmingham News</em>.  He didn&#8217;t know it while standing on those steps, but before the day was out, he&#8217;d return home and start filling out applications for every small paper across the state.</p>



<p>His only real experience with newspapers outside of university was reading about J. Jonah Jameson and Peter Parker or following the exploits of Clark Kent and Lois Lane.  He had this 1950s-esque picture in his mind of a cigar-smoking reporter wearing a cheap suit and fedora while pounding the keys of his typewriter.  He&#8217;d be working toward a Pulitzer-winning story.  Other reporters would sprint by his desk with their next big lead.  The editor would yell orders across the room as everyone rushed to beat the deadline.</p>



<p>Reality didn&#8217;t exactly match the picture in his mind.  The kid knew it wouldn&#8217;t.  On those steps of the recently-built news office, he&#8217;d need to let go of the fantasy.  He breathed deep and stepped forward at the instruction of his professor.</p>



<p>Field trips were a rare occurrence in college, but this professor was different.  His classroom was merely a part of the learning process.  Journalism was more than memorizing rules and writing a few papers each semester.  The only way to understand journalism was to step foot into an office and observe.</p>



<p>That&#8217;s the day the kid&#8217;s life changed forever.  He knew what he wanted to do after he graduated.  He wanted to work at a small-town newspaper by day and pen the great Southern American novel by night.</p>



<p>The roads people travel are rarely the direct route they set out on.</p>



<p>A few months later, the kid was living in Atlanta, Georgia, and traveling to Home Depots across half the state as a vendor.  During his summer in the Peach State, he got an opportunity to visit the CNN Center.  It was a thing of beauty.  With renewed vigor, he put in more applications at small papers.  Either no one was hiring or he didn&#8217;t have the experience.</p>



<p>He applied for other jobs.  Once he interviewed to be a used-car salesman.  However, he landed a job teaching in South Korea.  While imparting the few things he picked up about the English language to young minds, he began building his reputation in the WordPress community.  Before leaving the country, he&#8217;d bootstrapped his own WordPress theme shop in 2008.</p>



<p>After 11 years, the kid stumbled upon an opportunity to join the staff at WP Tavern, a chance to combine his passion for WordPress and writing.</p>



<p>Now a new chapter in his life begins.</p>



<h2>Allow Me to Introduce Myself</h2>



<p>My name is Justin Tadlock.  I&#8217;m the new staff writer for WP Tavern.  It&#8217;s my hope that I can bring a different perspective and produce many engaging stories for you to read long into the future.</p>



<p>You&#8217;ve probably used at least a few lines of my code to run your web site.  I&#8217;ve contributed to WordPress in some form or fashion since I started using the software in 2005.  I formerly ran Theme Hybrid, which was one of the earliest and longest-running theme shops in the WordPress ecosystem.  I also co-authored <em>Professional WordPress Plugin Development</em>.</p>



<p>Over the coming weeks and months, I plan to get to know more of you within the WordPress community.  I&#8217;ve been an avid reader of WP Tavern since its inception.  It&#8217;s always held a special place in my heart, and I want it to be an environment where everyone feels welcome to discuss all the things happening in the WordPress world.</p>



<p>It will take me a bit to get a feel for the new writing position and find my voice.  I may have a few hit-or-miss stories out of the gates, but I&#8217;m always open to feedback and criticism from our readers.  Ultimately, it&#8217;s my job to serve you the stories that you enjoy reading.</p>



<p>I&#8217;m stoked for the opportunity to get to know more of you.  I want to help you share your stories.  I want the community to know the people behind this platform that so many of us rely on in our personal and professional lives.</p>



<p>I hope I exceed your expectations for quality reporting and feature stories for WordPress.  Stay tuned.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Sep 2019 16:02:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"WPTavern: Adam Jacob Advocates for Building Healthy OSS Communities in “The War for the Soul of Open Source”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93730\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:117:\"https://wptavern.com/adam-jacob-advocates-for-building-healthy-oss-communities-in-the-war-for-the-soul-of-open-source\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3704:\"<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-13-at-1.40.07-PM.png?ssl=1\"><img /></a></p>
<p>Chef co-founder and former CTO <a href=\"https://twitter.com/adamhjk\" rel=\"noopener noreferrer\" target=\"_blank\">Adam Jacob</a> gave a short presentation at O&#8217;Reilly Open Source Software Conference (OSCON) 2019 titled &#8220;<a href=\"https://www.youtube.com/watch?v=8q5o-4pnxDQ\" rel=\"noopener noreferrer\" target=\"_blank\">The War for the Soul of Open Source</a>.&#8221; In his search for meaning in open source software today, Jacob confronts the notion of open source business models.</p>
<p>&#8220;We often talk about open source business models,&#8221; he said. &#8220;There isn&#8217;t an open source business model. That&#8217;s not a thing and the reason is open source is a channel. Open source is a way that you, in a business sense, get the software out to the people, the people use the software, and then they become a channel, which [companies] eventually try to turn into money.&#8221;</p>
<p>Companies often employ open source as a strategy to drive adoption, only to have mega corporations scoop up the software and corner the market. Jacob addressed the friction open source communities have with companies that use OSS to make billions of dollars per year running it as a service, citing Amazon Web Services (AWS) as a prime example.</p>
<p>Amid conflicts like these, it&#8217;s a challenge to find meaning in OSS via business. Jacob looked to organizations like the Free Software Foundation and Open Source Initiative but could not get on board with the methods and outcomes they pursue through their efforts.</p>
<p>He concluded that what is left is the people at the heart of OSS, who improbably come together with an overlapping sense of shared values and purpose.</p>
<p>&#8220;Each of us are a weird different shape, struggling to find our path and yet open source software gives us this ability to gather together around this resource that we turn from being scarce to being infinite,&#8221; he said.</p>
<p>&#8220;Look at your own desires, look at your own needs and the things you want in your own life. Then go out and find and build and steward communities with other people who share those values and who will embrace your purpose, and sustain each other. Because that is the true soul of open source.&#8221;</p>
<p>In December 2018, Jacob launched the <a href=\"https://sfosc.org/\" rel=\"noopener noreferrer\" target=\"_blank\">Sustainable Free and Open Source Communities</a> (SFOSC) project to advocate for these ideas. Instead of focusing on protecting revenue models of OSS companies, the project&#8217;s contributors work together to collaborate on writing core principles, social contracts, and business models as guidelines for healthy OSS communities.</p>
<p>&#8220;I believe we need to start talking about Open Source not in terms of licensing models, or business models (though those things matter): instead, we should be talking about wether or not we are building sustainable communities,&#8221; Jacob said in a <a href=\"https://medium.com/sustainable-free-and-open-source-communities/we-need-sustainable-free-and-open-source-communities-edf92723d619\" rel=\"noopener noreferrer\" target=\"_blank\">post</a> introducing the project. &#8220;What brings us together, as people, in this common effort around the software? What rights do we hold true for each other? What rights are we willing to trade in order to see more of the software in the world, through the investment of capital?&#8221;</p>
<p>Check out Jacob&#8217;s presentation below for a 13-minute condensed version of the inspiration behind the SFOSC project.</p>
<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Sep 2019 21:31:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Local Lightning Now in Public Beta with Major Performance Improvements\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93700\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"https://wptavern.com/local-lightning-now-in-public-beta-with-major-performance-improvements\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4418:\"<p>Flywheel put its new Local Lightning app into <a href=\"https://localbyflywheel.com/community/t/local-lightning-public-beta/14075\" rel=\"noopener noreferrer\" target=\"_blank\">public beta</a> this week. The app is an improved version of the company&#8217;s local WordPress development tool, formerly known as Pressmatic before Flywheel <a href=\"https://wptavern.com/flywheel-acquires-wordpress-local-development-tool-pressmatic\" rel=\"noopener noreferrer\" target=\"_blank\">acquired</a> it from Clay Griffiths and renamed it to &#8220;<a href=\"https://localbyflywheel.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Local by Flywheel</a>.&#8221;</p>
<p>Since its acquisition in 2016, Local has gained many fans, particularly developers who had grown tired of debugging local development environments. Local has proven to be a reliable app that saves many wasted hours. It also allows developers to quickly switch between PHP and MySQL versions as well as Apache and nginx.</p>
<p>Overall, Local users enjoy the app&#8217;s features but have found performance to be <a href=\"https://localbyflywheel.com/community/t/speed-issues-on-local-machine/360\" rel=\"noopener noreferrer\" target=\"_blank\">a continual issue</a>. Users reported having one-minute page loads in the backend, on small, uncomplicated sites. These speed issues began to drive users away from Local to other products, as many found that working locally was slower than creating a test site with their hosting companies.</p>
<p>Even booting up the app can be abysmally slow, as demonstrated in a video Griffiths shared announcing the Local Lightning beta:</p>
<p><a href=\"https://cloudup.com/cBmHR2MODnR\"><img src=\"https://i1.wp.com/cldup.com/K7hEKiIfjA.gif?resize=600%2C338&ssl=1\" alt=\"Local lightning comparison\" width=\"600\" height=\"338\" /></a></p>
<p>&#8220;To chart a more reliable and powerful path forward, we’re rebuilding Local’s core architecture and moving away from virtualization in favor of native, system-level software to run WordPress locally,&#8221; Griffiths said.</p>
<p>The new Local Lightning app reduces system requirements and the minimum disk space requirement has decreased by more than 18GB. Griffiths also reports that the download size for Local is 50% less than before.</p>
<p>Local is also now available on Linux, thanks to the new architecture in the updated app. Linux availability has been a frequent request since Local was originally launched.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\"><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f916.png\" alt=\"🤖\" class=\"wp-smiley\" /> Hey, guess what? LOCAL IS NOW AVAILABLE FOR LINUX!</p>
<p><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f427.png\" alt=\"🐧\" class=\"wp-smiley\" /> We’ve built it into the public beta of Local Lightning. </p>
<p><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/26a1.png\" alt=\"⚡\" class=\"wp-smiley\" /> Get it here: <a href=\"https://t.co/7LOgLYWeLc\">https://t.co/7LOgLYWeLc</a> <a href=\"https://t.co/N6klXH6BKl\">pic.twitter.com/N6klXH6BKl</a></p>
<p>&mdash; Local by Flywheel (@LocalbyFlywheel) <a href=\"https://twitter.com/LocalbyFlywheel/status/1172175142883139584?ref_src=twsrc%5Etfw\">September 12, 2019</a></p></blockquote>
<p></p>
<p>Local Lightning and Local by Flywheel have been developed as two separate applications in order to allow users to migrate their sites at their own pace. They can also run alongside each other and are named differently. &#8220;Local by Flywheel&#8221; is now the old version and the new Local Lightning app is simply known as &#8220;Local.&#8221; Users can migrate their sites by exporting from the old version and dragging them into the new app for automatic import. The beta is lacking some features that were previously available, including hot-swapping development environments and support for Varnish HTTP Cache. Griffiths&#8217; team is working on restoring feature parity with the original app.</p>
<p>When asked in the product&#8217;s forums about the general release date, a Flywheel representative said that it &#8220;will definitely be by the end of the year.&#8221; Users who want to join the public beta can download the latest version for Mac, Windows, or Linux from the <a href=\"https://localbyflywheel.com/community/t/local-lightning-public-beta/14075\" rel=\"noopener noreferrer\" target=\"_blank\">Local Lightning announcement post</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Sep 2019 16:17:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: WPHindi Plugin Instantly Converts Text from English to Hindi in the Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=92869\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"https://wptavern.com/wphindi-plugin-instantly-converts-text-from-english-to-hindi-live-in-the-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3607:\"<p>Hindi is one of the world&#8217;s top languages, with more than 520 million native and non-native speakers, and is the <a href=\"https://thelogicalindian.com/news/hindi-fastest-growing-language/\" rel=\"noopener noreferrer\" target=\"_blank\">fastest growing language in India</a>. In a region where English is also commonly spoken, many Hindi publishers have the unique requirement of being able to switch back and forth between the two languages when writing articles.</p>
<p><a href=\"https://wordpress.org/plugins/wphindi/\" rel=\"noopener noreferrer\" target=\"_blank\">WPHindi</a> is a new plugin that was developed to help WordPress users stay inside the editor instead of copying and pasting from third-party tools.</p>
<p>It offers a block that instantly converts text from English to Hindi as users are typing. It also works with the Classic Editor. The block supports intelligent auto-suggestions that make it easy to correct typos. Users can quickly enable/disable WPHindi with one click when switching between languages. It also works seamlessly with the rich text options inside the editor.</p>
<p></p>
<p>The plugin was originally created by the team at <a href=\"https://www.zozuk.com\" rel=\"noopener noreferrer\" target=\"_blank\">Zozuk</a>, a WordPress support and maintenance service, as a custom solution for a client.</p>
<p>&#8220;They are a big publisher in the Hindi content space and with a lot of writers,&#8221; Zozuk representative Aditya Rathore said. &#8220;Using tools outside the WordPress dashboard was becoming a huge productivity killer for them.&#8221;</p>
<p>After this request Zozuk contacted 54 Hindi content publishers who are WordPress users and found that 39 of them were facing the same problem.</p>
<p>&#8220;It was more than enough to realize the scale of the problem and we decided to make the plugin available for free to every webmaster including our partners,&#8221; Rathore said. &#8220;The scale of the problem and how important it was to solve it, proved to be our element of inspiration for WPHindi.&#8221;</p>
<p>Data from a <a href=\"https://www.theatlas.com/charts/r1q1GxrJW\" rel=\"noopener noreferrer\" target=\"_blank\">KPMG-Google study</a> indicates that 201 million Hindi users, which comprise 38% of the Indian internet user base, will be online by 2021.</p>
<div class=\"atlas-chart\"><img src=\"https://i2.wp.com/s3.us-east-1.amazonaws.com/qz-production-atlas-assets/charts/atlas_r1q1GxrJW.png?w=627&ssl=1\" /></div>
<p></p>
<p>WPHindi is currently the only solution of its kind in the WordPress space. An older plugin called <a href=\"https://www.monusoft.com/products/wordpress-plugin\" rel=\"noopener noreferrer\" target=\"_blank\">Hindi Writer</a> performed a similar function for converting text in the comment box but it was not available from the official plugin directory and has not been updated since 2006.</p>
<p>Hindi publishers have also used tools like <a href=\"http://google.com/intl/hi/inputtools/try/\" rel=\"noopener noreferrer\" target=\"_blank\">google.com/intl/hi/inputtools/try/</a> and <a href=\"http://easyhindityping.com\" rel=\"noopener noreferrer\" target=\"_blank\">easyhindityping.com</a> but these are not tailored to WordPress and have to be open in a separate window. WPHindi provides text conversion directly in the editor, speeding up writers&#8217; workflow.</p>
<p>Rathore said Zozuk plans to monetize the plugin in the future with an add-on that will allow users to comment in Hindi on the frontend. The plugin is currently in development. The team is is also working on releasing similar plugins for other languages like Bengali and Marathi.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Sep 2019 18:52:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Richard Best Releases Free Audio and Ebook: “A Practical Guide to WordPress and the GPL”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93615\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"https://wptavern.com/richard-best-releases-free-audio-and-ebook-a-practical-guide-to-wordpress-and-the-gpl\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2768:\"<p>If you&#8217;re itching to go deeper into the legal aspects of navigating WordPress&#8217; relationship to the GPL license, <a href=\"https://richardbestlaw.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Richard Best</a> has recently made his ebook (and the audio version) called &#8220;<a href=\"https://richardbestlaw.com/2019/09/10/a-practical-guide-to-wordpress-and-the-gpl/\" rel=\"noopener noreferrer\" target=\"_blank\">A Practical Guide to WordPress and the GPL</a>&#8221; available for free. Best, a technology and public lawyer based in New Zealand, had previously sold the book with other products as part of a <a href=\"http://wpandlegalstuff.com/a-practical-guide-to-wordpress-and-the-gpl-get-it/\" rel=\"noopener noreferrer\" target=\"_blank\">business package</a> that is still available for purchase. After receiving feedback on his most recent post titled &#8220;<a href=\"http://wpandlegalstuff.com/taking-gpld-code-proprietary/\" rel=\"noopener noreferrer\" target=\"_blank\">Taking GPL’d code proprietary</a>,&#8221; he found that the issues addressed in the book are still relevant and decided to release it for free.</p>
<p>The first two sections provide a brief history of WordPress, its adoption of the GPL, and a summary of the license. These sections are a bit dry, but Chapter 3 is where it gets more interesting, particularly for theme and plugin developers who have questions about licensing GPL-derivatives. Best explores the practical application of the GPL in common business scenarios:</p>
<ul>
<li>If I modify the core WordPress software or a GPL’d theme or plugin, must I release the source code of the modified versions(s) to the public?</li>
<li>I’m a theme/plugin developer. I’ve put huge effort into writing my theme/plugin and I’m going to release it under the GPL but I want to make sure that everyone who receives my theme or plugin, even if from someone else, is obliged to pay me a licensing fee or notify me that they have it. Can I do that?</li>
<li>I’ve purchased some fully GPL’d themes or plugins from a commercial theme or plugin provider. May I sell those themes or plugins from my own website for my own benefit or publish those themes or plugins on my own website and give them away for free?</li>
</ul>
<p>Subsequent chapters cover controversies surrounding &#8220;GPL non-compliant&#8221; sales models, applications of copyright law, GPL compatibility with other licenses, and trademarks. Both the audio and the PDF ebook are <a href=\"https://richardbestlaw.com/2019/09/10/a-practical-guide-to-wordpress-and-the-gpl/\" rel=\"noopener noreferrer\" target=\"_blank\">available for download</a> on Best&#8217;s website. The text of the book is licensed under the Creative Commons Attribution 4.0 International License.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 11 Sep 2019 22:24:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"WPTavern: Google Announces New Ways to Identify Nofollow Links, Progress on Related Gutenberg Ticket Is Currently Stalled\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93592\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"https://wptavern.com/google-announces-new-ways-to-identify-nofollow-links-progress-on-related-gutenberg-ticket-is-currently-stalled\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4775:\"<p>This week Google <a href=\"https://webmasters.googleblog.com/2019/09/evolving-nofollow-new-ways-to-identify.html?fbclid=IwAR2pPFs1IaEfRNj7w_xPO1TLw-1RQSWwUeRiKjYZBwSENf7A1f426mDlz0I\" rel=\"noopener noreferrer\" target=\"_blank\">announced</a> changes to the 15-year old <a href=\"https://support.google.com/webmasters/answer/96569\" rel=\"noopener noreferrer\" target=\"_blank\">nofollow attribute</a> that was previously recommended for identifying links related to advertising, sponsors, or content for which users are not intending to pass along ranking credit. The nofollow attribute is no longer a catchall for these types of instances, as Google has introduced two new rel values (&#8220;sponsored&#8221; and &#8220;ugc&#8221;) to further specify the purpose of the link to the search engine:</p>
<ul>
<li><strong>rel=&#8221;sponsored&#8221;</strong>:</li>
<p> Use the sponsored attribute to identify links on your site that were created as part of advertisements, sponsorships or other compensation agreements.</p>
<li><strong>rel=&#8221;ugc&#8221;</strong>:</li>
<p> UGC stands for User Generated Content, and the ugc attribute value is recommended for links within user generated content, such as comments and forum posts.</p>
<li><strong>rel=&#8221;nofollow&#8221;</strong>:</li>
<p> Use this attribute for cases where you want to link to a page but don’t want to imply any type of endorsement, including passing along ranking credit to another page.
</ul>
<p>Google is also shifting to using a &#8220;hint model&#8221; for interpreting the new link attributes:</p>
<blockquote><p>When nofollow was introduced, Google would not count any link marked this way as a signal to use within our search algorithms. This has now changed. All the link attributes &#8212; sponsored, UGC and nofollow &#8212; are treated as hints about which links to consider or exclude within Search. We’ll use these hints &#8212; along with other signals &#8212; as a way to better understand how to appropriately analyze and use links within our systems.</p></blockquote>
<p>The announcement includes a few notable instructions regarding usage. Although all the new link attributes are working today as hints for ranking purposes, there is no need to change existing links. For sponsored links, Google recommends switching over to using rel=”sponsored” if or when it is convenient. Users can also specify multiple rel values (e.g. rel=&#8221;ugc sponsored&#8221;). Google plans to use the hints for crawling and indexing purposes beginning March 1, 2020.</p>
<p>The new ways to identify nofollow links impacts not only how users create links in their sites but also <a href=\"https://wordpress.org/plugins/search/nofollow/\" rel=\"noopener noreferrer\" target=\"_blank\">plugins that add the nofollow attribute</a> sitewide or other otherwise. Plugin authors will want to reevaluate the options provided in their products.</p>
<p>Progress on the relevant <a href=\"https://github.com/WordPress/gutenberg/pull/16609\" rel=\"noopener noreferrer\" target=\"_blank\">Gutenberg PR for adding a nofollow option</a> has stalled and is not currently listed for any upcoming milestones. Last week Gutenberg designer Mark Uraine expressed hesitation on adding this feature to the plugin.</p>
<p>&#8220;I’m hesitant on this one,&#8221; Uraine <a href=\"https://github.com/WordPress/gutenberg/pull/16609#issuecomment-527921959\" rel=\"noopener noreferrer\" target=\"_blank\">said</a>. &#8220;I think it’s been a long-standing discussion and there are reasons behind not including this option in the Classic Editor.</p>
<p>&#8220;How does it adhere to the WordPress 80/20 rule? We’re looking to implement this as an option (not a decision)… so will 80% of WP users benefit from it?&#8221;</p>
<p>Gutenberg users are continuing to advocate on the ticket for the necessity of nofollow link options.</p>
<p>&#8220;Now, with Gutenberg, you can only add a nofollow by switching to the HTML version and manually add the nofollow attribute,&#8221; Andreas de Rosi said. &#8220;It&#8217;s a big pain. I don&#8217;t know how to best implement it (I am not a programer), but this is an important feature the Gutenberg editor should have.&#8221;</p>
<p>Paal Joachim Romdahl <a href=\"https://github.com/WordPress/gutenberg/pull/16609#issuecomment-528838567\" rel=\"noopener noreferrer\" target=\"_blank\">commented</a> on the ticket, requesting a simple way for plugins to extend the link dialog box if the Gutenberg team decides to reject the PR for adding nofollow options.</p>
<p>More general <a href=\"https://github.com/WordPress/gutenberg/pull/13190\" rel=\"noopener noreferrer\" target=\"_blank\">discussion</a> regarding how to implement link settings extensibility is open in a separate ticket on the Gutenberg repository.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 11 Sep 2019 18:41:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"WPTavern: Kioken Blocks: The New Street Fighter-Inspired Block Collection that Is Taking Aim at Page Builders\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93524\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:119:\"https://wptavern.com/kioken-blocks-the-new-street-fighter-inspired-block-collection-that-is-taking-aim-at-page-builders\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7918:\"<p>With the proliferation of block collection plugins over the past year, <a href=\"https://wordpress.org/plugins/kioken-blocks/\" rel=\"noopener noreferrer\" target=\"_blank\">Kioken Blocks</a> is a relatively unknown newcomer that you may have missed. Compared to competitors with thousands of users like <a href=\"https://wordpress.org/plugins/coblocks/\" rel=\"noopener noreferrer\" target=\"_blank\">CoBlocks</a> (30K+), <a href=\"https://wordpress.org/plugins/atomic-blocks/\" rel=\"noopener noreferrer\" target=\"_blank\">Atomic Blocks</a> (20K+), <a href=\"https://wordpress.org/plugins/stackable-ultimate-gutenberg-blocks/\" rel=\"noopener noreferrer\" target=\"_blank\">Stackable</a> (10K+), and <a href=\"https://wordpress.org/plugins/ultimate-addons-for-gutenberg/\" rel=\"noopener noreferrer\" target=\"_blank\">Ultimate Addons for Gutenberg</a> (100K+), Kioken is a small fish in a big pond of page builder utilities.</p>
<p>You might have seen Kioken Blocks in action recently without knowing it, if you checked out Matias Ventura&#8217;s demo introducing the concept of “<a href=\"https://wptavern.com/gutenberg-team-explores-the-future-of-full-site-editing-with-new-prototype\" rel=\"noopener noreferrer\" target=\"_blank\">block areas</a>.&#8221; The plugin was first released two months ago but is already starting to differentiate itself with some innovative design features, block templates, and layouts. Its name was inspired by the <a href=\"https://streetfighter.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Street Fighter</a> arcade game and major releases are named for different character moves.</p>
<p>Kioken&#8217;s most recent release includes a new Vertical Text setting that allows users to rotate paragraphs and headings for a special effect in more complex layouts.</p>
<p></p>
<p>Inside the block editor, users can flip the vertical text rotation, adjust the alignment, add margins, dropcaps, and apply other standard text settings to the selection.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-10-at-1.49.07-PM.png?ssl=1\"><img /></a></p>
<p>Kioken currently includes 17 blocks, all created with an emphasis on providing an aesthetic base design that will seamlessly fit into a user&#8217;s theme, with further customization options for each block. The blocks are not cookie cutter repeats of other collections but rather offer their own distinct styles and features.</p>
<p>For example, the <a href=\"https://kiokengutenberg.com/blocks/kinetic-posts-block/\" rel=\"noopener noreferrer\" target=\"_blank\">Kinetic Posts</a> block allows users to list blog posts, including custom post types, inside a grid, columns/list, or slider with multiple different layout options. Users can run custom queries, such as ordering randomly, or by name, popularity, date, and by post type with custom taxonomy queries.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-10-at-2.06.08-PM.png?ssl=1\"><img /></a></p>
<p>Kioken Blocks creator Onur Oztaskiran said he focuses on adding features and blocks that are not commonly available already. This includes some under the hoods usability features, such as custom block appenders, lighter block highlighter on block selection on dark backgrounds, and block settings change indicators in the sidebar.</p>
<p>&#8220;I try to add blocks that people don’t have access to yet,&#8221; Oztaskiran said. &#8220;So I don’t spend my time on creating accordions or team blocks but rather add things that enrich your content building process in the same fashion premium page building tools do (Kinetic Wrapper block, Animator and Vertical Text extensions are some of these).&#8221;</p>
<h3>Kioken Blocks Aims to Provide a Faster, Simpler Alternative to Complex Page Builder Plugins</h3>
<p>Oztaskiran has a design background, having previously worked as the design lead at Udemy, Noon.com, and Qordoba, but he taught himself how to build blocks in order to push the limits of WordPress&#8217; page building capabilities.</p>
<p>&#8220;Kioken Blocks started out as a personal hobby to learn Gutenberg development and test out if I can do something with GB that would replace mine and everyone else’s page building workflow with WordPress, using only Gutenberg by extending it.</p>
<p>&#8220;I am a designer and not so great developer. I’ve mostly built Kioken Blocks following Gutenberg resources on the web and GitHub, most of the time by learning from the Gutenberg GitHub repo.&#8221;</p>
<p>Oztaskiran&#8217;s personal site, <a href=\"https://monofactor.com/\" rel=\"noopener noreferrer\" target=\"_blank\">monofactor.com</a>, was built with nothing but Gutenberg and Kioken Blocks, including the fancy animations reminiscent of Themeforest products, along with the layout. The site is a good example of how the block editor and a few custom blocks can enable users to create beautiful, complex layouts without having to use a heavy, over-engineered page builder plugin.</p>
<p>&#8220;I took a leap of faith in Gutenberg when it was first released and started developing for it since I&#8217;m also a user and hate many things about page builder plugins,&#8221; Oztaskiran said. &#8220;I love to hate Gutenberg as well, but right now I can&#8217;t stop using it.&#8221;</p>
<p>Oztaskiran used page builder plugins in the past and even created extensions for some of them, but ultimately his frustrations inspired him to go all in on Gutenberg block development.</p>
<p>&#8220;With page builders, what took me away from them most was the MBs of resources they add to my sites, and the complexity of content editing in the editor, the long learning curve for some of them, and most importantly you need to be a &#8216;pro&#8217; to create complex layouts and engaging, rich content,&#8221; Oztaskiran said.</p>
<p>As a result of these frustrations, he decided to focus on speed and usability in Kioken Blocks. Oztaskiran said he is satisfied to have developed a product that allows users to create animated, complex layouts in minutes, much faster than he was able to do in other platforms. Kioken&#8217;s predefined block presets allow users to insert elements like background hero sections, product intros, sliding testimonials, and other page elements, making it easy to quickly design a site. These types of elements further blur the line between predefined block templates and themes.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-10-at-4.57.56-PM.png?ssl=1\"><img /></a></p>
<p>&#8220;What amazes me with Gutenberg is you only need a lightweight unbloated GB compatible theme and nothing else,&#8221; Oztaskira said. &#8220;You can create amazing things.&#8221;</p>
<p>He is currently maintaining the plugin by himself without a team but the project is very time consuming. He sells commercial block templates through the plugin&#8217;s upgrade page and the user base is growing, so is considering making some partnerships in the future. Kioken Blocks only has approximately 100+ active installs at the moment, but Oztaskiran reports that his conversion rate is about 6-7% on selling Pro licenses, which include priority support and commercial block templates and layouts.</p>
<p>Despite identifying himself as just &#8220;a designer and a crappy developer,&#8221; Oztaskiran&#8217;s investment in learning Gutenberg block development is starting to pay off.</p>
<p>&#8220;You don’t need to be a pro dev to understand the logic, and with having an average JS knowledge you can get on board to GB development in a short time,&#8221; he said.&#8221;</p>
<p>&#8220;I indeed had ups and downs with Gutenberg, and Kioken Blocks aims to cover for those &#8216;downs.&#8217; I’ve been trying to build a tool for the editor so that some day you will only need Gutenberg and no other page building tools to create engaging and beautiful content.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Sep 2019 22:53:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"BuddyPress: BuddyPress 5.0.0-beta2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=307715\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://buddypress.org/2019/09/buddypress-5-0-0-beta2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2888:\"<p>Hello BuddyPress contributors!</p>



<p><strong>5.0.0-beta2</strong> is available for testing, you can&nbsp;<a href=\"https://downloads.wordpress.org/plugin/buddypress.5.0.0-beta2.zip\">download it here</a>&nbsp;or get a copy via our Subversion repository. This is really important for us to have your feedback and testing help.</p>



<p>Since <a href=\"https://buddypress.org/2019/08/buddypress-5-0-0-beta1/\">5.0.0-beta1</a>:</p>



<ul><li>We&#8217;ve brought some improvements to string i18n into the BP REST API code.</li><li>We&#8217;ve also improved the JavaScript function we are making available in this release to ease your clients BP REST API Requests.</li></ul>



<h2>5.0.0 final release is approaching!</h2>



<p>The <strong>Release Candidate (RC) is scheduled on September 16</strong>: at this time BuddyPress 5.0.0 will be in a string freeze. It means we won&#8217;t change i18n strings anymore for this release to leave enough time to our beloved polyglot contributors to <a href=\"https://translate.wordpress.org/projects/wp-plugins/buddypress/\">translate BuddyPress</a> into their native languages. If you&#8217;re a good english writer or copywriter you can still help us to <a href=\"https://buddypress.trac.wordpress.org/ticket/8132#comment:5\">polish the text</a> we plan to use to inform about the 5.0.0 new features.</p>



<p>If you are still using our Legacy Template Pack and think it&#8217;s important to include a Twenty Nineteen companion stylesheet into this release, <strong>September 16 is also the deadline to make it happen</strong>. Please test, contribute and improve the patch attached to this <a href=\"https://buddypress.trac.wordpress.org/ticket/8103\">ticket</a>.</p>



<div class=\"wp-block-image\"><img src=\"https://plugins.svn.wordpress.org/buddypress/assets/icon.svg\" alt=\"\" width=\"33\" height=\"33\" /></div>



<p>Let&#8217;s use the coming days to make sure your BuddyPress plugins or your theme or your specific WordPress configuration are ready for BuddyPress 5.0.0 : <strong>we need you to help us help you</strong>: please <a href=\"https://downloads.wordpress.org/plugin/buddypress.5.0.0-beta2.zip\">download and test 5.0.0-beta2</a>!</p>



<div class=\"wp-block-button aligncenter is-style-squared\"><a class=\"wp-block-button__link has-background\" href=\"https://downloads.wordpress.org/plugin/buddypress.5.0.0-beta2.zip\">Download and test 5.0.0-beta2</a></div>



<div class=\"wp-block-spacer\"></div>



<p>5.0.0 is almost ready (Targeted release date is <a href=\"https://bpdevel.wordpress.com/2019/09/06/bp-dev-chat-summary-september-4/\">September 30, 2019</a>), but please do not run this Beta 2 release in a production environment just yet. Let us know of any issues you find in <a href=\"https://buddypress.org/support\">the support forums</a> and/or on <a href=\"https://buddypress.trac.wordpress.org/\">our development tracker</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Sep 2019 17:45:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"imath\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Creative Commons Releases New WordPress Plugin for Attributing Content with Gutenberg Blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93506\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://wptavern.com/creative-commons-releases-new-wordpress-plugin-for-attributing-content-with-gutenberg-blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2484:\"<p><a href=\"https://creativecommons.org/\" rel=\"noopener noreferrer\" target=\"_blank\">Creative Commons</a> has released an <a href=\"https://wordpress.org/plugins/creative-commons/\" rel=\"noopener noreferrer\" target=\"_blank\">official WordPress plugin</a> for attributing and licensing content. It is an updated and revamped version of the organization&#8217;s <a href=\"https://github.com/tarmot/wp-cc-plugin\" rel=\"noopener noreferrer\" target=\"_blank\">WPLicense</a> plugin. It is also loosely based on an old plugin called <a href=\"https://wordpress.org/plugins/license/\" rel=\"noopener noreferrer\" target=\"_blank\">License</a>, which seems to have been abandoned after not receiving any updates for six years.</p>
<p>The new Creative Commons plugin is an attribution tool that is compatible with the block editor. It comes with eight different blocks for licensing any post, page, image, or other type of media.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/creative-commons-gutenberg-blocks.png?ssl=1\"><img /></a></p>
<p>The block settings allow the user to specify the Attribution text, add additional text after the license, and customize the block&#8217;s background and text colors.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/creative-commons-block-customization.png?ssl=1\"><img /></a></p>
<p>The plugin also retains several features from the older versions, including the ability to set a default license and display it as a widget or in the footer. Users can license their entire sites or license some posts, pages, or images differently on a per-content basis using the CC Gutenberg blocks. It is also multisite compatible, where network admins can license the entire network with a default license or allow site admins to choose their own. License information can be displayed with &#8220;One Click Attribution&#8221; for images.</p>
<p>Software developer <a href=\"https://ahmadbilal.dev/\" rel=\"noopener noreferrer\" target=\"_blank\">Ahmad Bilal</a> worked on the Creative Commons plugin with help from a mentor as part of his Google Summer of Code project. This update is long overdue, as the older version of the plugin was not compatible with newer versions of WordPress beyond 3.8.1. The new plugin is compatible with the latest version of WordPress (5.2.2) and is now <a href=\"https://wordpress.org/plugins/creative-commons/\" rel=\"noopener noreferrer\" target=\"_blank\">available in the official plugin directory</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Sep 2019 03:58:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: Gutenberg Team Explores the Future of Full-Site Editing with New Prototype\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93512\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://wptavern.com/gutenberg-team-explores-the-future-of-full-site-editing-with-new-prototype\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6839:\"<p>From its inception, the block editor was always intended to be more than just an editor for the main content area. Gutenberg phase 2 brings the block editor to other parts of the site, including widgets, menus, and other aspects of site customization. Matias Ventura, one of the lead engineers on the project, has offered a glimpse of the team&#8217;s vision for how the block editor will tackle full-site editing with an intriguing new <a href=\"https://make.wordpress.org/core/2019/09/05/defining-content-block-areas/\" rel=\"noopener noreferrer\" target=\"_blank\">prototype</a>.</p>
<p>Ventura shared a video demo, introducing the concept of &#8220;block areas,&#8221; which he said would include headers, footers, sidebars, and any other meaningful template part outside of the post content that contains blocks. In the example below, every element on the page is made of blocks and can be directly manipulated by the user.</p>
<p></p>
<p>The prototype wasn&#8217;t necessarily created to prescribe a specific implementation but rather shows some of the possibilities of how block areas could be organized within the page. Each block area is saved separately and any of the template parts can have a distinct name. Ventura suggested they might be saved as individual posts in an internal custom post type, which can be isolated and edited individually or within the scope of the whole page. This would allow for different view modes and possibly even a design mode with a grid overlay:</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-09-at-9.25.03-AM.png?ssl=1\"><img /></a></p>
<p>The prototype demonstrates the possibility of drilling down into the individual blocks nested within theme templates and post content. This offers users a better understanding of the page structure and allows them to easily navigate nested blocks.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-09-at-9.21.27-AM.png?ssl=1\"><img /></a></p>
<p>Ventura&#8217;s writeup is somewhat technical and implementation details are still being actively discussed across several tickets on GitHub, but initial community reactions to the prototype have been positive overall.</p>
<h3>A Closer Look at How Block Areas Could Replace the Customizer</h3>
<p>With WordPress closing in on the one year anniversary of having the block editor in core, the interface presented in the block areas prototype seems immediately more familiar than the Customizer. Full-site editing in the Gutenberg era will fundamentally change how users approach their site designs. The block editor stands to unify customization and content interfaces that were previously unable to make the jump into full-on frontend editing.</p>
<p>&#8220;It&#8217;s too early to say for sure, but in a world where everything is a block, there isn&#8217;t much need for the Customizer&#8217;s current interface where the preview is disconnected from the controls in a separate window,&#8221; Customizer component maintainer Weston Ruter said. &#8220;If theme templates are built entirely with blocks which support direct manipulation, then it&#8217;s essentially a frontend editing paradigm.&#8221;</p>
<p>Ruter, who was instrumental in architecting a great deal of the Customizer, said the current interface, which splits the design and controls into separate windows, was necessary because so many of the controls required full-page reloads. The split interface ensures that the controls don&#8217;t constantly disappear while the page reloads to display the changes.</p>
<p>&#8220;The better Customizer integrations are the live &#8216;postMessage&#8217; updating-controls which didn&#8217;t require reloads (e.g. color picker),&#8221; Ruter said. &#8220;More recently the &#8216;selective refresh&#8217; capability also facilitated themes and plugins to re-generate partial templates without having to reload the entire page. In theory, those capabilities did allow for <a href=\"https://github.com/xwp/wp-customize-inline-editing\" rel=\"noopener noreferrer\" target=\"_blank\">inline editing</a> without having to reload the page.&#8221;</p>
<p>While the Customizer gave users more control over their site designs, the component has always struggled to provide powerful controls and live refreshing in the same interface with a limited amount of page real estate. Ruter highlighted a few of the advantages of making the block editor the primary vehicle for customization in WordPress.</p>
<p>&#8220;Blocks bring a common interface to be able to do such inline editing for any part of the page, not just special areas in the Customizer preview that get the extra user interface goodies added,&#8221; he said. &#8220;And so with this common block interface with direct manipulation paradigm, there&#8217;s no need for a separate controls panel and there is no need to do full page reloads to do preview changes. So there would be no need for the current Customizer interface.&#8221;</p>
<p>Although much of the Customizer is likely to become obsolete in the new era of Gutenberg-powered full-site editing, the <a href=\"https://make.wordpress.org/core/2016/10/12/customize-changesets-technical-design-decisions/\" rel=\"noopener noreferrer\" target=\"_blank\">Customizer changeset</a> is one key concept that Ruter thinks could be preserved. This is the code that enables users to <a href=\"https://make.wordpress.org/core/2017/11/03/new-features-and-enhancements-with-customizer-changesets-in-4-9/\" rel=\"noopener noreferrer\" target=\"_blank\">stage and schedule sitewide design changes</a>.</p>
<p>&#8220;This is independent of the current Customizer interface and relates to the underlying data model of WordPress,&#8221; he said. &#8220;If changes made to Gutenberg blocks were put into such a changeset prior to being published, then the changes could be previewed across a site before going live. The need for this has not been so apparent until now because the changes have been scoped to post content. But once the block data being manipulated across various entities of a site, then it becomes important to have some place to stage those changes prior to going live.&#8221;</p>
<p>Plugin and theme developers will want to monitor the conversations surrounding the implementation of block areas for full site editing. When this prototype become a reality, it will have a significant impact on themes and plugins that are currently extending the Customizer. Many product developers will need to re-architect their solutions to be better suited to site customization that is powered by the block editor. Ventura lists all the relevant GitHub issues in his post <a href=\"https://make.wordpress.org/core/2019/09/05/defining-content-block-areas/\" rel=\"noopener noreferrer\" target=\"_blank\">introducing content-block areas</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Sep 2019 19:48:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: First Look at Twenty Twenty: New WordPress Default Theme based on Chaplin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93474\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"https://wptavern.com/first-look-at-twenty-twenty-new-wordpress-default-theme-based-on-chaplain\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3576:\"<p>Anders Norén unveiled the <a href=\"https://make.wordpress.org/core/2019/09/06/introducing-twenty-twenty/\" rel=\"noopener noreferrer\" target=\"_blank\">designs for the new Twenty Twenty theme</a> today. As speculated earlier this week, <a href=\"https://wptavern.com/anders-noren-to-design-twenty-twenty-default-theme-shipping-in-wordpress-5-3\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress will repurpose Noren&#8217;s Chaplin theme</a> in order to expedite shipping the new default theme on the constrained <a href=\"https://make.wordpress.org/core/5-3/\" rel=\"noopener noreferrer\" target=\"_blank\">5.3 release timeline</a>.</p>
<p>Although the new default theme will be based on Chaplin, it will not retain the same style.</p>
<p>&#8220;Using an existing theme as a base will help us get going on development faster,&#8221; Norén said. &#8220;Very little of the style of Chaplin will remain though, so it will still look and feel very much like its own thing.&#8221;</p>
<p>The screenshots he shared in the announcement look like a completely different theme. With just a few color and typography changes, along with a centered column for content, Twenty Twenty has its own distinct character.</p>
<p>
<a href=\"https://wptavern.com/first-look-at-twenty-twenty-new-wordpress-default-theme-based-on-chaplain/twenty-twenty-sub-page\"><img width=\"150\" height=\"150\" src=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2019/09/twenty-twenty-sub-page.jpg?resize=150%2C150&ssl=1\" class=\"attachment-thumbnail size-thumbnail\" alt=\"\" /></a>
<a href=\"https://wptavern.com/first-look-at-twenty-twenty-new-wordpress-default-theme-based-on-chaplain/twenty-twenty-single-post\"><img width=\"150\" height=\"150\" src=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/twenty-twenty-single-post.jpg?resize=150%2C150&ssl=1\" class=\"attachment-thumbnail size-thumbnail\" alt=\"\" /></a>
</p>
<p>Norén said he designed it to be a flexible, all-purpose theme suitable for businesses, organizations, and blogs, depending on the combination of blocks.</p>
<p>&#8220;The promise of the block editor is to give users the freedom to design and structure their sites as they see fit,&#8221; he said in the <a href=\"https://make.wordpress.org/core/2019/09/06/introducing-twenty-twenty/\" rel=\"noopener noreferrer\" target=\"_blank\">post</a> introducing Twenty Twenty. &#8220;The responsibility of a theme is to empower users to create their inspired vision by making the end result look as good, and work as well, as the user intended.&#8221;</p>
<p>The theme uses <a href=\"https://rsms.me/inter/\" rel=\"noopener noreferrer\" target=\"_blank\">Inter</a> for the typeface, selected for its legibility and bold personality when used in headings. It also comes in a Variable Font version, which Norén said will be a first for WordPress default themes. The benefits are that it reduces the number of requests and decreases the page size.</p>
<p>Those who are adventurous can <a href=\"https://github.com/WordPress/twentytwenty\" rel=\"noopener noreferrer\" target=\"_blank\">download Twenty Twenty right now from GitHub</a> and play around with the theme in its current state. Once it is stable, Norén and his team plan to merge it into core and continue development on Trac. There will be weekly meetings held in the #core-themes Slack channel for those who want to contribute to the design and development. The first one is scheduled for <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?iso=20190909T1900\" rel=\"noopener noreferrer\" target=\"_blank\">Monday, September 9, 2019, 02:00 PM CDT</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 07 Sep 2019 03:16:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: Google Releases Native Lazyload Plugin for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93443\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"https://wptavern.com/google-releases-native-lazyload-plugin-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5493:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/Screen-Shot-2019-09-06-at-10.26.38-AM.png?ssl=1\"><img /></a></p>
<p>The most recent release of Chrome (76) added a new “loading” attribute that supports <a href=\"https://wptavern.com/chrome-76-adds-native-lazy-loading-wordpress-contributors-continue-discussion-regarding-core-support\" rel=\"noopener noreferrer\" target=\"_blank\">native lazy loading in the browser</a>. An implementation for WordPress core is still under discussion. In the meantime, plugins that enable this for WordPress sites are starting to pop up, and Google has just released one of its own.</p>
<p><a href=\"https://wordpress.org/plugins/native-lazyload/\" rel=\"noopener noreferrer\" target=\"_blank\">Native Lazyload</a> was created by Google engineer Felix Arntz and the team behind the official AMP and PWA plugins for WordPress. It lazy loads images and iframes with the new loading attribute for browsers that support it. It also includes a fallback mechanism for browsers that do not yet support it, but this can be disabled with a filter. The plugin has no settings &#8211; users simply activate it and it works.</p>
<p>In a <a href=\"https://felix-arntz.me/blog/native-lazy-loading-wordpress/\" rel=\"noopener noreferrer\" target=\"_blank\">post</a> introducing the new plugin, Arntz explains why current lazy loading options, which require custom JavaScript, are not always good for performance:</p>
<blockquote><p>Lazy-loading has for a long time not been a switch you can just toggle to make it work. It was not a browser feature, so it typically required loading and running custom JavaScript logic to make it work. Unfortunately, JavaScript itself is an expensive resource, so lazy-loading as it’s been done so far might in certain cases actually have a negative impact on performance (e.g. if a page doesn’t contain any images or only contains a single image that’s immediately visible). Furthermore, if a user had disabled JavaScript in their browsers, lazy-loading wouldn’t work at all.</p></blockquote>
<p>The plugin uses a similar implementation that is being discussed in the core ticket. Arntz described it as a &#8220;progressive enhancement,&#8221; where a user&#8217;s website performance will &#8220;magically improve without intervention,&#8221; as more browsers add support for the loading attribute.</p>
<p>With the release of this plugin, and Google&#8217;s input on the related trac ticket, it&#8217;s clear that the company is interested in seeing WordPress core support the new loading attribute. Chrome Engineering Manager <a href=\"https://addyosmani.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Addy Osmani</a> <a href=\"https://core.trac.wordpress.org/ticket/44427#comment:38\" rel=\"noopener noreferrer\" target=\"_blank\">commented</a> on the ticket 10 days ago to lend his support for the effort and make a few recommendations.</p>
<p>&#8220;I&#8217;m very supportive of core getting support for native lazy-loading in a non-destructive manner,&#8221; Osmani said.</p>
<p>&#8220;The ideal change I would love to see in lazy-load plugins is deferring to native lazy-loading where supported and applying their fallback where it is not.&#8221; Osmani estimates that more than 17K origins are already using loading=lazy, according to Google&#8217;s telemetry.</p>
<p>Andy Potts, a software engineer at the BBC <a href=\"https://medium.com/bbc-design-engineering/native-lazy-loading-has-arrived-c37a165d70a5\" rel=\"noopener noreferrer\" target=\"_blank\">reported</a> seeing major performance improvements after adopting native lazy loading. He implemented it on one of the company&#8217;s internal products, a site with approximately 3,000 active users per day:</p>
<p>&#8220;One of the most common actions on the site involves running a query which renders a list of up to 100 images — which I thought seemed like the ideal place to experiment with native lazy loading,&#8221; Potts said.</p>
<p>&#8220;Adding the loading attribute to the images <strong>decreased the load time on a fast network connection by ~50% — it went from ~1 second to &lt; 0.5 seconds, as well as saving up to 40 requests to the server</strong>. All of those performance enhancements just from adding one attribute to a bunch of images!&#8221;</p>
<p>Kris Gunnars, who operates <a href=\"http://searchfacts.com\" rel=\"noopener noreferrer\" target=\"_blank\">searchfacts.com</a>, added Google&#8217;s new Native Lazyload plugin to his site and <a href=\"https://wordpress.org/support/topic/very-powerful-lazy-loading-plugin/\" rel=\"noopener noreferrer\" target=\"_blank\">reported</a> remarkable performance improvements, especially on mobile.</p>
<p>&#8220;After I installed this, my mobile PageSpeed score went from 92 to 96 and it also shaved a whopping 1.5 seconds off of my Time to Interactive score,&#8221; Gunnars said.</p>
<p>With WordPress powering <a href=\"https://w3techs.com/technologies/details/cm-wordpress/all/all\" rel=\"noopener noreferrer\" target=\"_blank\">34.5%</a> of the top 10 million websites, core support for native lazy loading stands to make a huge impact on the overall performance of the web. Progress on the <a href=\"https://core.trac.wordpress.org/ticket/44427\" rel=\"noopener noreferrer\" target=\"_blank\">ticket</a> has been slow, as contributors continue discussing the best approach. In the meantime, users who are anxious to implement it on their sites can install any one of a number of plugins that are already available.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Sep 2019 19:14:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"WordPress.org blog: People of WordPress: Abdullah Ramzan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7086\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/news/2019/09/people-of-wordpress-abdullah-ramzan/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5588:\"<p><em>You’ve probably heard that WordPress is open-source software, and may know that it’s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people’s lives for the better. This monthly series shares some of those lesser-known, amazing stories.</em></p>



<h2><strong>Meet Abdullah Ramzan, from Lahore, Punjab, Pakistan.</strong></h2>



<p>Abdullah Ramzan was born and brought up in the under-developed city of <a href=\"https://en.wikipedia.org/wiki/Layyah\"><strong>​Layyah​</strong></a>, which is situated in Southern Punjab, Pakistan and surrounded by desert and the river ​Sindh​.</p>



<p>He graduated from college in his home town and started using a computer in ​2010​ when he joined <a href=\"https://gcuf.edu.pk/\"><strong>​Government College University Faisalabad​</strong></a>. Abdullah’s introduction to WordPress happened while he was finishing the last semester of his degree. His final project was based in WordPress.</p>



<p>Ramzan’s late mother was the real hero in his life, helping him with his Kindergarten homework and seeing him off to school every day.&nbsp;</p>



<p>Before her heart surgery, Ramzan visited her in the hospital ICU, where she hugged him and said: ​“<strong>Don’t worry, everything will be good</strong>.” Sadly, his mother died during her surgery. However, her influence on Ramzan’s life continues.</p>



<h3><strong>Start of Ramzan’s Career:</strong></h3>



<p>After graduation, Ramzan struggled to get his first job. He first joined PressTigers<strong>​</strong> as a Software Engineer and met Khawaja Fahad Shakeel<a href=\"https://twitter.com/FahadShakeel\"><strong>​</strong></a>, his first mentor. Shakeel provided Ramzan with endless support. Something had always felt missing in his life, but he felt like he was on the right track for the first time in his life when he joined the WordPress community.&nbsp;</p>



<h3><strong>Community – WordCamps and Meetups:</strong></h3>



<p>Although Ramzan had used WordPress since ​2015​, attending WordPress meetups and open source contributions turned out to be a game-changer for him. He learned a lot from the WordPress community and platform, and developed strong relationships with several individuals. One of them is <a href=\"https://twitter.com/jainnidhi03\"><strong>​</strong></a>Nidhi Jain​ from Udaipur India who he works with on WordPress development. The second is <a href=\"https://twitter.com/desrosj\"><strong>​</strong></a>Jonathan Desrosiers​ who he continues to learn a lot from.</p>



<p>In addition, Usman Khalid<a href=\"https://twitter.com/Usman__Khalid\"><strong>​</strong></a>, the lead organizer of WC Karachi, mentored Ramzan, helping him to develop his community skills.&nbsp;</p>



<p>With the mentorship of these contributors, Ramzan is confident supporting local WordPress groups and helped to organize ​WordCamp Karachi​, where he spoke for the first time at an international level event. He believes that WordPress has contributed much to his personal identity.&nbsp;</p>



<img src=\"https://i0.wp.com/wordpress.org/news/files/2019/09/AbdullahRamzan.jpeg?resize=632%2C422&ssl=1\" alt=\"Abdullah Ramzan among a group of community members at WordCamp Karachi 2018\" class=\"wp-image-7088\" />Abdullah Ramzan at WordCamp Karachi 2018



<h3><strong>WordPress and the Future:</strong></h3>



<p>As a <a href=\"https://www.meetup.com/WordPress-Lahore/members/?op=leaders&sort=name\"><strong>​co-organizer of WordPress Meetup Lahore,​</strong></a> he would love to involve more people in the community leadership team, to provide a platform for people to gather under one roof, to learn and share something with each other. </p>



<p>But he has loftier ambitions. Impressed by <a href=\"https://walktowc.eu/\">Walk to WordCamp Europe</a>, Abdullah is seriously considering walking to WordCamp Asia. He also one day hopes for the opportunity to serve his country as a senator of Pakistan<a href=\"http://www.senate.gov.pk/\"><strong>​</strong></a> and intends to enter the next senate election.</p>



<h3><strong>Words of Encouragement</strong></h3>



<p>Abdullah Ramzan knows there is no shortcut to success. “You have to work hard to achieve your goals,” explained Ramzan. He still has much he wishes to accomplish and hopes to be remembered for his impact on the project.</p>



<p>Abdullah believes WordPress can never die as long as people don’t stop innovating to meet new demands. The beauty of WordPress is that it is made for everyone.</p>



<p>Ramzan encouraged, “If you seriously want to do something for yourself, do something for others first. Go for open source, you’ll surely learn how to code. You’ll learn how to work in a team. Join local meetups, meet with the folks: help them, learn from them, and share ideas.”</p>



<hr class=\"wp-block-separator\" />



<div class=\"wp-block-image\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo.jpg?resize=109%2C82&ssl=1\" alt=\"\" class=\"wp-image-7025\" width=\"109\" height=\"82\" /></div>



<p><em>This post is based on an article originally published on HeroPress.com, a community initiative created by <a href=\"https://profiles.wordpress.org/topher1kenobe/\">Topher DeRosia</a>. HeroPress highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p><em>Meet more WordPress community members over at </em><a href=\"https://heropress.com/\"><em>HeroPress.com</em></a><em>!</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Sep 2019 18:21:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Yvette Sonneveld\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: WordSesh EMEA Schedule Published, Registration Opens September 9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93428\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wptavern.com/wordsesh-emea-schedule-published-registration-opens-september-9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3153:\"<p><a href=\"https://wptavern.com/wordsesh-emea-coming-september-25-a-new-virtual-wordpress-event-for-europe-middle-east-and-africa\" rel=\"noopener noreferrer\" target=\"_blank\">WordSesh EMEA</a>, a 12-hour virtual conference designed for the WordPress community in the Middle East, Europe, and Africa, has <a href=\"https://wordsesh.com/\" rel=\"noopener noreferrer\" target=\"_blank\">published the full schedule</a> for the upcoming event. The lineup includes speakers from the UK to Cape Town to Sri Lanka, and other parts of the wider world of WordPress. Approximately 8 of the 11 speakers selected are from the targeted regions for this event. The remaining three are located in the U.S.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/09/wordsesh-emea-speakers.jpg?ssl=1\"><img /></a></p>
<p>WordSesh EMEA&#8217;s schedule features a healthy mix of topics, including multiple sessions on using Gatsby with WordPress, image optimization, webops, managing a business with mental illness, building SaaS apps with WordPress and Laravel, and Jetpack.</p>
<p><a href=\"https://muhammad.dev/\" rel=\"noopener noreferrer\" target=\"_blank\">Muhammad Muhsin</a>, a Sri Lanka-based React developer at <a href=\"https://rtcamp.com\" rel=\"noopener noreferrer\" target=\"_blank\">rtCamp</a>, will be presenting a session on using WordPress as a headless CMS with Gatsby. After Gatsby introduced themes, he started converting WordPress themes to Gatsby and experimenting with using WPGraphQL to get the content. He is also the lead developer for the <a href=\"http://GatsbyWPThemes.com\" rel=\"noopener noreferrer\" target=\"_blank\">GatsbyWPThemes.com</a> project.</p>
<p>If you have ever heard the marketing term &#8220;digital experience platform&#8221; (DXP) and wondered what all the buzz is about, Karim Marucchi, CEO of <a href=\"https://crowdfavorite.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Crowd Favorite</a>, has a session titled &#8220;What&#8217;s All The Fuss About DXPs, and Why Should I Care?&#8221; He will explore a recent trend where enterprise clients are moving away from content management towards DXP&#8217;s that integrate online marketing tools.</p>
<p><a href=\"https://ahmadbilal.dev\" rel=\"noopener noreferrer\" target=\"_blank\">Ahmad Bilal</a>, a developer based in Pakistan and 2019 Google Summer of Code student, will be presenting a session on GitHub Actions and how to automatically deploy a plugin to WordPress.org when tagging a new version on GitHub.</p>
<p>WordSesh EMEA provides an opportunity for viewers in the Middle East, Europe, and Africa to see virtual conference sessions during regular daytime hours, but it also gives viewers in the Western hemisphere a chance to hear speakers who they may never meet at a local WordCamp. It is scheduled for Wednesday, September 25, 2019, from 7:00-19:00 UTC. A handy dropdown on the schedule allows viewers to select their own timezone for the schedule display. Sessions will be conducted in English for this first EMEA event and will also be live captioned.</p>
<p>WordSesh EMEA is free for all to attend online and registration for tickets will be open Monday, September 9.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Sep 2019 20:30:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"WPTavern: Anders Norén to Design Twenty Twenty Default Theme, Shipping in WordPress 5.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93395\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"https://wptavern.com/anders-noren-to-design-twenty-twenty-default-theme-shipping-in-wordpress-5-3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4093:\"<p>WordPress 5.3&#8217;s release lead coordinators <a href=\"https://make.wordpress.org/core/2019/09/04/dev-chat-summary-september-4/\" rel=\"noopener noreferrer\" target=\"_blank\">announced a new batch of focus leads</a> during yesterday&#8217;s core dev chat.</p>
<p><a href=\"https://www.andersnoren.se/\" rel=\"noopener noreferrer\" target=\"_blank\">Anders Norén</a>, one of the most well-respected theme authors in the community and an early adopter of Gutenberg, will be leading the design of the upcoming Twenty Twenty default theme. He is working alongside team Theme Wrangler <a href=\"https://profiles.wordpress.org/ianbelanger/\" rel=\"noopener noreferrer\" target=\"_blank\">Ian Belanger</a>, a developer who is currently sponsored by Bluehost as a core contributor. <a href=\"https://profiles.wordpress.org/poena/\" rel=\"noopener noreferrer\" target=\"_blank\">Carolina Nymark</a> is also collaborating as a rep from the Theme Review team.</p>
<p><a href=\"https://twitter.com/andersnoren/status/1169368819095224320\" rel=\"noopener noreferrer\" target=\"_blank\">Reactions to the news</a> were overwhelmingly positive. I have never seen the WordPress community more excited about a  default theme. Those who have followed Norén&#8217;s work for a long time are hopeful that Twenty Twenty will be a theme they can actually use to build websites.</p>
<h3>Will WordPress Repurpose the Chaplin Theme for Twenty Twenty or Start from Scratch?</h3>
<p>Norén has released <a href=\"https://wordpress.org/themes/author/anlino/\" rel=\"noopener noreferrer\" target=\"_blank\">20 free themes on WordPress.org</a> with <a href=\"http://wptally.com/?wpusername=anlino\" rel=\"noopener noreferrer\" target=\"_blank\">2.85 million downloads</a> and a cumulative rating of 4.98 out of 5 stars. <a href=\"https://wptavern.com/anders-noren-release-free-chaplin-theme-designed-for-block-editor-theme-authors-discuss-better-ways-to-promote-truly-free-themes\" rel=\"noopener noreferrer\" target=\"_blank\">Chaplin</a>, his most recent release, is a beautiful example of the possibilities that the block editor opens up for users who want to design their own sites without having to search through dozens of panels of Customizer options. It provides the bones for an agency or business style theme but the block editor enables users to create advanced page layouts that would suit many different types of websites.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2019/07/chaplin.jpg?ssl=1\"><img /></a>Chaplin would make a good candidate for WordPress&#8217; next default theme, since it showcases the block editor as the main vehicle for editing the home page layout. Users can easily create unique customizations with different combinations of blocks that won&#8217;t look just like every other site using the same default theme.</p>
<p>Norén would not confirm whether WordPress will be re-purposing Chaplin for Twenty Twenty or if he will be starting from scratch, as the team is not ready to make the announcement yet. <a href=\"https://make.wordpress.org/core/5-3/\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress 5.3</a> is expected November 12, so the timeline may be somewhat constrained for creating an entirely new theme, but it&#8217;s not entirely outside the range of possibility.</p>
<p>&#8220;This is probably (yes, most definitely) the best thing that&#8217;s going to happen for WP + Gutenberg adoption since the 5.0 release,&#8221; Matt Medeiros <a href=\"https://twitter.com/mattmedeiros/status/1169367750424313856\" rel=\"noopener noreferrer\" target=\"_blank\">commented</a> on the news about Norén designing Twenty Twenty. &#8220;His Chaplin theme has been a joy to use and provoked me to embrace using Gutenberg with his theme.</p>
<p>&#8220;Right now, Gutenberg feels like an early version of iOS stuffed into a Blackberry Bold when you don&#8217;t get the right theme. I hope he can give us something as enjoyable as Chaplin.&#8221;</p>
<p>With WordPress 5.3 beta 1 expected September 23, an announcement with more details regarding Twenty Twenty&#8217;s design and scope should be available soon.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Sep 2019 19:24:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WordPress.org blog: WordPress 5.2.3 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7064\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2019/09/wordpress-5-2-3-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7631:\"<p>WordPress 5.2.3 is now available! </p>



<p>This security and maintenance release features 29 fixes and enhancements. Plus, it adds a number of security fixes—see the list below.</p>



<p>These bugs affect WordPress versions 5.2.2 and earlier; version 5.2.3 fixes them, so you&#8217;ll want to upgrade. </p>



<p>If you haven&#8217;t yet updated to 5.2, there are also updated versions of 5.0 and earlier that fix the bugs for you.</p>



<h3>Security Updates</h3>



<ul><li>Props to&nbsp;<a href=\"https://blog.ripstech.com/authors/simon-scannell/\">Simon Scannell of RIPS Technologies</a>&nbsp;for finding and disclosing two issues. The first, a cross-site scripting (XSS) vulnerability found in post previews by contributors. The second was a cross-site scripting vulnerability in stored comments.&nbsp;</li><li>Props to&nbsp;<a href=\"https://security-consulting.icu/blog/\">Tim Coen</a>&nbsp;for disclosing an issue where validation and sanitization of a URL could lead to an open redirect.&nbsp;</li><li>Props to Anshul Jain for disclosing reflected cross-site scripting during media uploads.</li><li>Props to&nbsp;<a href=\"https://fortiguard.com/\">Zhouyuan Yang of Fortinet’s FortiGuard Labs</a>&nbsp;who disclosed a vulnerability for cross-site scripting (XSS) in shortcode previews.</li><li>Props to Ian Dunn of the Core Security Team for finding and disclosing a case where reflected cross-site scripting could be found in the dashboard.</li><li>Props to Soroush Dalili (<a href=\"https://twitter.com/irsdl?lang=en\">@irsdl</a>) from NCC Group for disclosing an issue with URL sanitization that can lead to cross-site scripting (XSS) attacks.</li><li>In addition to the above changes, we are also updating jQuery on older versions of WordPress. This change was&nbsp;<a href=\"https://core.trac.wordpress.org/ticket/47020\">added in 5.2.1</a>&nbsp;and is now being brought to older versions.&nbsp;</li></ul>



<p>You can browse the&nbsp;<a href=\"https://core.trac.wordpress.org/query?status=closed&resolution=fixed&milestone=5.2.3&order=priority\">full list of changes on Trac</a>.</p>



<p>For more info, browse the full list of changes on Trac or check out the Version&nbsp;<a href=\"https://wordpress.org/support/wordpress-version/version-5-2-3/\">5.2.3 documentation page</a>.</p>



<p>WordPress 5.2.3 is a short-cycle maintenance release. The next major release will be&nbsp;<a href=\"https://make.wordpress.org/core/5-3/\">version 5.3.</a></p>



<p>You can download WordPress 5.2.3 from the button at the top of this page, or visit your<strong> Dashboard → Updates</strong> and click <strong>Update Now</strong>. </p>



<p>If you have sites that support automatic background updates, they&#8217;ve already started the update process.</p>



<h2>Thanks and props!</h2>



<p>This release brings together contributions from more than 62 other people. Thank you to everyone who made this release possible!</p>



<p><a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>,&nbsp;<a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>,&nbsp;<a href=\"https://profiles.wordpress.org/alpipego/\">Alex Goller</a>,&nbsp;<a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>,&nbsp;<a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>,&nbsp;<a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>,&nbsp;<a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/762e5e74/\">Ashish Shukla</a>,&nbsp;<a href=\"https://profiles.wordpress.org/wpboss/\">Aslam Shekh</a>,&nbsp;<a href=\"https://profiles.wordpress.org/backermann1978/\">backermann1978</a>,&nbsp;<a href=\"https://profiles.wordpress.org/cdog/\">Catalin Dogaru</a>,&nbsp;<a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>,&nbsp;<a href=\"https://profiles.wordpress.org/aprea/\">Chris Aprea</a>,&nbsp;<a href=\"https://profiles.wordpress.org/christophherr/\">Christoph Herr</a>,&nbsp;<a href=\"https://profiles.wordpress.org/danmicamediacom/\">dan@micamedia.com</a>,&nbsp;<a href=\"https://profiles.wordpress.org/diddledan/\">Daniel Llewellyn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/donmhico/\">donmhico</a>,&nbsp;<a href=\"https://profiles.wordpress.org/iseulde/\">Ella van Durpe</a>,&nbsp;<a href=\"https://profiles.wordpress.org/epiqueras/\">epiqueras</a>,&nbsp;<a href=\"https://profiles.wordpress.org/fencer04/\">Fencer04</a>,&nbsp;<a href=\"https://profiles.wordpress.org/flaviozavan/\">flaviozavan</a>,&nbsp;<a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>,&nbsp;<a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>,&nbsp;<a href=\"https://profiles.wordpress.org/gqevu6bsiz/\">gqevu6bsiz</a>,&nbsp;<a href=\"https://profiles.wordpress.org/thakkarhardik/\">Hardik Thakkar</a>,&nbsp;<a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>,&nbsp;<a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>,&nbsp;<a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>,&nbsp;<a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeffrey Paul</a>,&nbsp;<a href=\"https://profiles.wordpress.org/jikamens/\">jikamens</a>,&nbsp;<a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>,&nbsp;<a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa,</a> <a href=\"https://profiles.wordpress.org/karlgroves/\">karlgroves</a>,&nbsp;<a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a>,&nbsp;<a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>,&nbsp;<a href=\"https://profiles.wordpress.org/majemedia/\">Maje Media LLC</a>,&nbsp;<a href=\"https://profiles.wordpress.org/mspatovaliyski/\">Martin Spatovaliyski</a>,&nbsp;<a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>,&nbsp;<a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>,&nbsp;<a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nayana123/\">nayana123</a>,&nbsp;<a href=\"https://profiles.wordpress.org/greatislander/\">Ned Zimmerman</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nickdaugherty/\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/rabmalin/\">Nilambar Sharma</a>,&nbsp;<a href=\"https://profiles.wordpress.org/nmenescardi/\">nmenescardi</a>,&nbsp;<a href=\"https://profiles.wordpress.org/bassgang/\">Paul Vincent Beigang</a>,&nbsp;<a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendonça</a>,&nbsp;<a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vjik/\">Sergey Predvoditelev</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sharaz/\">Sharaz Shahid</a>,&nbsp;<a href=\"https://profiles.wordpress.org/sstoqnov/\">Stanimir Stoyanov</a>,&nbsp;<a href=\"https://profiles.wordpress.org/ryokuhi/\">Stefano Minoia</a>,&nbsp;<a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>,&nbsp;<a href=\"https://profiles.wordpress.org/isabel_brison/\">tellthemachines</a>,&nbsp;<a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vaishalipanchal/\">Vaishali Panchal</a>,&nbsp;<a href=\"https://profiles.wordpress.org/vortfu/\">vortfu</a>,&nbsp;<a href=\"https://profiles.wordpress.org/tsewlliw/\">Will West</a>, and&nbsp;<a href=\"https://profiles.wordpress.org/yarnboy/\">yarnboy</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Sep 2019 01:51:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: WordPress Governance Project Looks for New Leadership\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93009\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wptavern.com/wordpress-governance-project-looks-for-new-leadership\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11564:\"<p>The <a href=\"https://wpgovernance.com/\" rel=\"noopener noreferrer\" target=\"_blank\">WordPress Governance</a> project is looking for new leadership after its current leaders, <a href=\"https://bamadesigner.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Rachel Cherry</a> and <a href=\"https://mor10.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Morten Rand-Hendriksen</a>, announced that they will be stepping down. Weekly meetings have been canceled until the organization selects new leadership.</p>
<p>After its introduction at WordCamp Europe 2018, the project went through what its leadership believed were the appropriate channels for launching it through the Community group but it was <a href=\"https://wptavern.com/wordpress-governance-project-flagged-as-unsanctioned-first-meeting-set-for-january-15\" rel=\"noopener noreferrer\" target=\"_blank\">flagged as unsanctioned by WordPress leadership</a> shortly before the first meeting and denied access to the Make blog and Slack workspace. Despite initial setbacks, the group has been meeting regularly throughout 2019 on its own website and Slack instance.</p>
<p>&#8220;I need to step down from my leadership role in this project,&#8221; Cherry <a href=\"https://twgp.slack.com/archives/CF94YNHT8/p1566830315017300\" rel=\"noopener noreferrer\" target=\"_blank\">said</a> in a recent meeting. &#8220;I’m not stepping away for good, but this project is too important and I don’t have the bandwidth needed to keep it moving forward in the manner it deserves.&#8221;</p>
<p>She said the team is looking for two co-chairs who will help lead WordPress Governance going forward. Responsibilities include managing the overall vision and planning, as well as managing meetings and delegating assignments in support of the vision. Cherry said the duties list is intentionally &#8220;slim and vague,&#8221; as the leadership team doesn&#8217;t want the new leaders to feel they have to keep doing what has been done in the past.</p>
<p>&#8220;The Governance Project was always meant to be a community project meaning we want the community to take ownership of it,&#8221; Rand-Hendriksen said in his farewell <a href=\"https://twgp.slack.com/archives/CF94YNHT8/p1566574797490300\" rel=\"noopener noreferrer\" target=\"_blank\">announcement</a>. &#8220;This is the first step: We&#8217;ve established the project and set some parameters. Now it&#8217;s time for the community to move beyond our intentionally vague vision and make it into what the community wants and needs. New internal governance in the form of co-chairs from the actual community is a key step in this direction.&#8221;</p>
<h3>Governance Project Aims to Bring Clarity to WordPress&#8217; Organizational Structure and Decision Making Process</h3>
<p>In a recent post titled &#8220;<a href=\"https://wpgovernance.com/2019/09/03/what-is-governance-and-why-does-it-matter/\" rel=\"noopener noreferrer\" target=\"_blank\">What is governance and why does it matter</a>,&#8221; Cherry said that the project &#8220;made a crucial error&#8221; in not clearly setting clear expectations at the beginning:</p>
<blockquote><p>This lack of clarity, combined with a growing undercurrent of unrest in the WordPress community, led some to label the project a revolt, a revolution, even a coup.</p>
<p>That’s unfortunate and has done governance, and our project, a disservice. I feel it&#8217;s incumbent upon myself and Morten to set the record straight so we are able to move forward as a community.</p></blockquote>
<p>Cherry identified two recent controversial issues within the WordPress project with debates that highlight a lack of established policy, including <a href=\"https://make.wordpress.org/core/2019/08/07/proposal-auto-update-old-versions-to-4-7/\" rel=\"noopener noreferrer\" target=\"_blank\">auto-updating old versions of WordPress</a> and questions about <a href=\"https://make.wordpress.org/community/2019/08/15/discussion-how-to-handle-conflict-of-interest-situations/\" rel=\"noopener noreferrer\" target=\"_blank\">conflicts of interest</a>.</p>
<p>On both of these matters members of the governance project have chimed in on the Make/WordPress posts to urge decision makers to establish policies that will guide future decisions and to be more transparent about who is making the decisions.</p>
<p>Rand-Hendriksen <a href=\"https://make.wordpress.org/core/2019/08/07/proposal-auto-update-old-versions-to-4-7/#comment-36698\" rel=\"noopener noreferrer\" target=\"_blank\">asked</a> questions about how and where the decision will be made regarding auto-updating old versions of WordPress, who holds responsibility for the final decision, and how people without decision-making power will be represented. His questions went unanswered.</p>
<p>&#8220;The WordPress project already has some governance, but much of it remains ad-hoc, opaque, and often inscrutable,&#8221; Cherry said. She identified three key areas where the WordPress Governance project seeks to introduce clarity and transparency: organizational structure, day-to-day processes, and how decisions are made.</p>
<p>The group is also actively working on researching and drafting policies around a variety of topics, including the following:</p>
<ul>
<li>Community Code of Conduct</li>
<li>Diversity and Inclusion Policy</li>
<li>Code of Ethics</li>
<li>Privacy Policy</li>
<li>Conflict of Interest Policy</li>
<li>Accessibility Policy</li>
</ul>
<p>It is not clear whether these policies would then be submitted to WordPress&#8217; community team for consideration, as the group has not yet attempted to propose a finished document.</p>
<p>&#8220;Considering there’s no clear process for proposing and ratifying these types of policies, the goal of these efforts are to create a starting point for future official discussions within the WordPress project,&#8221; Cherry said.</p>
<h3>The Challenge of Defining Governance in a BDFL-led Open Source Project</h3>
<p>In the past, WordPress has navigated controversial issues in its own way. While the project has handbooks that offer guidelines, its leadership has never really been in the business of piling up policies to act on in anticipation of of future conflicts. The Governance project seems to have a good deal of both active and passive supporters. Regardless, when it was officially branded as unsanctioned, it was clear that WordPress&#8217; leadership was not actively looking to amend its organizational structure or decision-making process through the Governance project&#8217;s particular approach.</p>
<p>Cherry&#8217;s post clearly states that the project is not aiming to overthrow Matt Mullenweg as WordPress&#8217; <a href=\"https://en.wikipedia.org/wiki/Benevolent_dictator_for_life\" rel=\"noopener noreferrer\" target=\"_blank\">Benevolent Dictator for Life</a> (BDFL).</p>
<p>&#8220;Governance and Matt Mullenweg leading the WordPress project are not mutually exclusive,&#8221; Cherry said.</p>
<p>&#8220;The goal of the WordPress Governance Project isn’t to change how Matt is involved, but to more clearly define how the project is managed, and how he and others fit into the process.&#8221;</p>
<p>The BDFL governance model has traditionally operated with leaders acting more as a &#8220;community-approved arbitrator,&#8221; who often &#8220;let things work themselves out through discussion and experimentation whenever possible,&#8221; as Karl Fogel describes in <a href=\"https://producingoss.com/html-chunk/benevolent-dictator.html#benevolent-dictator-qualifications\" rel=\"noopener noreferrer\" target=\"_blank\">Producing Open Source Software</a>. Historically, WordPress&#8217; particular expression of BDFL leadership has loosely followed this design.</p>
<p>In her February 2019 newsletter, <a href=\"https://nadiaeghbal.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Nadia Eghbal</a>, a researcher who specializes in open source infrastructure, shared some informal thoughts about governance, particularly in relationship to BDFL-led projects:</p>
<blockquote><p>A friend of mine has very good taste in music, but I couldn’t tell you what he listens to. I couldn’t name a single artist he plays, or where one song begins or ends. His view is that “the best kind of music is where nobody notices it’s playing”. In his ideal world, music shapes ambiance as a background process. </p>
<p>Similarly, despite all our talk about governance design, I keep coming back to the idea that the best kind of governance is where nobody can tell it’s there.</p></blockquote>
<p>Eghbal describes the relationship between the “government&#8221; and “the governed” as fragile and symbiotic and that &#8220;having power can be just as vulnerable [as disenfranchisement], an act of cupping water in your hands, rather than closing your fist over it.&#8221; Maintaining a BDFL leadership role requires diplomacy and a broad awareness of the project&#8217;s needs. Eghbal surmises that contributors support a leader in this position because of the character the leader has demonstrated:</p>
<blockquote><p>In open source, there’s this concept of a “benevolent dictator for life”: a developer, usually the author, who runs the project and whose authority is not challenged. This phrase is often interpreted as “You’re the dictator, but at least you’re nice about it”. But I think there’s a hidden causal relationship that gets missed. It’s not that you’re a dictator who’s decided to be benevolent. Rather: because you are benevolent, you get to be dictator for life.</p></blockquote>
<p>This idea echoes Fogel&#8217;s summary of the <a href=\"https://producingoss.com/html-chunk/benevolent-dictator.html#benevolent-dictator-qualifications\" rel=\"noopener noreferrer\" target=\"_blank\">qualities of a good BDF</a>. The forkability of any open source project serves to keep BDFL powers in check:</p>
<blockquote><p>It is common for the benevolent dictator to be a founder of the project, but this is more a correlation than a cause. The sorts of qualities that make one able to successfully start a project — technical competence, ability to persuade other people to join, and so on — are exactly the qualities any BD would need.</p></blockquote>
<p>In reviewing the 16-year history of WordPress&#8217; leadership structure on a <a href=\"https://poststatus.com/matt-mullenweg-on-gutenberg/\" rel=\"noopener noreferrer\" target=\"_blank\">Post Status podcast episode</a> earlier this year, Matt Mullenweg described different experiments the project has explored, including a &#8220;lead developers consensus&#8221; approach and having the release lead as the final decision maker for the software. In recent years he has returned to a more overt BDFL model but said, &#8220;I don&#8217;t see that as the forever structure.&#8221;</p>
<p>In attempting to clarify WordPress&#8217; organizational structure and decision making model, the independent Governance project will need to be sensitive to the possibility that this ability to improvise and evolve the project&#8217;s leadership structures may have been one of the key factors in its continued growth and long-term ability to thrive.</p>
<p>The new leaders who replace Cherry and Rand-Hendriksen will have a formidable challenge ahead of them in carving out a path for the organization to have a meaningful impact on WordPress, despite not being designated as an official project. As it stands, the leaders face an uphill climb in moving the project from an unofficial working group to one that can effectively draft policies that WordPress will readily adopt.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Sep 2019 22:28:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WPTavern: WordPress 5.3 to Use Robots Meta Tag to Better Discourage Search Engines from Listing Sites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93331\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"https://wptavern.com/wordpress-5-3-to-use-robots-meta-tag-to-better-discourage-search-engines-from-listing-sites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2491:\"<p>WordPress is changing the method it uses to prevent search engines from indexing sites. Previously, if a user checked the &#8220;Discourage search engines from indexing this site&#8221; option in a site&#8217;s Settings > Reading screen, WordPress would add <code>Disallow: /</code> to the robots.txt file. This would prevent crawling but did not always prevent sites from showing up in search results. </p>



<img />



<p>As of 5.3, WordPress will drop the robots.txt method in favor of adding an updated robots meta tag to prevent the site from being listed in search engines: <code>&lt;meta name=\'robots\' content=\'noindex,nofollow\' /></code>. The meta tag offers a more reliable way of preventing indexing and subsequent crawling.</p>



<p>When checking the setting to discourage search engines from indexing a site, users are often looking for a way to hide their sites, but the setting does not always work as they expected. Jono Alderson summarized the problem and the proposed solution in a <a href=\"https://core.trac.wordpress.org/ticket/43590#comment:9\">comment</a> on the trac <a href=\"https://core.trac.wordpress.org/ticket/43590\">ticket</a> that brought about the changes:</p>



<blockquote class=\"wp-block-quote\"><p>The Reading setting infers that it&#8217;s intended to prevent search engines from <em>indexing</em> the content, rather than from <em>crawling</em> it. However, <strong>the presence of the robots disallow rule prevents search engines from ever discovering the <code>noindex</code> directive</strong>, and thus they may index &#8216;fragments&#8217; (where the page is indexed without content).<br /><br />2) Google recently announced that they&#8217;re making efforts to prevent fragment indexing. However, until this exists (and I&#8217;m not sure it will; it&#8217;s still a necessary/correct solution sometimes), we should solve for current behaviors. <strong>Let&#8217;s remove the <code>robots.txt</code> disallow rule</strong>, and allow Google (and others) to <em>crawl</em> the site.</p></blockquote>



<p>In the <a href=\"https://make.wordpress.org/core/2019/09/02/changes-to-prevent-search-engines-indexing-sites/\">dev note</a> announcing the change, Peter Wilson recommends that developers wanting to exclude development sites from being indexed by search engines should include the HTTP Header <code>X-Robots-Tag: noindex, nofollow</code> when serving all assets for the site, including images, PDFs, video, and other assets.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Sep 2019 03:19:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Toolbelt: A New Jetpack-Inspired Plugin with a Focus on Speed and Privacy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=92814\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wptavern.com/toolbelt-a-new-jetpack-inspired-plugin-with-a-focus-on-speed-and-privacy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6830:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/08/Screen-Shot-2019-09-02-at-11.16.22-PM.png?ssl=1\"><img /></a></p>
<p>WordPress theme and plugin developer <a href=\"https://www.binarymoon.co.uk/\" rel=\"noopener noreferrer\" target=\"_blank\">Ben Gillbanks</a> is building a <a href=\"https://wordpress.org/plugins/jetpack/\" rel=\"noopener noreferrer\" target=\"_blank\">Jetpack</a> alternative with an emphasis on speed, simplicity, and privacy. <a href=\"https://wordpress.org/plugins/wp-toolbelt/\" rel=\"noopener noreferrer\" target=\"_blank\">Toolbelt</a> is a new, lightweight plugin that offers a collection of functionality that is commonly-used on WordPress sites. Currently available modules include features like breadcrumbs, browser native lazy loading, a Portfolio custom post type, related posts with images, responsive video, static social sharing, and more.</p>
<p>Gillbanks runs <a href=\"https://prothemedesign.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Pro Theme Design</a>, a commercial WordPress theme shop, and has sold themes on WordPress.com for the past seven years. He likes the idea of Jetpack and all of his commercial themes support it, but a desire to deliver more performant and sustainable sites drove him to create Toolbelt. He&#8217;s working on a new free theme called <a href=\"https://github.com/BinaryMoon/jarvis\" rel=\"noopener noreferrer\" target=\"_blank\">Jarvis</a> that will be released on WordPress.org with full Toolbelt compatibility.</p>
<p>&#8220;With my new theme I wanted to make something that was fast, private, and accessible. Inspired by people like Jack Lenox with <a href=\"https://sustywp.com/\" rel=\"noopener noreferrer\" target=\"_blank\">Susty</a> (and <a href=\"https://wordpress.tv/2019/08/27/jack-lenox-how-better-performing-websites-can-help-save-the-planet-2/\" rel=\"noopener noreferrer\" target=\"_blank\">his talk at WordCamp Europe</a>), I wanted to make something more sustainable. In testing my theme on my personal site I found that Jetpack was slowing it down. So I started rebuilding the features I wanted to use as an optimized plugin.&#8221;</p>
<p>Toolbelt currently includes more than a dozen modules, offered in a format similar to Jetpack but with a dramatically stripped down management interface in the admin. All modules are disabled by default so users can turn on only the ones they need.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/08/Screen-Shot-2019-09-02-at-11.01.15-PM.png?ssl=1\"><img /></a></p>
<p>The settings page includes a column that transparently displays the page impact for several of the modules, as high performance is one of Gillbanks&#8217; chief goals for the plugin.</p>
<p>&#8220;I had been testing my theme on a dev server and it was getting a score of 99 or 100 &#8211; but when I added it to my personal site the score dropped,&#8221; he said. &#8220;It took me a while to realize the problem was Jetpack, and once I had disabled Jetpack my score went up to 99 or 100 again. So now, each time I add a feature, I test the site to make sure I am maintaining the performance I am testing my site, with each feature and &#8211; hopefully &#8211; keeping the score nice and high.&#8221;</p>
<p>Although Toolbelt borrows a lot of code from both <a href=\"https://wordpress.org/plugins/jetpack/\" rel=\"noopener noreferrer\" target=\"_blank\">Jetpack</a> and the <a href=\"https://github.com/nilovelez/machete/\" rel=\"noopener noreferrer\" target=\"_blank\">Machete</a> plugin, Gillbanks made some deliberate choices in favor of performance when loading the code for the modules:</p>
<ul>
<li>Doesn’t use jQuery or any other javascript framework. All javascript is vanilla js, and minified.</li>
<li>Minifies all assets (JS and CSS)</li>
<li>Loads all assets inline. They are already small, and loading them directly on the page means there are no server requests.</li>
<li>Only loads things when they are needed. JS and CSS are only loaded for activated modules.</li>
<li>No options. There’s only one database option, and that’s an array that stores what modules are active.</li>
<li>Uses the minimum code possible. Minimum Javascript and PHP. Less code means more speed, and fewer bugs.</li>
</ul>
<h3>Toolbelt&#8217;s Approach to Privacy: No Phoning Out, No User Tracking</h3>
<p>Privacy is one of the most important aspects of the plugin for Gillbanks, who is English and has to deal with GDPR and EU cookie laws. Toolbelt does not phone out for any of its features, nor does the plugin share data with third parties or use standard social sharing JavaScripts. It also does not track usage or add any comments to the site&#8217;s HTML.</p>
<p>&#8220;One of the downsides of Jetpack is that it relies on the wordpress.com servers, including hosting images and content on their site,&#8221; Gillbanks said. &#8220;Things like Related Posts sync the blog post data to their servers so it can be searched and filtered.&#8221;</p>
<p>The privacy choices built into Toolbelt may limit Gillbanks&#8217; ability to reproduce certain features that rely on third-party servers, such as visitor stats, downtime monitoring, and image CDN.</p>
<p>&#8220;I&#8217;m not sure if I&#8217;ll add these features, or partner with privacy focused third party services,&#8221; Gillbanks said. &#8220;I must admit I&#8217;d really like to add the stats so I&#8217;m hoping I can find someone to work with.&#8221;</p>
<p>Toolbelt is heavily inspired by Jetpack but Gillbanks said he doesn&#8217;t plan to rebuild all of its features. He is starting with the easier ones and focusing on the ones he wants to use. He also doesn&#8217;t have plans to monetize it anytime soon.</p>
<p>&#8220;I&#8217;m open to adding premium features in the future, but if I do I won&#8217;t start charging for anything that is currently free,&#8221; he said. &#8220;For the time being I just want to keep adding more modules and making something that I find useful.&#8221;</p>
<p>Gillbanks is currently working on improving Toolbelt&#8217;s cookie consent bar to build a method for having it allow an &#8216;accept&#8217; and &#8216;decline&#8217; option, so that tracking is only enabled when users press the accept button. This assists those who want to follow GDPR guidelines more strictly. The current implementation automatically links to the site&#8217;s privacy policy page if the user has it setup in their site settings.</p>
<p>Toolbelt doesn&#8217;t have any settings, besides what modules are active on the site, but Gillbanks has created a collection of actions and filters that allow developers to customize things for clients/ themes. The <a href=\"https://github.com/BinaryMoon/wp-toolbelt/wiki\" rel=\"noopener noreferrer\" target=\"_blank\">documentation</a> is available on GitHub, where users can also submit issues and feature requests.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Sep 2019 20:13:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"WordPress.org blog: The Month in WordPress: August 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7059\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2019/09/the-month-in-wordpress-august-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9644:\"<p>This has been a particularly busy month, with a number of interesting and ambitious proposals for the WordPress project along with active progress across the entire community. </p>



<hr class=\"wp-block-separator\" />



<h2>Core Development and Schedule</h2>



<p>The upcoming minor release of WordPress, v5.2.3, is currently <a href=\"https://make.wordpress.org/core/2019/08/22/wordpress-5-2-3-rc-1/\">in the release candidate phase</a> and available for testing.</p>



<p>Following that, the next major release is v5.3 and the Core team has laid out <a href=\"https://make.wordpress.org/core/2019/08/21/wordpress-5-3-schedule-and-scope/\">a schedule and scope</a> for development. In addition, <a href=\"https://make.wordpress.org/core/2019/08/27/bug-scrub-schedule-for-5-3/\">a bug scrub schedule</a> and <a href=\"https://make.wordpress.org/accessibility/2019/08/28/wordpress-5-3-accessibility-focused-bug-scrub-schedule/\">an accessibility-focused schedule</a> have been set out to provide dedicated times for contributors to work on ironing out the bugs in the release.</p>



<p>Want to get involved in building WordPress Core? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>Proposal for User Privacy Improvements</h2>



<p>The Core Privacy Team <a href=\"https://make.wordpress.org/core/2019/08/07/feature-plugin-discussion-a-consent-and-logging-mechanism-for-user-privacy/\">has proposed a feature plugin</a> to build a consent and logging mechanism for user privacy. This project will focus on improving the user privacy controls in WordPress Core in order to protect site owners and users alike.</p>



<p>The proposal includes some useful information about building effective controls for users, how other projects have worked on similar efforts, and what kind of time and resources the project will need in order to be developed.</p>



<p>Want to get involved in this feature project? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core-privacy channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a> where there are open office hours every Wednesday at 19:00 UTC.</p>



<h2>Core Notification System Proposal</h2>



<p><a href=\"https://make.wordpress.org/core/2019/08/05/feature-project-proposal-wp-notify/\">A proposal has been made</a> for a new feature project to build a robust notification system for WordPress Core. The aim of the project is to build a system to handle notifications for site owners that can be extended by plugin and theme developers.</p>



<p>This proposal comes on the back of <a href=\"https://core.trac.wordpress.org/ticket/43484\">a Trac ticket</a> opened 18 months ago. With weekly meetings to discuss the project, the team behind WP Notify are <a href=\"https://make.wordpress.org/core/2019/08/28/wp-notify-meeting-recap-august-26-2019/\">in the planning phase</a> while they establish exactly how to develop the feature.<br /></p>



<p>Want to get involved in this feature project? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a>, and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a> &#8211; meetings for this project happen every Monday at 14:00 and 22:00 UTC.</p>



<h2>Local WordPress Development Environment</h2>



<p>Members of the Core Team <a href=\"https://make.wordpress.org/core/2019/08/05/wordpress-local-environment/\">have put together a local development environment for WordPress</a> that runs on Docker. This environment provides an easy way for developers to get involved with WordPress core development. </p>



<p>The work on this was inspired by the environment used for local Gutenberg development, <a href=\"https://make.wordpress.org/core/2019/08/30/gutenberg-local-environment-rewrite/\">which has since been improved</a> based on the new work that has been done here.</p>



<p><a href=\"https://make.wordpress.org/core/2019/08/05/wordpress-local-environment/\">The announcement post</a> explains how to use the Docker environment. If you have any feedback or bug reports, please comment on the post directly.</p>



<h2>Updates for Older Versions of WordPress</h2>



<p>On July 30, the Security Team shared that security updates need to undergo the same testing and release process for every major version of WordPress. This means they have to provide long-term support for over fifteen major versions of WordPress. This requires a lot of time and effort, and <a href=\"https://make.wordpress.org/core/2019/07/29/should-security-fixes-continue-to-be-backported-to-very-old-versions-of-wordpress/\">the team has sought feedback on potential solutions for this challenge</a>. </p>



<p>Following this discussion, <a href=\"https://make.wordpress.org/core/2019/08/07/proposal-auto-update-old-versions-to-4-7/\">a proposal was made to auto-update old versions of WordPress to v4.7</a>. This proposal garnered many responses and has since been updated to incorporate feedback from comments. The current recommendation is to secure the six latest versions and to eventually auto-update all older versions of WordPress to 4.7. Since this proposal was made, it has been discussed at <a href=\"https://make.wordpress.org/hosting/2019/08/26/hosting-meeting-notes-august-19-2019/\">Hosting Team meetings</a> and <a href=\"https://make.wordpress.org/core/2019/08/16/follow-up-discussion-on-major-auto-updates/\">Dev Chat meetings</a>, and the conversation is still ongoing.</p>



<p>Want to provide feedback on this proposal? Comment on <a href=\"https://make.wordpress.org/core/2019/08/07/proposal-auto-update-old-versions-to-4-7/\">the original post</a> with your thoughts.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>The recommended minimum PHP version for WordPress Core <a href=\"https://make.wordpress.org/core/2019/08/13/increasing-the-recommended-php-version-in-core/\">has been increased to 7.0</a>.</li><li>Gutenberg development continues at a rapid pace with <a href=\"https://make.wordpress.org/core/2019/08/28/whats-new-in-gutenberg-28-august/\">new updates</a> coming out every month.</li><li>The Core Team is kicking off bug scrub and triage sessions <a href=\"https://make.wordpress.org/core/2019/08/26/apac-triage-and-bug-scrub-sessions/\">at APAC-friendly times</a>.</li><li>WordCamp US announced <a href=\"https://2019.us.wordcamp.org/schedule/\">the event schedule</a> to take place on November 1-3.</li><li>The Plugin Team reminded developers that <a href=\"https://make.wordpress.org/plugins/2019/08/23/reminder-developers-must-comply-with-the-forum-guidelines/\">they need to stick to the Plugin Directory forum guidelines</a> if they choose to use them for support.</li><li>WordPress project leadership is looking at <a href=\"https://make.wordpress.org/updates/2019/07/30/update-sanctions-and-open-source/\">how to respond to political sanctions</a> in light of the open-source nature of the project.&nbsp;</li><li>The Community Team has proposed <a href=\"https://make.wordpress.org/community/2019/08/19/proposal-speaker-feedback-tool/\">a WordCamp speaker feedback tool</a> that will allow more reliable and consistent feedback for WordCamps speakers all over the world.</li><li>The Five for the Future project now has <a href=\"https://make.wordpress.org/updates/2019/08/29/five-for-the-future-proposed-scope-and-mockups/\">more complete mockups</a> and a plan to move forward.</li><li>The Theme Review Team decided to terminate the Trusted Authors program for a number of reasons <a href=\"https://make.wordpress.org/themes/2019/08/14/trusted-author-program-a-year-of-its-journey/\">outlined in the announcement post</a>.</li><li>The Design Team is taking a look at <a href=\"https://make.wordpress.org/design/2019/08/28/discussion-about-the-about-page/\">how they can improve the About page</a> in future WordPress releases.</li><li>This month saw <a href=\"https://make.wordpress.org/cli/2019/08/14/wp-cli-release-v2-3-0/\">the release of v2.3 of WP-CLI</a>, including a number of new commands and improvements.</li><li>WordCamp websites can now make use of <a href=\"https://make.wordpress.org/community/2019/08/19/wordcamp-blocks-are-live/\">custom blocks in the block editor</a> for crafting their content.</li><li>The Mobile Team are looking for testers for the v13.2 release of the <a href=\"https://make.wordpress.org/mobile/2019/08/27/call-for-testing-wordpress-for-android-13-2/\">Android</a> and <a href=\"https://make.wordpress.org/mobile/2019/08/29/call-for-testing-wordpress-for-ios-13-2/\">iOS</a> apps.</li><li>The WordCamp Asia team <a href=\"https://2020.asia.wordcamp.org/2019/08/20/wordcamp-asia-logo-a-design-journey\">published an interesting look</a> at the journey they took to design the event logo.</li><li><a href=\"https://make.wordpress.org/community/2019/08/26/call-for-volunteers-2020-global-sponsorship-working-group/\">A working group of volunteers is being formed</a> to work out the details for the Global Sponsorship Program in 2020.</li><li>In an effort to increase the accessibility of available WordPress themes, the Theme Review Team now requires that <a href=\"https://make.wordpress.org/themes/2019/08/03/planning-for-keyboard-navigation/\">all themes include keyboard navigation</a>.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Sep 2019 10:00:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: NetNewsWire 5.0 RSS Reader Rebuilt from Scratch, Now Free and Open Source\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=93240\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wptavern.com/netnewswire-5-0-rss-reader-rebuilt-from-scratch-now-free-and-open-source\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4964:\"<p><a href=\"https://inessential.com/2019/08/26/netnewswire_5_0_now_available\" rel=\"noopener noreferrer\" target=\"_blank\">NetNewsWire 5.0</a> was released this week as a completely rebuilt, free and open source Mac app. Back in its earlier days, the 17-year old RSS reader was widely regarded as the best available. Since its creation, the app has changed hands multiple times through two acquisitions, finally <a href=\"https://inessential.com/2018/08/31/netnewswire_comes_home\" rel=\"noopener noreferrer\" target=\"_blank\">landing back home with its creator, Brent Simmons</a>, in August 2018.</p>
<p>NetNewsWire 5.0 retains much of its original character while incorporating modern features like JSON Feed support, Dark Mode, a “Today” smart feed, syncing via Feedbin, starred articles, and more. It is a brand new app that doesn&#8217;t use any code from previous versions. Users who are updating from older commercial versions can export OPML from the old app and import it into the NetNewsWire 5.0 app.</p>
<p>Notably lacking from the app is the ability to sync data across devices. Right now this is only possible if users hook up Feedbin. Simmons said he is working with contributors on an iOS version of the app.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2019/08/NNW5Light.png?ssl=1\"><img /></a></p>
<p>Although it may not yet have as many features as some of its contemporaries, NetNewsWire&#8217;s return was celebrated by those who are hopeful that RSS can be one of the key technologies for unshackling web users from social media silos. NetNewsWire is back in support of this mission, which is highlighted on the app&#8217;s homepage:</p>
<blockquote><p>We support the open web. The big social networking sites are damaging society and eroding democracy — and we believe one of the ways out of this is to get our news via the open web rather than from Twitter and Facebook.</p>
<p>NetNewsWire is part of repairing the web we lost, and it’s part of building the web we want. That future web should not include viral hate speech, abuse, massive corporate surveillance, or successful influence operations by hostile governments and entities opposed to democracy.</p></blockquote>
<p>NetNewsWire is no longer owned or sponsored by any corporation. In fact, the app&#8217;s GitHub repo has a <a href=\"https://github.com/brentsimmons/NetNewsWire/blob/master/Technotes/HowToSupportNetNewsWire.markdown\" rel=\"noopener noreferrer\" target=\"_blank\">support document</a> that says: &#8220;First thing: don’t send money. This app is written for love, not money.&#8221; It outlines the project&#8217;s values:</p>
<blockquote><p>NetNewsWire is all about three things:</p>
<p>The open web<br />
High-quality open source Mac and iOS apps<br />
The community that loves both of the above</p></blockquote>
<p>In contrast to recent <a href=\"https://wptavern.com/standardjs-ends-controversial-funding-experiment\" rel=\"noopener noreferrer\" target=\"_blank\">experiments and conversations around sustaining open source infrastructure</a>, NetNewsWire&#8217;s approach gives the project the <a href=\"https://inessential.com/2015/06/30/love\" rel=\"noopener noreferrer\" target=\"_blank\">creative freedom to take risks</a> and ship software at their own pace.</p>
<p>When one commenter asked on Twitter about NetNewsWire&#8217;s business model, Ruby on Rails creator David Heinemeier Hansson <a href=\"https://twitter.com/dhh/status/1167445558534914048\" rel=\"noopener noreferrer\" target=\"_blank\">commented</a> in defense of the project&#8217;s lack of a plan for making a profit.</p>
<p>&#8220;Not everything needs a business model,&#8221; Hansson said. &#8220;Writing open source software for fun, for the intellectual challenge, for the expression of creativity, are valid reasons. Same too goes for writing and sharing. Filtering everything through WHERE’S THE MONEY is a disease of the soul.</p>
<p>&#8220;An open source RSS reader that does not operate a service does not need a business model. An individual publisher paying a pittance to host a blog with RSS does not need a business model.&#8221;</p>
<p>If you&#8217;re looking for a new RSS reader to aggregate your news in a more calm environment than Twitter or Facebook can provide, NetNewsWire is a strong open source option with an exciting future ahead. Few apps have this kind of longevity, and it will be interesting to see how it evolves as an open source Mac app. As of <a href=\"https://ranchero.com/netnewswire/\" rel=\"noopener noreferrer\" target=\"_blank\">version 5.0</a>, it&#8217;s still fairly minimalist in terms of features but has a lot of momentum and <a href=\"https://netnewswire.slack.com/join/shared_invite/enQtNjM4MDA1MjQzMDkzLTNlNjBhOWVhYzdhYjA4ZWFhMzQ1MTUxYjU0NTE5ZGY0YzYwZWJhNjYwNTNmNTg2NjIwYWY4YzhlYzk5NmU3ZTc\" rel=\"noopener noreferrer\" target=\"_blank\">a passionate community</a> behind it, which in this case has proven more valuable towards ensuring its future.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 31 Aug 2019 03:10:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 27 Sep 2019 15:43:45 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Fri, 27 Sep 2019 15:30:08 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `enojr_options` VALUES("164","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1569642226","no");
INSERT INTO `enojr_options` VALUES("165","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1569599026","no");
INSERT INTO `enojr_options` VALUES("166","_transient_timeout_dash_v2_5438fb5baf31c513fff2b9a1067656a6","1569642226","no");
INSERT INTO `enojr_options` VALUES("167","_transient_dash_v2_5438fb5baf31c513fff2b9a1067656a6","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2019/09/wordpress-5-3-beta-1/\'>WordPress 5.3 Beta 1</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/gatsby-raises-15m-plans-to-invest-more-heavily-in-wordpress-and-cms-integrations\'>WPTavern: Gatsby Raises $15M, Plans to Invest More Heavily in WordPress and CMS Integrations</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/long-needed-date-time-improvements-land-in-core\'>WPTavern: Long-Needed Date/Time Improvements Land in Core</a></li><li><a class=\'rsswidget\' href=\'https://pento.net/2019/09/26/talking-with-wpup/\'>Gary: Talking with WP&amp;UP</a></li></ul></div>","no");
INSERT INTO `enojr_options` VALUES("173","_transient_timeout_plugin_slugs","1569686112","no");
INSERT INTO `enojr_options` VALUES("174","_transient_plugin_slugs","a:14:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:3;s:11:\"amp/amp.php\";i:4;s:23:\"elementor/elementor.php\";i:5;s:67:\"extended-google-map-for-elementor/elementor-google-map-extended.php\";i:6;s:36:\"google-sitemap-generator/sitemap.php\";i:7;s:9:\"hello.php\";i:8;s:35:\"modula-best-grid-gallery/Modula.php\";i:9;s:31:\"query-monitor/query-monitor.php\";i:10;s:47:\"show-current-template/show-current-template.php\";i:11;s:27:\"woosidebars/woosidebars.php\";i:12;s:33:\"wp-user-avatar/wp-user-avatar.php\";i:13;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `enojr_options` VALUES("175","recently_activated","a:0:{}","yes");
INSERT INTO `enojr_options` VALUES("176","widget_akismet_widget","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `enojr_options` VALUES("177","akismet_strictness","0","yes");
INSERT INTO `enojr_options` VALUES("178","akismet_show_user_comments_approved","0","yes");
INSERT INTO `enojr_options` VALUES("179","akismet_comment_form_privacy_notice","hide","yes");
INSERT INTO `enojr_options` VALUES("180","wordpress_api_key","2d082d2b416f","yes");
INSERT INTO `enojr_options` VALUES("181","akismet_spam_count","0","yes");
INSERT INTO `enojr_options` VALUES("182","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1569610108","no");
INSERT INTO `enojr_options` VALUES("183","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4617;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:3654;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2643;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2515;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1936;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1760;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1750;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1472;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1451;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1447;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1437;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1384;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1359;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1295;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1157;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1136;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1106;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1076;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1044;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:952;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:862;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:849;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:845;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:813;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:755;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:747;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:735;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:734;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:725;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:706;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:704;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:688;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:681;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:674;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:671;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:657;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:636;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:633;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:624;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:624;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:608;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:599;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:577;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:573;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:564;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:563;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:557;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:543;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:537;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:534;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:531;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:525;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:520;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:518;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:516;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:514;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:505;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:485;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:481;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:479;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:479;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:478;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:460;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:459;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:450;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:442;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:432;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:424;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:418;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:418;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:416;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:413;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:409;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:404;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:401;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:398;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:396;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:390;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:387;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:386;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:382;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:380;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:369;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:363;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:363;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:359;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:358;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:356;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:352;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:348;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:348;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:336;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:326;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:326;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:326;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:324;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:321;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:318;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:314;}s:3:\"map\";a:3:{s:4:\"name\";s:3:\"map\";s:4:\"slug\";s:3:\"map\";s:5:\"count\";i:312;}}","no");
INSERT INTO `enojr_options` VALUES("213","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/zh_CN/wordpress-5.2.3.zip\";s:6:\"locale\";s:5:\"zh_CN\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/zh_CN/wordpress-5.2.3.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.3\";s:7:\"version\";s:5:\"5.2.3\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1569599702;s:15:\"version_checked\";s:5:\"5.2.3\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `enojr_options` VALUES("215","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1569599704;s:7:\"checked\";a:3:{s:14:\"twentynineteen\";s:3:\"1.4\";s:15:\"twentyseventeen\";s:3:\"2.2\";s:13:\"twentysixteen\";s:3:\"2.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `enojr_options` VALUES("216","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1569599707;s:7:\"checked\";a:14:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.8.3\";s:19:\"akismet/akismet.php\";s:5:\"4.1.2\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.1\";s:11:\"amp/amp.php\";s:5:\"1.2.2\";s:23:\"elementor/elementor.php\";s:5:\"2.7.3\";s:67:\"extended-google-map-for-elementor/elementor-google-map-extended.php\";s:5:\"1.2.1\";s:36:\"google-sitemap-generator/sitemap.php\";s:5:\"4.1.0\";s:9:\"hello.php\";s:5:\"1.7.2\";s:35:\"modula-best-grid-gallery/Modula.php\";s:5:\"2.1.6\";s:31:\"query-monitor/query-monitor.php\";s:5:\"3.3.7\";s:47:\"show-current-template/show-current-template.php\";s:5:\"0.3.0\";s:27:\"woosidebars/woosidebars.php\";s:5:\"1.4.5\";s:33:\"wp-user-avatar/wp-user-avatar.php\";s:5:\"2.2.4\";s:24:\"wordpress-seo/wp-seo.php\";s:4:\"12.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:14:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.8.3\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.8.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.1\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:11:\"amp/amp.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:17:\"w.org/plugins/amp\";s:4:\"slug\";s:3:\"amp\";s:6:\"plugin\";s:11:\"amp/amp.php\";s:11:\"new_version\";s:5:\"1.2.2\";s:3:\"url\";s:34:\"https://wordpress.org/plugins/amp/\";s:7:\"package\";s:52:\"https://downloads.wordpress.org/plugin/amp.1.2.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:56:\"https://ps.w.org/amp/assets/icon-256x256.png?rev=1987390\";s:2:\"1x\";s:56:\"https://ps.w.org/amp/assets/icon-128x128.png?rev=1987390\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/amp/assets/banner-1544x500.png?rev=1987390\";s:2:\"1x\";s:58:\"https://ps.w.org/amp/assets/banner-772x250.png?rev=1987390\";}s:11:\"banners_rtl\";a:0:{}}s:23:\"elementor/elementor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:23:\"w.org/plugins/elementor\";s:4:\"slug\";s:9:\"elementor\";s:6:\"plugin\";s:23:\"elementor/elementor.php\";s:11:\"new_version\";s:5:\"2.7.3\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/elementor/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/elementor.2.7.3.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:62:\"https://ps.w.org/elementor/assets/icon-256x256.png?rev=1427768\";s:2:\"1x\";s:54:\"https://ps.w.org/elementor/assets/icon.svg?rev=1426809\";s:3:\"svg\";s:54:\"https://ps.w.org/elementor/assets/icon.svg?rev=1426809\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/elementor/assets/banner-1544x500.png?rev=1475479\";s:2:\"1x\";s:64:\"https://ps.w.org/elementor/assets/banner-772x250.png?rev=1475479\";}s:11:\"banners_rtl\";a:0:{}}s:67:\"extended-google-map-for-elementor/elementor-google-map-extended.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:47:\"w.org/plugins/extended-google-map-for-elementor\";s:4:\"slug\";s:33:\"extended-google-map-for-elementor\";s:6:\"plugin\";s:67:\"extended-google-map-for-elementor/elementor-google-map-extended.php\";s:11:\"new_version\";s:5:\"1.2.1\";s:3:\"url\";s:64:\"https://wordpress.org/plugins/extended-google-map-for-elementor/\";s:7:\"package\";s:82:\"https://downloads.wordpress.org/plugin/extended-google-map-for-elementor.1.2.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:86:\"https://ps.w.org/extended-google-map-for-elementor/assets/icon-256x256.png?rev=1834518\";s:2:\"1x\";s:86:\"https://ps.w.org/extended-google-map-for-elementor/assets/icon-128x128.png?rev=1834518\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:89:\"https://ps.w.org/extended-google-map-for-elementor/assets/banner-1544x500.png?rev=1834574\";s:2:\"1x\";s:88:\"https://ps.w.org/extended-google-map-for-elementor/assets/banner-772x250.png?rev=1834574\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"google-sitemap-generator/sitemap.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/google-sitemap-generator\";s:4:\"slug\";s:24:\"google-sitemap-generator\";s:6:\"plugin\";s:36:\"google-sitemap-generator/sitemap.php\";s:11:\"new_version\";s:5:\"4.1.0\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/google-sitemap-generator/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/google-sitemap-generator.4.1.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/google-sitemap-generator/assets/icon-256x256.png?rev=1701944\";s:2:\"1x\";s:77:\"https://ps.w.org/google-sitemap-generator/assets/icon-128x128.png?rev=1701944\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/google-sitemap-generator/assets/banner-772x250.png?rev=1701944\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:35:\"modula-best-grid-gallery/Modula.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:38:\"w.org/plugins/modula-best-grid-gallery\";s:4:\"slug\";s:24:\"modula-best-grid-gallery\";s:6:\"plugin\";s:35:\"modula-best-grid-gallery/Modula.php\";s:11:\"new_version\";s:5:\"2.1.6\";s:3:\"url\";s:55:\"https://wordpress.org/plugins/modula-best-grid-gallery/\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/plugin/modula-best-grid-gallery.2.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:77:\"https://ps.w.org/modula-best-grid-gallery/assets/icon-256x256.jpg?rev=2019530\";s:2:\"1x\";s:77:\"https://ps.w.org/modula-best-grid-gallery/assets/icon-256x256.jpg?rev=2019530\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:79:\"https://ps.w.org/modula-best-grid-gallery/assets/banner-772x250.jpg?rev=2019530\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"query-monitor/query-monitor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/query-monitor\";s:4:\"slug\";s:13:\"query-monitor\";s:6:\"plugin\";s:31:\"query-monitor/query-monitor.php\";s:11:\"new_version\";s:5:\"3.3.7\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/query-monitor/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/query-monitor.3.3.7.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/query-monitor/assets/icon-256x256.png?rev=2056073\";s:2:\"1x\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";s:3:\"svg\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=1629576\";s:2:\"1x\";s:68:\"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=1731469\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"show-current-template/show-current-template.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:35:\"w.org/plugins/show-current-template\";s:4:\"slug\";s:21:\"show-current-template\";s:6:\"plugin\";s:47:\"show-current-template/show-current-template.php\";s:11:\"new_version\";s:5:\"0.3.0\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/show-current-template/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/show-current-template.0.3.0.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:73:\"https://ps.w.org/show-current-template/assets/icon-256x256.png?rev=976031\";s:2:\"1x\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";s:3:\"svg\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:27:\"woosidebars/woosidebars.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woosidebars\";s:4:\"slug\";s:11:\"woosidebars\";s:6:\"plugin\";s:27:\"woosidebars/woosidebars.php\";s:11:\"new_version\";s:5:\"1.4.5\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woosidebars/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woosidebars.1.4.5.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:62:\"https://s.w.org/plugins/geopattern-icon/woosidebars_a9c7b8.svg\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/woosidebars/assets/banner-1544x500.png?rev=633896\";s:2:\"1x\";s:65:\"https://ps.w.org/woosidebars/assets/banner-772x250.png?rev=633896\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"wp-user-avatar/wp-user-avatar.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/wp-user-avatar\";s:4:\"slug\";s:14:\"wp-user-avatar\";s:6:\"plugin\";s:33:\"wp-user-avatar/wp-user-avatar.php\";s:11:\"new_version\";s:5:\"2.2.4\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wp-user-avatar/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/wp-user-avatar.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/wp-user-avatar/assets/icon-256x256.png?rev=1755722\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-user-avatar/assets/icon-128x128.png?rev=1755722\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:68:\"https://ps.w.org/wp-user-avatar/assets/banner-772x250.png?rev=882713\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:4:\"12.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wordpress-seo.12.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}","no");
INSERT INTO `enojr_options` VALUES("217","aiowpsec_db_version","1.9","yes");
INSERT INTO `enojr_options` VALUES("218","aio_wp_security_configs","a:91:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:0:\"\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:1:\"1\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:1:\"1\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:22:\"haokexin1214@gmail.com\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:1:\"1\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"fnpdydwmchamabwtg2et\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_custom_login_captcha\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:0:\"\";s:34:\"aiowps_enable_woo_register_captcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";s:25:\"aiowps_captcha_secret_key\";s:20:\"vg9urehxyzpm5qyvrjhc\";s:42:\"aiowps_enable_manual_registration_approval\";s:0:\"\";s:39:\"aiowps_enable_registration_page_captcha\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:0:\"\";s:26:\"aiowps_db_backup_frequency\";s:1:\"4\";s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";s:1:\"2\";s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:22:\"haokexin1214@gmail.com\";s:27:\"aiowps_disable_file_editing\";s:0:\"\";s:37:\"aiowps_prevent_default_wp_file_access\";s:0:\"\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:0:\"\";s:31:\"aiowps_enable_pingback_firewall\";s:0:\"\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:0:\"\";s:34:\"aiowps_block_debug_log_file_access\";s:0:\"\";s:26:\"aiowps_disable_index_views\";s:0:\"\";s:30:\"aiowps_disable_trace_and_track\";s:0:\"\";s:28:\"aiowps_forbid_proxy_comments\";s:0:\"\";s:29:\"aiowps_deny_bad_query_strings\";s:0:\"\";s:34:\"aiowps_advanced_char_string_filter\";s:0:\"\";s:25:\"aiowps_enable_5g_firewall\";s:0:\"\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:0:\"\";s:28:\"aiowps_enable_404_IP_lockout\";s:0:\"\";s:30:\"aiowps_404_lockout_time_length\";s:2:\"60\";s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:0:\"\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:0:\"\";s:30:\"aiowps_enable_spambot_blocking\";s:0:\"\";s:29:\"aiowps_enable_comment_captcha\";s:0:\"\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:0:\"\";s:33:\"aiowps_spam_ip_min_comments_block\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:22:\"haokexin1214@gmail.com\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:0:\"\";s:32:\"aiowps_prevent_users_enumeration\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";}","yes");
INSERT INTO `enojr_options` VALUES("219","_transient_timeout_users_online","1569601512","no");
INSERT INTO `enojr_options` VALUES("220","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";d:1569632112;s:10:\"ip_address\";s:12:\"60.76.76.120\";}}","no");


DROP TABLE IF EXISTS `enojr_postmeta`;

CREATE TABLE `enojr_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `enojr_postmeta` VALUES("2","3","_wp_page_template","default");


DROP TABLE IF EXISTS `enojr_posts`;

CREATE TABLE `enojr_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_posts` VALUES("1","1","2019-09-28 00:34:12","2019-09-27 15:34:12","<!-- wp:paragraph -->
<p>WordPress へようこそ。こちらは最初の投稿です。編集または削除し、コンテンツ作成を始めてください。</p>
<!-- /wp:paragraph -->","Hello world!","","publish","open","open","","hello-world","","","2019-09-28 00:34:12","2019-09-27 15:34:12","","0","https://hkx.monster/?p=1","0","post","","1");
INSERT INTO `enojr_posts` VALUES("2","1","2019-09-28 00:34:12","2019-09-27 15:34:12","<!-- wp:paragraph -->
<p>これはサンプルページです。同じ位置に固定され、(多くのテーマでは) サイトナビゲーションメニューに含まれる点がブログ投稿とは異なります。まずは、サイト訪問者に対して自分のことを説明する自己紹介ページを作成するのが一般的です。たとえば以下のようなものです。</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>はじめまして。昼間はバイク便のメッセンジャーとして働いていますが、俳優志望でもあります。これは僕のサイトです。ロサンゼルスに住み、ジャックという名前のかわいい犬を飼っています。好きなものはピニャコラーダ、そして通り雨に濡れること。</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>または、このようなものです。</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>XYZ 小道具株式会社は1971年の創立以来、高品質の小道具を皆様にご提供させていただいています。ゴッサム・シティに所在する当社では2,000名以上の社員が働いており、様々な形で地域のコミュニティへ貢献しています。</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>新しく WordPress ユーザーになった方は、<a href=\"https://hkx.monster/wp-admin/\">ダッシュボード</a>へ行ってこのページを削除し、独自のコンテンツを含む新しいページを作成してください。それでは、お楽しみください !</p>
<!-- /wp:paragraph -->","サンプルページ","","publish","closed","open","","sample-page","","","2019-09-28 00:34:12","2019-09-27 15:34:12","","0","https://hkx.monster/?page_id=2","0","page","","0");
INSERT INTO `enojr_posts` VALUES("3","1","2019-09-28 00:34:12","2019-09-27 15:34:12","<!-- wp:heading --><h2>私たちについて</h2><!-- /wp:heading --><!-- wp:paragraph --><p>私たちのサイトアドレスは https://hkx.monster です。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>このサイトが収集する個人データと収集の理由</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>コメント</h3><!-- /wp:heading --><!-- wp:paragraph --><p>訪問者がこのサイトにコメントを残す際、コメントフォームに表示されているデータ、そしてスパム検出に役立てるための IP アドレスとブラウザーユーザーエージェント文字列を収集します。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>メールアドレスから作成される匿名化された (「ハッシュ」とも呼ばれる) 文字列は、あなたが Gravatar サービスを使用中かどうか確認するため同サービスに提供されることがあります。同サービスのプライバシーポリシーは https://automattic.com/privacy/ にあります。コメントが承認されると、プロフィール画像がコメントとともに一般公開されます。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>メディア</h3><!-- /wp:heading --><!-- wp:paragraph --><p>サイトに画像をアップロードする際、位置情報 (EXIF GPS) を含む画像をアップロードするべきではありません。サイトの訪問者は、サイトから画像をダウンロードして位置データを抽出することができます。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>お問い合わせフォーム</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookie</h3><!-- /wp:heading --><!-- wp:paragraph --><p>サイトにコメントを残す際、お名前、メールアドレス、サイトを Cookie に保存することにオプトインできます。これはあなたの便宜のためであり、他のコメントを残す際に詳細情報を再入力する手間を省きます。この Cookie は1年間保持されます。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>ログインページを訪問すると、お使いのブラウザーが Cookie を受け入れられるかを判断するために一時 Cookie を設定します。この Cookie は個人データを含んでおらず、ブラウザーを閉じると廃棄されます。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>ログインの際さらに、ログイン情報と画面表示情報を保持するため、私たちはいくつかの Cookie を設定します。ログイン Cookie は2日間、画面表示オプション Cookie は1年間保持されます。「ログイン状態を保存する」を選択した場合、ログイン情報は2週間維持されます。ログアウトするとログイン Cookie は消去されます。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>もし投稿を編集または公開すると、さらなる Cookie がブラウザーに保存されます。この Cookie は個人データを含まず、単に変更した投稿の ID を示すものです。1日で有効期限が切れます。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>他サイトからの埋め込みコンテンツ</h3><!-- /wp:heading --><!-- wp:paragraph --><p>このサイトの投稿には埋め込みコンテンツ (動画、画像、投稿など) が含まれます。他サイトからの埋め込みコンテンツは、訪問者がそのサイトを訪れた場合とまったく同じように振る舞います。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>これらのサイトは、あなたのデータの収集、Cookie の使用、サードパーティによる追加トラッキングの埋め込み、埋め込みコンテンツとのやりとりの監視を行うことがあります。アカウントを使ってそのサイトにログイン中の場合、埋め込みコンテンツとのやりとりのトラッキングも含まれます。</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>アナリティクス</h3><!-- /wp:heading --><!-- wp:heading --><h2>あなたのデータの共有先</h2><!-- /wp:heading --><!-- wp:heading --><h2>データを保存する期間</h2><!-- /wp:heading --><!-- wp:paragraph --><p>あなたがコメントを残すと、コメントとそのメタデータが無期限に保持されます。これは、モデレーションキューにコメントを保持しておく代わりに、フォローアップのコメントを自動的に認識し承認できるようにするためです。</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>このサイトに登録したユーザーがいる場合、その方がユーザープロフィールページで提供した個人情報を保存します。すべてのユーザーは自分の個人情報を表示、編集、削除することができます (ただしユーザー名は変更することができません)。サイト管理者もそれらの情報を表示、編集できます。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>データに対するあなたの権利</h2><!-- /wp:heading --><!-- wp:paragraph --><p>このサイトのアカウントを持っているか、サイトにコメントを残したことがある場合、私たちが保持するあなたについての個人データ (提供したすべてのデータを含む) をエクスポートファイルとして受け取るリクエストを行うことができます。また、個人データの消去リクエストを行うこともできます。これには、管理、法律、セキュリティ目的のために保持する義務があるデータは含まれません。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>あなたのデータの送信先</h2><!-- /wp:heading --><!-- wp:paragraph --><p>訪問者によるコメントは、自動スパム検出サービスを通じて確認を行う場合があります。</p><!-- /wp:paragraph --><!-- wp:heading --><h2>あなたの連絡先情報</h2><!-- /wp:heading --><!-- wp:heading --><h2>追加情報</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>データの保護方法</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>データ漏洩対策手順</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>データ送信元のサードパーティ</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>ユーザーデータに対して行う自動的な意思決定およびプロファイリング</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>業界規制の開示要件</h3><!-- /wp:heading -->","プライバシーポリシー","","draft","closed","open","","privacy-policy","","","2019-09-28 00:34:12","2019-09-27 15:34:12","","0","https://hkx.monster/?page_id=3","0","page","","0");
INSERT INTO `enojr_posts` VALUES("4","1","2019-09-28 00:34:22","0000-00-00 00:00:00","","自動下書き","","auto-draft","open","open","","","","","2019-09-28 00:34:22","0000-00-00 00:00:00","","0","https://hkx.monster/?p=4","0","post","","0");


DROP TABLE IF EXISTS `enojr_site_cache`;

CREATE TABLE `enojr_site_cache` (
  `hash` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `server` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updating` tinyint(1) NOT NULL DEFAULT '0',
  `create_time` datetime NOT NULL,
  `expire_time` datetime NOT NULL,
  KEY `hash` (`hash`),
  KEY `expire_time` (`expire_time`),
  KEY `type` (`type`,`post_type`(191)),
  KEY `updating` (`updating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_sitemanager_device`;

CREATE TABLE `enojr_sitemanager_device` (
  `device_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `keyword` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `builtin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`device_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_sitemanager_device` VALUES("1","iPad","\\(iPad","0");
INSERT INTO `enojr_sitemanager_device` VALUES("2","iPhone","\\(iPhone","0");
INSERT INTO `enojr_sitemanager_device` VALUES("3","iPod","\\(iPod","0");
INSERT INTO `enojr_sitemanager_device` VALUES("4","Android","Android .+ Mobile","0");
INSERT INTO `enojr_sitemanager_device` VALUES("5","Android Tablet"," Android ","0");
INSERT INTO `enojr_sitemanager_device` VALUES("6","IEMobile","IEMobile","0");
INSERT INTO `enojr_sitemanager_device` VALUES("7","Windows Phone","Windows Phone","0");
INSERT INTO `enojr_sitemanager_device` VALUES("8","Firefox Mobile","Android; Mobile; .+Firefox","0");
INSERT INTO `enojr_sitemanager_device` VALUES("9","Firefox Tablet","Android; Tablet; .+Firefox","0");


DROP TABLE IF EXISTS `enojr_sitemanager_device_group`;

CREATE TABLE `enojr_sitemanager_device_group` (
  `group_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int(11) NOT NULL,
  `builtin` binary(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_sitemanager_device_group` VALUES("1","タブレット","","tablet","200","0");
INSERT INTO `enojr_sitemanager_device_group` VALUES("2","スマートフォン","","smart","100","0");


DROP TABLE IF EXISTS `enojr_sitemanager_device_relation`;

CREATE TABLE `enojr_sitemanager_device_relation` (
  `group_id` bigint(20) NOT NULL,
  `device_id` bigint(20) NOT NULL,
  KEY `group_id` (`group_id`,`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_sitemanager_device_relation` VALUES("1","1");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("1","5");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("1","9");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("2","2");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("2","3");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("2","4");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("2","6");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("2","7");
INSERT INTO `enojr_sitemanager_device_relation` VALUES("2","8");


DROP TABLE IF EXISTS `enojr_term_relationships`;

CREATE TABLE `enojr_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_term_relationships` VALUES("1","1","0");


DROP TABLE IF EXISTS `enojr_term_taxonomy`;

CREATE TABLE `enojr_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_term_taxonomy` VALUES("1","1","category","","0","1");


DROP TABLE IF EXISTS `enojr_termmeta`;

CREATE TABLE `enojr_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `enojr_terms`;

CREATE TABLE `enojr_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_terms` VALUES("1","未分類","%e6%9c%aa%e5%88%86%e9%a1%9e","0");


DROP TABLE IF EXISTS `enojr_usermeta`;

CREATE TABLE `enojr_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_usermeta` VALUES("1","1","nickname","haokexin");
INSERT INTO `enojr_usermeta` VALUES("2","1","first_name","");
INSERT INTO `enojr_usermeta` VALUES("3","1","last_name","");
INSERT INTO `enojr_usermeta` VALUES("4","1","description","");
INSERT INTO `enojr_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `enojr_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `enojr_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `enojr_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `enojr_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `enojr_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `enojr_usermeta` VALUES("11","1","locale","");
INSERT INTO `enojr_usermeta` VALUES("12","1","enojr_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `enojr_usermeta` VALUES("13","1","enojr_user_level","10");
INSERT INTO `enojr_usermeta` VALUES("14","1","dismissed_wp_pointers","");
INSERT INTO `enojr_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `enojr_usermeta` VALUES("16","1","session_tokens","a:2:{s:64:\"be3390a6f7ca4e0d6d2e90703d6cb82665e8192f9ee5e6177656315e4bdbe5ee\";a:4:{s:10:\"expiration\";i:1569771261;s:2:\"ip\";s:12:\"60.76.76.120\";s:2:\"ua\";s:113:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36\";s:5:\"login\";i:1569598461;}s:64:\"ee09bffced84c01453993952dae1d47901cf4fe02a7f46e6233e54ddcc3a6846\";a:4:{s:10:\"expiration\";i:1569771697;s:2:\"ip\";s:12:\"60.76.76.120\";s:2:\"ua\";s:113:\"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36\";s:5:\"login\";i:1569598897;}}");
INSERT INTO `enojr_usermeta` VALUES("17","1","enojr_dashboard_quick_press_last_post_id","4");
INSERT INTO `enojr_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:10:\"60.76.76.0\";}");


DROP TABLE IF EXISTS `enojr_users`;

CREATE TABLE `enojr_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enojr_users` VALUES("1","haokexin","$P$Bf2x0LA36Y8swnapXcVFeuEC2fidCe.","haokexin","haokexin1214@gmail.com","","2019-09-27 15:34:12","","0","haokexin");


